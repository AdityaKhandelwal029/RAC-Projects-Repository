package com.rac.teamcenter.projectaccessextension.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.jface.dialogs.MessageDialog;

@SuppressWarnings("unused")
public class SampleHandler extends AbstractHandler 
{

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException 
	{
		//IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		//MessageDialog.openInformation(window.getShell(),"Project Access Extension","Please wait for few minutes.Loading will take time ......... ");
		
		ProAccessApp window1 = new ProAccessApp(event);
		window1.frmProjectAccessExtension.setVisible(true);		
		
		return null;
	}
}
