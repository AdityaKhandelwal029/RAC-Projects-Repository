package com.rac.teamcenter.projectaccessextension.handlers;

import java.io.*;
import java.util.*;
import java.lang.*;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.t5.services.rac.tmshellexecution.T5LinuxShellManagementService;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AbstractAIFSession;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentFolder;
import com.teamcenter.rac.kernel.TCComponentGroup;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRole;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;

import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

import java.text.SimpleDateFormat;
import java.beans.PropertyChangeEvent;
import com.teamcenter.rac.kernel.TCComponentProcessType;
import com.teamcenter.rac.kernel.TCComponentTaskTemplate;
import com.teamcenter.rac.kernel.TCComponentTaskTemplateType;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.loose.core._2008_06.DataManagement.CreateIn;
import com.teamcenter.services.loose.core._2008_06.DataManagement.CreateInput;
import com.teamcenter.services.loose.core._2008_06.DataManagement.CreateResponse;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2008_06.DataManagement;

@SuppressWarnings("unused")
public class ProAccessApp {

	JFrame frmProjectAccessExtension;
	private JLabel lblTmlManager;
	private JLabel lblProjectCode;
	private JLabel lblGroup;
	private JLabel lblRole;
	
	//Icon imgIcon = new ImageIcon(this.getClass().getResource("file:///D:/DVA_workspasce/com.rac.teamcenter.ProjectAccessExtension/icons/img1.gif"));
	
	private JTextField txtLoadingInProcess;
	private final JLabel gifLabel = new JLabel(new ImageIcon(ProAccessApp.class.getResource("/com/rac/teamcenter/projectaccessextension/handlers/LoadingImg.png")));
	static ExecutionEvent eventobj;
	@SuppressWarnings("rawtypes")
	JComboBox comboBoxProjectCode = new JComboBox();
	@SuppressWarnings("rawtypes")
	JComboBox comboBoxGroup = new JComboBox();
	@SuppressWarnings("rawtypes")
	JComboBox comboBoxRole = new JComboBox();
	@SuppressWarnings("rawtypes")
	JComboBox comboBoxTMLManager = new JComboBox();
	JButton SelectProjectbtn = new JButton("Select");
	JButton SelectRolebtn = new JButton("Select");
	JButton btnOk = new JButton("OK");
	JButton btnCancel = new JButton("Cancel");	
	JTextPane textPaneProCode = new JTextPane();
	JTextPane textPaneRole = new JTextPane();
	JScrollPane scrollPane = new JScrollPane();
	JScrollPane scrollPane_1 = new JScrollPane();
	
	int t1=0,t2=0;
	int k = 1;
	int tmpId = 0;
	int w=0;
 	int x=0;
 	int y=0;
    int z=0;
    
    int groupRoleVerify = 0;
    
	String logFileName          = null;
	String finalInputString     = null;
	String currentdate          = null;
	String currentTime          = null;
	String LoggedInUser         = null;
	String LoggedInUserPassword = null;
	String updatedItemId        = null;
	String tempId               = null; 
	String tempa                = ""; 
	String tempb                = null;
	String updT5Manager         = "";
	String currentRole          = null; 
	String currentGroup         = null;
	String tempGroup            = null;
	String userIdValue          = null;
	String testUserId           = null;
	String parNum               = null;
	String tmlManager           = null;
	String projectCode          = null;
	String groups               = null;
	String roles                = null;
	String glbRolesAccess       = null;
	String parRequestOwner      = null;
	String parRequestOwnId      = null;
	
	
	TCSession session = null;
	TCComponentQueryType tccomponentquerytype = null;
	TCComponentQuery query                    = null;
								              
	TCComponent parObject                     = null;
	TCComponent userObjCom                    = null;
	TCComponent owningUserObjCom              = null;
	
	TCComponentItemRevision parObjectRev      = null;
										      
	TCComponent[] qryResultParRequest         = null;
	TCComponent[] qryResultProject            = null;
	TCComponent[] qryResultUser               = null;
	TCComponent[] qryResultGroup              = null;
	TCComponent[] qryGroupRoleUser            = null;
	
	
	TCComponent[] itemRevArray = new TCComponent[1];
	int[] targtCount = new int[1];

	ArrayList<String> projectValues = new ArrayList<String>();
	ArrayList<String> userValues = new ArrayList<String>();
	ArrayList<String> groupValues = new ArrayList<String>();
	
	Vector<Integer> itemIdsfound = new Vector<>();
	
	
	TCComponentItem itemComp = null;
	TCComponentGroup grp = null;
	TCComponentFolder userHomeFolder = null;
	TCComponentRole[] rolesList = null;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProAccessApp window = new ProAccessApp(eventobj);
					window.frmProjectAccessExtension.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	@SuppressWarnings("static-access")
	public ProAccessApp(ExecutionEvent event1) 
	{
		this.eventobj=event1;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initialize() {
		frmProjectAccessExtension = new JFrame();
		frmProjectAccessExtension.setResizable(false);
		frmProjectAccessExtension.addWindowListener(new WindowAdapter() {
			
			@Override
			public void windowOpened(WindowEvent e) 
			{
				try
				{
					// Query for PAR Request Item.
					
					session = (TCSession) AIFUtility.getCurrentApplication().getSession();
					LoggedInUser=session.getUser().getProperty("user_id").toString();	 
					currentRole=session.getCurrentRole().getProperty("object_name").toString();
					currentGroup=session.getCurrentGroup().getProperty("display_name").toString();
					
					System.out.println(" LoggedInUser found = "+LoggedInUser);	
					System.out.println(" currentRole  found = "+currentRole);
					System.out.println(" currentGroup found = "+currentGroup);
					  					  					
					// Query for user list in teamcenter.
					  
					System.out.println("\n ******************* User Query Started 20-01-2025 ******************* ");
															
					tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
					query = (TCComponentQuery) tccomponentquerytype.find("UserCheck");
					String[] qryEntry  = new String[] { "Id","Status"};
					String[] qryValues = new String[] { "*","0"};
					qryResultUser = null;
					qryResultUser = query.execute(qryEntry, qryValues);
					System.out.println("\n -qryResultUser.length = "+qryResultUser.length);
					
					for (int i = 0; i < qryResultUser.length; i++)
					{						
						testUserId=qryResultUser[i].getStringProperty("object_string");
					   //	System.out.println(" - testUserId = "+testUserId);
																						
					    if(testUserId.equals("")==false && testUserId.length()>0)
					    {
					    	if(testUserId.contains(".")||testUserId.contains("-")||testUserId.contains("_"))
							{
								// Not to add these values.
							}
							else
							{
								// TML managers only added.																								
								userValues.add(testUserId);
							}
					    }						
					}                                                      
					Collections.sort(userValues);
					for (int i = 0; i < userValues.size(); i++)
					{
						comboBoxTMLManager.addItem(userValues.get(i));
					}                                                            
					
		    		// Query for Project codes.
					
					System.out.println("\n ******************* Project Query Started ******************* ");
					
					tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
					query = (TCComponentQuery) tccomponentquerytype.find("Projects...");
					String[] qryEntry1 = new String[] { "Project ID" };
					String[] qryValues1 = new String[] { "*" };
					qryResultProject = null;
					qryResultProject = query.execute(qryEntry1, qryValues1);
					
					System.out.println(" -qryResultProject.length = "+qryResultProject.length);
					
					for (int i = 0; i < qryResultProject.length; i++) 
					{
						String testProjectId = qryResultProject[i].getStringProperty("project_id");
					//	System.out.println("\n -testProjectId = "+testProjectId);
						if(testProjectId.equals("")==false && testProjectId.length()>0)
						{
							projectValues.add(testProjectId);
						}						
					}
					Collections.sort(projectValues);
					for (int i = 0; i < projectValues.size(); i++)
					{
						comboBoxProjectCode.addItem(projectValues.get(i));
					}
					
					txtLoadingInProcess.setText("");
					gifLabel.setBorder(new LineBorder(Color.WHITE));
					gifLabel.setIcon(null);    
				} 
				catch (TCException e1) 
				{
					e1.printStackTrace();
					System.out.println("********** TC Exception occurred point [1] ********** ");
				}
				catch (Exception e1) 
				{
					e1.printStackTrace();
					System.out.println("********** General Exception occurred point [1] ********** ");
				}
			}
		});
		frmProjectAccessExtension.getContentPane().setBackground(Color.WHITE);
		frmProjectAccessExtension.setTitle("Project Access Extension Request");
		frmProjectAccessExtension.setBounds(100, 100, 625, 600);
		frmProjectAccessExtension.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmProjectAccessExtension.getContentPane().setLayout(null);
		
		lblTmlManager = new JLabel("TML Manager");
		lblTmlManager.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblTmlManager.setBorder(null);
		lblTmlManager.setBounds(45, 88, 125, 25);
		frmProjectAccessExtension.getContentPane().add(lblTmlManager);
		
		lblProjectCode = new JLabel("Project code");
		lblProjectCode.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblProjectCode.setBorder(null);
		lblProjectCode.setBounds(45, 142, 125, 25);
		frmProjectAccessExtension.getContentPane().add(lblProjectCode);
		
		lblGroup = new JLabel("Group");
		lblGroup.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblGroup.setBorder(null);
		lblGroup.setBounds(45, 297, 125, 25);
		frmProjectAccessExtension.getContentPane().add(lblGroup);
		
		lblRole = new JLabel("Role");
		lblRole.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblRole.setBorder(null);
		lblRole.setBounds(45, 333, 125, 25);
		frmProjectAccessExtension.getContentPane().add(lblRole);
		
		comboBoxProjectCode.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		comboBoxProjectCode.setBackground(Color.WHITE);
		comboBoxProjectCode.setBorder(null);
		comboBoxProjectCode.setBounds(230, 142, 250, 25);
		frmProjectAccessExtension.getContentPane().add(comboBoxProjectCode);
			
		comboBoxGroup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				System.out.println(" Action Performed on group Combobox");
				try
				{
					String input=comboBoxGroup.getSelectedItem().toString();
					session = (TCSession) AIFUtility.getCurrentApplication().getSession();
					tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
					query = (TCComponentQuery) tccomponentquerytype.find("GroupByName");
					String[] qryEntry2 = new String[] { "Name" };
					String[] qryValues2 = new String[] { input };
					qryResultGroup = null;
					qryResultGroup = query.execute(qryEntry2, qryValues2);
					for(int i=0;i<qryResultGroup.length;i++)
					{
						tempGroup=qryResultGroup[i].getProperty("display_name");
						System.out.println(" tempGroup = "+tempGroup);
						if(tempGroup.equals(input))
						{
							System.out.println(" Matching Group Found = "+qryResultGroup[i].toString());
							grp = (TCComponentGroup) qryResultGroup[i];
							rolesList = grp.getRoles();
							if (rolesList.length > 0)
							{
								comboBoxRole.removeAllItems();
								for (int j = 0; j < rolesList.length; j++) 
								{
									comboBoxRole.addItem(rolesList[j].toString());
								}
							} 
							else
							{
								comboBoxRole.removeAllItems();
								System.out.println("Roles not found for the selected group. Please select a valid group or connect with admin !");
								JOptionPane.showMessageDialog(null, "Roles not found for the selected group. Please select a valid group or connect with admin !","Error",JOptionPane.ERROR_MESSAGE);
							}	
						}
					}
				}
				catch (TCException e1) 
				{
					e1.printStackTrace();
					System.out.println("********** TC Exception occurred point [2] ********** ");
				}
				catch (Exception e1) 
				{
					e1.printStackTrace();
					System.out.println("********** General Exception occurred point [2] ********** ");
				}
			}
			
		});
		comboBoxGroup.setModel(new DefaultComboBoxModel(new String[] {"", "ERC_Designers_Group", "Colour_Designer_Group", "Modular_Colour_Scheme_Group", "MBOM", "Vehicle_Integration", "APLAHD", "APLCAR", "APLDWD", "APLJSR", "APLLKO", "APLPUNE", "APLSND", "APLUTK", "APLUV", "STDAHD", "STDCAR", "STDDWD", "STDJSR", "STDLKO", "STDPUNE", "STDSND", "STDUTK"}));
		
		comboBoxGroup.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		comboBoxGroup.setBorder(null);
		comboBoxGroup.setBackground(Color.WHITE);
		comboBoxGroup.setBounds(230, 298, 250, 25);
		frmProjectAccessExtension.getContentPane().add(comboBoxGroup);
		
		comboBoxRole.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		comboBoxRole.setBorder(null);
		comboBoxRole.setBackground(Color.WHITE);
		comboBoxRole.setBounds(230, 334, 250, 25);
		frmProjectAccessExtension.getContentPane().add(comboBoxRole);
		
		comboBoxTMLManager.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		comboBoxTMLManager.setBorder(null);
		comboBoxTMLManager.setBackground(Color.WHITE);
		comboBoxTMLManager.setBounds(230, 88, 250, 25);
		frmProjectAccessExtension.getContentPane().add(comboBoxTMLManager);
		SelectProjectbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				String temp  = comboBoxProjectCode.getSelectedItem().toString();
			    String temp2 = textPaneProCode.getText();
			    if(t1==0)
			    {
			    	temp2=temp;
			    	t1=1;
			    }
			    else
			    {
			    	temp2=temp2+","+temp;
			    }
			    textPaneProCode.setText(temp2);
			}
		});
		
		SelectProjectbtn.setBackground(Color.WHITE);
		SelectProjectbtn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		SelectProjectbtn.setBounds(485, 144, 89, 23);
		frmProjectAccessExtension.getContentPane().add(SelectProjectbtn);
		SelectRolebtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				String temp = comboBoxRole.getSelectedItem().toString();
			    String temp2 = textPaneRole.getText();
			    if(t2==0)
			    {
			    	temp2=temp;
			    	t2=1;
			    }
			    else
			    {
			    	temp2=temp2+","+temp;
			    }
			    textPaneRole.setText(temp2);
			}
		});
		
		SelectRolebtn.setBackground(Color.WHITE);
		SelectRolebtn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		SelectRolebtn.setBounds(485, 335, 89, 23);
		frmProjectAccessExtension.getContentPane().add(SelectRolebtn);
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				System.out.println(" ****************** OK 20-01-2025 ****************** ");
				
				y=0;
				updT5Manager = "";
				groupRoleVerify=0;
				txtLoadingInProcess.setText("Loading .... ");
				gifLabel.setBorder(new LineBorder(Color.LIGHT_GRAY));
				gifLabel.setIcon(new ImageIcon(ProAccessApp.class.getResource("/com/rac/teamcenter/projectaccessextension/handlers/LoadingImg.png")));			
					
				tmlManager  = comboBoxTMLManager.getSelectedItem().toString();
				projectCode = textPaneProCode.getText(); 
				groups      = comboBoxGroup.getSelectedItem().toString();
				roles       = textPaneRole.getText();	
				
				for(w=0;w<tmlManager.length();w++)
				{
					if(tmlManager.charAt(w)=='(')
					{
						x=1;
					}
					if(tmlManager.charAt(w)==')')
					{
						x=2;
					}
					if(x==1)
					{
						y++;
						if(y>1)
						{
							updT5Manager=updT5Manager+tmlManager.charAt(w);
						    z++;
						}
					}
				}
				
				System.out.println(" LoggedInUser   = "+LoggedInUser  +" LoggedInUserLength = "+LoggedInUser.length());
				System.out.println(" tmlManager     = "+tmlManager    +" tmlManagerLength   = "+tmlManager.length());
				System.out.println(" updT5Manager   = "+updT5Manager  +" updT5ManagerLength = "+updT5Manager.length());
				System.out.println(" projectCode    = "+projectCode   +" projectCodeLength  = "+projectCode.length());
				System.out.println(" groups         = "+groups        +" groupsLength       = "+groups.length());
				System.out.println(" roles          = "+roles         +" roles Length       = "+roles.length());
						
				//System.out.println(" logFileName      ="+logFileName);
				//System.out.println(" finalInputString ="+finalInputString);
								
				if(tmlManager.length()>0 && projectCode.length()>0&&groups.length()>0&&roles.length()>0)
				{
					System.out.println("If Condition executed with length of variables Greater than zero.");
					
					if(LoggedInUser.equals(updT5Manager)&&LoggedInUser.length()==updT5Manager.length())
					{
						System.out.println("If condition executed Loggedin user can't be TML Manager.");	
						JOptionPane.showMessageDialog(null, "Login user can't be selected as TML Manager. Please select valid TML Manager and try again.","Error",JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						groupRoleVerify = groupRoleVerificationCheck(groups,roles);
						
						System.out.println("- groupRoleVerify = "+groupRoleVerify);
						System.out.println("- glbRolesAccess  = "+glbRolesAccess);
											 
                        if(groupRoleVerify==0)
                        {
                       	    JOptionPane.showMessageDialog(null, "User don't have access to selected -> [ "+glbRolesAccess+" ] role/roles .Please Check and try again.","Error",JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {                        	                       	                         	                        	                         	     						
    						try 
    						{
								// Request Id Generation 
								
								tccomponentquerytype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
       					        query = (TCComponentQuery)tccomponentquerytype.find("General..."); 
       					        String[] qryEntry3  = new String[] {"Name","Type"}; 
       					        String[] qryValues3 = new String[] {"*", "Par Request" };
       					        qryResultParRequest = null; 
       					        qryResultParRequest = query.execute(qryEntry3,qryValues3);
       					        System.out.println("Total PAR Objects Found = "+qryResultParRequest.length);				  					  													
       					        if(qryResultParRequest.length>0)
       					        {					 	  
       						        for(int i=0;i<qryResultParRequest.length;i++)							  
       						        {
       						    	      itemComp = (TCComponentItem)qryResultParRequest[i]; 						  
       						    	       tempId  = itemComp.getProperty("item_id"); 
       						    	       tempId = tempId.substring(3,tempId.length());						   
       						    	       tmpId  =Integer.parseInt(tempId); 			   				  
       						    	      itemIdsfound.add(tmpId);
       						        }
       						        Collections.sort(itemIdsfound);
       						        tmpId=itemIdsfound.lastElement();
       						        System.out.println(" Value found = "+tmpId);
       						        tmpId = tmpId +1;
       						        System.out.println(" Updated Value found = "+tmpId);
       						        
       						        String s=String.valueOf(tmpId);
       						        k=7-s.length();
       						        for(int i=1;i<=k;i++)
       						        {
       						         tempa=tempa+"0";
       						        }
       						        tempa=tempa+s;
       						        s=tempa;
       						        s="PAR"+s;
       						        updatedItemId=s;
       						        System.out.println(" String Returned or requestId generated = "+updatedItemId);
                                    parNum = updatedItemId;									
       					        }
       					        else
       					        {
       					            updatedItemId="PAR0000001";									
									parNum = updatedItemId;
       					        }
								
								System.out.println(" - parNum = "+parNum);
								
								// Par Object Creation
								
								DataManagement.CreateInput itemCreateIn= new DataManagement.CreateInput();
    						    itemCreateIn.boName = "T5_ParRequest";
							    
    						    itemCreateIn.stringProps.put("item_id", parNum);
    						    itemCreateIn.stringProps.put("object_name", parNum);
    						    itemCreateIn.stringProps.put("object_desc",parNum);
							    
    						    System.out.println("\n Setting the value1 for T5_ParRequest");
							    							    
    						    DataManagement.CreateInput revisionCreateIn = new DataManagement.CreateInput();
    						    revisionCreateIn.boName = "T5_ParRequestRevision";
    						    revisionCreateIn.stringProps.put("item_revision_id", "NR");	
    						    revisionCreateIn.stringProps.put("t5_Group", groups);
    						    revisionCreateIn.stringProps.put("t5_ParRequestProjectCode", projectCode);
    						    revisionCreateIn.stringProps.put("t5_TML_Manager", updT5Manager);
    						    revisionCreateIn.stringProps.put("DocumentAuthor", LoggedInUser);
    						    revisionCreateIn.stringProps.put("t5_Role", roles);
    						    
    						    System.out.println("\n Setting the values for T5_ParRequestRevision");
							    
    						    itemCreateIn.compoundCreateInput.put("revision", new DataManagement.CreateInput[]{revisionCreateIn});
    						    DataManagement.CreateIn cnAPLDMLCreateIn = new DataManagement.CreateIn();
    						    cnAPLDMLCreateIn.clientId = parNum;
    						    cnAPLDMLCreateIn.data = itemCreateIn;
    						    DataManagementService dmService_APLDML = DataManagementService.getService(session);
    						    DataManagement.CreateResponse APLDMLcreateResponse;
								
    							APLDMLcreateResponse = dmService_APLDML.createObjects(new DataManagement.CreateIn[]{cnAPLDMLCreateIn});
    							System.out.println(" ************ Par Object creation successfull ************ ");
    							
    							tccomponentquerytype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
    							query = (TCComponentQuery)tccomponentquerytype.find("Item..."); 
    							String[] qryEntry4  = new String[] {"Item ID","Type"}; 
    							String[] qryValues4 = new String[] {parNum, "Par Request" };
    							qryResultParRequest = null; 
    							qryResultParRequest = query.execute(qryEntry4,qryValues4);
    							System.out.println("Total Real PAR Objects found = "+qryResultParRequest.length);
    							if(qryResultParRequest.length==1)
    							{    								
    								owningUserObjCom = qryResultParRequest[0].getReferenceProperty("owning_user");   								
    								parRequestOwner  = owningUserObjCom.getStringProperty("object_string");
    								parRequestOwnId  = owningUserObjCom.getStringProperty("user_id");
    								   								
    								System.out.println(" - parRequestOwner    = "+parRequestOwner);
    								System.out.println(" - parRequestOwnId    = "+parRequestOwnId);
    								System.out.println(" - LoggedInUser found = "+LoggedInUser);
    								    								
    								if(LoggedInUser.equals(parRequestOwnId) == true)
    								{
    									parObject      = qryResultParRequest[0];
        								parObjectRev   = ((TCComponentItem) parObject).getLatestItemRevision();
        								userHomeFolder = session.getUser().getHomeFolder();
        								userHomeFolder.add("contents",parObject);
        								
        								targtCount[0] = 1;
        								itemRevArray[0] = parObjectRev;
        								
        								System.out.println(" ************ Object successfully added to home folder ************ ");
        								
        								TCComponentTaskTemplateType workflowtemptask = (TCComponentTaskTemplateType)session.getTypeComponent("EPMTaskTemplate");
        								TCComponentTaskTemplate workflowTemplate = workflowtemptask.find("Project access extension request process workflow", 0);
        								TCComponentProcessType workflowProcess = (TCComponentProcessType)session.getTypeComponent("Job");
        								workflowProcess.create(parNum, "-", workflowTemplate, itemRevArray, targtCount);
        								
        								System.out.println(" ************ Workflow Process successfully attached ************ ");
        								
        								JOptionPane.showMessageDialog(null,"Process completed. Project Access Request creation successful with ID "+parNum+" .","Info",JOptionPane.INFORMATION_MESSAGE); 
        								System.out.println(" ************ Project Access Extension Request Jar execution successfull. ************ ");
        								frmProjectAccessExtension.dispose();
    								}
    								else
    								{
    									JOptionPane.showMessageDialog(null,"Par request creation failed due to incorrect request id. Please create a new request and try again.","Info",JOptionPane.INFORMATION_MESSAGE); 
    									frmProjectAccessExtension.dispose();
    								}   							
    							}
    							else
    							{
    								System.out.println(" ************ Par request creation failed  ************ ");
    								System.out.println(" ************ Attacment of object to home folder failed because real par request not found  ************ ");
    								JOptionPane.showMessageDialog(null,"Par request creation failed. Please try again or connect with admin.","Info",JOptionPane.INFORMATION_MESSAGE); 
    								frmProjectAccessExtension.dispose();
    							}    												
    						} 
    						catch (ServiceException e) 
    						{
    							// TODO Auto-generated catch block				
    							System.out.println(" ************ Service Exception Occurred point [3] ************ ");
    							e.printStackTrace();
    						} 
    						catch (TCException e) 
    						{
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							System.out.println(" ************ TC Exception Occurred point [3] ************ ");							
    						}
    						catch (Exception e)
    						{
    							e.printStackTrace();
    							System.out.println(" ************ General Occurred point [3] ************ ");
    						}
                        }
					}
				}
				else
				{
					System.out.println("Else Condition executed After checking length. Missing values found.");	
					JOptionPane.showMessageDialog(null, "Please fill all required fields. some required fields are missing.","Error",JOptionPane.ERROR_MESSAGE);
				}
				
				//textField.setText("");
				//textPaneProCode.setText(""); 
				//textPaneRole.setText("");
				t1=0;
				t2=0;
				txtLoadingInProcess.setText("");
				gifLabel.setBorder(new LineBorder(Color.WHITE));
				gifLabel.setIcon(null);				
			}
		});
		
		
		btnOk.setBackground(Color.WHITE);
		btnOk.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnOk.setBounds(115, 493, 89, 23);
		frmProjectAccessExtension.getContentPane().add(btnOk);
		
		btnCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				frmProjectAccessExtension.dispose();
			}
		});
		
		
		btnCancel.setBackground(Color.WHITE);
		btnCancel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnCancel.setBounds(391, 493, 89, 23);
		frmProjectAccessExtension.getContentPane().add(btnCancel);	
		
		scrollPane.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		scrollPane.setBounds(180, 180, 300, 100);
		frmProjectAccessExtension.getContentPane().add(scrollPane);
		textPaneProCode.setEditable(false);
		textPaneProCode.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		scrollPane.setViewportView(textPaneProCode);
		scrollPane_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		
		scrollPane_1.setBounds(180, 370, 300, 100);
		frmProjectAccessExtension.getContentPane().add(scrollPane_1);
		textPaneRole.setEditable(false);
		scrollPane_1.setViewportView(textPaneRole);
		textPaneRole.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		
		txtLoadingInProcess = new JTextField();
		txtLoadingInProcess.setBackground(Color.WHITE);
		txtLoadingInProcess.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		txtLoadingInProcess.setEditable(false);
		txtLoadingInProcess.setBorder(null);
		txtLoadingInProcess.setText("Loading .... ");
		txtLoadingInProcess.setBounds(217, 0, 98, 34);
		frmProjectAccessExtension.getContentPane().add(txtLoadingInProcess);
		txtLoadingInProcess.setColumns(10);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnClear.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				t1=0;
				textPaneProCode.setText("");
			}
		});
		btnClear.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnClear.setBackground(Color.WHITE);
		btnClear.setBounds(485, 218, 89, 23);
		frmProjectAccessExtension.getContentPane().add(btnClear);

		JButton btnClear_1 = new JButton("Clear");
		btnClear_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				t2=0;
				textPaneRole.setText("");
			}
		});
		btnClear_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnClear_1.setBackground(Color.WHITE);
		btnClear_1.setBounds(485, 404, 89, 23);
		frmProjectAccessExtension.getContentPane().add(btnClear_1);
		gifLabel.setBorder(new LineBorder(Color.LIGHT_GRAY));
		gifLabel.setBounds(315, 0, 70, 34);
		frmProjectAccessExtension.getContentPane().add(gifLabel);
		
		JLabel lblNewLabel = new JLabel("Note : Please select TML Manager L4 and above.");
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 10));
		lblNewLabel.setBounds(10, 112, 218, 14);
		frmProjectAccessExtension.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Project Access Request");
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(217, 45, 188, 23);
		frmProjectAccessExtension.getContentPane().add(lblNewLabel_1);
	}

	public int groupRoleVerificationCheck(String groups2, String roles2) 
	{
		int status          = 0;
		int check           = 0;
		int roleTotalCount  = 0;
		int userTotalFound  = 0;
		int found           = 0;
		
		String temp         = "";
		String userIdFound  = null;
		glbRolesAccess = "";
		
		System.out.println(" ************ groupRoleVerificationCheck Started ************ ");
		System.out.println(" -groups2 = "+groups2);
		System.out.println(" -roles2  =  "+roles2 );
				
		for(int i=0;i<roles2.length();i++)
		{
			if(roles2.charAt(i)==',')
			{
				roleTotalCount++;
				found  = 0;
				System.out.println(" -temp[if] = "+temp);
				try 
				{
					tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
					query                = (TCComponentQuery) tccomponentquerytype.find("Admin - Group/Role Membership");
					String[] qryEntry    = new String[] { "Group","Role"};
					String[] qryValues   = new String[] {groups2,temp};
					qryGroupRoleUser     = null;
					qryGroupRoleUser     = query.execute(qryEntry, qryValues);
					System.out.println("\n -qryGroupRoleUser.length = "+qryGroupRoleUser.length);
					
					if(qryGroupRoleUser.length == 0)
					{
						if(check ==0 )
						{
							glbRolesAccess = glbRolesAccess + temp;
							check = 1;
						}
						else
						{
							glbRolesAccess = glbRolesAccess + ","+temp;
						}
					}
					else
					{
						for(int j=0;j<qryGroupRoleUser.length;j++)
						{													    							
							userIdFound= qryGroupRoleUser[j].getStringProperty("object_string");					
							System.out.println("- userIdFound [Function if] = "+userIdFound);
							
							if(userIdFound.contains(LoggedInUser)==true)
							{
								userTotalFound++;								
								found = 1;
							}
						}						
						if(found == 0)
						{
							if(check ==0 )
							{
								glbRolesAccess = glbRolesAccess + temp;
								check = 1;
							}
							else
							{
								glbRolesAccess = glbRolesAccess + ","+temp;
							}
						}
					}
				}
				catch(TCException e)
				{
					System.out.println(" ****************** TC Exception Occurred while executing if in groupRoleVerificationCheck ******************");
				}
				catch(Exception e)
				{
					System.out.println(" ****************** TC Exception Occurred while executing if in groupRoleVerificationCheck ******************");
				}
				temp="";
			}
			else if(i+1 == roles2.length())
			{
				roleTotalCount++;
				found = 0;
				temp = temp+roles2.charAt(i);				
			    System.out.println(" -temp[else] = "+temp);
				
				try 
				{			
					tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
					query                = (TCComponentQuery) tccomponentquerytype.find("Admin - Group/Role Membership");
					String[] qryEntry    = new String[] { "Group","Role"};
					String[] qryValues   = new String[] {groups2,temp};
					qryGroupRoleUser     = null;
					qryGroupRoleUser     = query.execute(qryEntry, qryValues);
					System.out.println("\n -qryGroupRoleUser.length = "+qryGroupRoleUser.length);
					
					if(qryGroupRoleUser.length == 0)
					{
						if(check ==0 )
						{
							glbRolesAccess = glbRolesAccess + temp;
							check = 1;
						}
						else
						{
							glbRolesAccess = glbRolesAccess + ","+temp;
						}
					}
					else
					{
						for(int j=0;j<qryGroupRoleUser.length;j++)
						{													    							
							userIdFound= qryGroupRoleUser[j].getStringProperty("object_string");					
							System.out.println("- userIdFound [Function if] = "+userIdFound);
							
							if(userIdFound.contains(LoggedInUser)==true)
							{
								userTotalFound++;
								found = 1;
							}
						}
						if(found == 0)
						{
							if(check ==0 )
							{
								glbRolesAccess = glbRolesAccess + temp;
								check = 1;
							}
							else
							{
								glbRolesAccess = glbRolesAccess + ","+temp;
							}
						}
					}
				}
				catch(TCException e)
				{
					System.out.println(" ****************** TC Exception Occurred while executing else in groupRoleVerificationCheck ******************");
				}
				catch(Exception e)
				{
					System.out.println(" ****************** TC Exception Occurred while executing else in groupRoleVerificationCheck ******************");
				}
				temp="";
			}
			else
			{
				temp = temp+roles2.charAt(i);
			}
		}
		System.out.println(" - roleTotalCount = "+roleTotalCount);
		System.out.println(" - userTotalFound = "+userTotalFound);
		
		if(roleTotalCount == userTotalFound)
		{
			status = 1;
		}
		else
		{
			status = 0;
		}
					
		System.out.println(" ************ groupRoleVerificationCheck Ended ************ ");
		return (status);
	}
}
