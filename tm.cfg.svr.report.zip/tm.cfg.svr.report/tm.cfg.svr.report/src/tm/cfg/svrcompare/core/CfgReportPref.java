package tm.cfg.svrcompare.core;

public class CfgReportPref {
	
	public static final String INTERNAL_OPTION_SEPARATOR_STR="#";
	public static final String DISPLAY_OPTION_SEPARATOR_STR="/";
	
	public static final char INTERNAL_OPTION_SEPARATOR_CHR='#';
	public static final char DISPLAY_OPTION_SEPARATOR_CHR='/';

}
