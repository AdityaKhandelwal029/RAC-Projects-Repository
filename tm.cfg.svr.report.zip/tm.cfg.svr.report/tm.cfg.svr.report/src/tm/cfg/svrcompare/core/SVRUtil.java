package tm.cfg.svrcompare.core;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Set;
import java.util.TreeMap;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;

//import org.apache.poi.xslf.usermodel.TextAlign;
import org.apache.poi.xssf.usermodel.IndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.viewers.CheckboxTreeViewer;
import org.eclipse.swt.widgets.Display;


import tm.cfg.svr.report.ui.TreeTableNodeLine;



import com.cfg0.services.internal.loose.configurator.ConfiguratorManagementService;
import com.cfg0.services.internal.loose.configurator._2015_10.ConfiguratorManagement.ApplicationConfigExpression;
import com.cfg0.services.internal.loose.configurator._2015_10.ConfiguratorManagement.BusinessObjectConfigExpression;
import com.cfg0.services.internal.loose.configurator._2015_10.ConfiguratorManagement.GetVariantExpressionsResponse;
import com.cfg0.services.internal.loose.configurator.ConfiguratorManagementService;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.InterfaceAIFOperationExecutionListener;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.SoaUtil;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentCfg0ConfiguratorPerspective;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;
import com.teamcenter.rac.kernel.TCComponentVariantRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCExceptionPartial;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCUserService;
import com.teamcenter.rac.kernel.TCVariantService;
import com.teamcenter.rac.kernel.TCVariantService.SosEntry;
import com.teamcenter.rac.kernel.TCVariantService.StoredOptionValue;
import com.teamcenter.rac.kernel.variants.ExpressionEditModeEnum;
import com.teamcenter.rac.kernel.variants.GridExpression;
import com.teamcenter.rac.kernel.variants.GridSubExpression;
import com.teamcenter.rac.kernel.variants.IGridExpressionContainer;
import com.teamcenter.rac.kernel.variants.IOptionFamily;
import com.teamcenter.rac.kernel.variants.IOptionValue;
import com.teamcenter.rac.kernel.variants.IVariantConfigurable;
import com.teamcenter.rac.kernel.variants.IVariantConfiguratorAdapter;
import com.teamcenter.rac.kernel.variants.IVariantExpressionContainer;
import com.teamcenter.rac.kernel.variants.GridSubExpression.GridExpressionSelection;
import com.teamcenter.rac.pca.common.ConfigExpressionHelper;
import com.teamcenter.rac.pca.model.SavedVariantRule;
import com.teamcenter.rac.pca.operations.GetVariantCriteriaOperation;
import com.teamcenter.rac.pca.operations.LoadExpEditorContentFromFormulaOperation;
import com.teamcenter.rac.pca.operations.LoadExpressionEditorContentOperation;
import com.teamcenter.rac.pca.operations.LoadExpressionEditorContentOperation.GridRefreshModeEnum;
import com.teamcenter.rac.pse.common.BOMLineNode;
import com.teamcenter.rac.treetable.TreeTableNode;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.soa.client.model.ModelObject;


public class SVRUtil {

	//private ArrayList<TreeTableNodeLine> bomlist;

	private ConfiguratorManagementService localConfiguratorManagementService;
	private TCComponentRevisionRule localTCComponentRevisionRule;
	private TCComponent[] variantRules;
	//private TCComponentBOMLine bl;
	private List<TCComponentSavedVariantRule> m_savedVariantRules;
	private TCComponentCfg0ConfiguratorPerspective m_configPerspective;
	private Map<TCComponentSavedVariantRule, GridExpression> m_ruleExpressionMap = new HashMap();
	private Map<IOptionFamily, LinkedHashSet<IOptionValue>> m_familyToValueMap = new HashMap();
	private LinkedHashMap<IOptionFamily, LinkedHashSet<IOptionValue>> svrrulemap;
	private Map<IOptionFamily, LinkedHashSet<IOptionValue>> all_svrrulemap;
	private Map<GridExpression,Map<IOptionFamily, LinkedHashSet<IOptionValue>>> m_gridexptofamilyToValueMap = new TreeMap();
	private Map<TCComponentSavedVariantRule,Map<GridExpression,Map<IOptionFamily, LinkedHashSet<IOptionValue>>>> m_rule_gridexptofamilyToValueMap = new HashMap();
	;
	private TCSession localTCSession;
	private TCComponentItemRevision platformRevision;
	private TCComponentSavedVariantRule svarrule;
	
	private TCComponentSavedVariantRule anysvrrule;
	private int maxheader;


	private TreeMap<IVariantExpressionContainer,LoadExpressionEditorContentOperation>  localObjectOpList ;
	private TreeMap<BOMLineNode,IVariantExpressionContainer>  localObjectOpList1 ;
	private TreeMap<TCComponentItemRevision, BOMFamilyMap> m_bom_familyToOptionValuesMap;

	public Map<TCComponentItem,Map<IOptionFamily,LinkedHashSet<IOptionValue>>> exptype_fam_val;//=new TreeMap<TCComponentItem,TreeMap<IOptionFamily,IOptionValue>>();
	public Map<TCComponentItem,Map<IOptionFamily, LinkedHashSet<IOptionValue>>> exptype_fam_val1;//=new TreeMap<TCComponentItem,Map<IOptionFamily, LinkedHashSet<IOptionValue>>>();

	private TCComponentBOMLine bl1 = null;
	private int rownum=1;
	private ArrayList<TCComponentSavedVariantRule> svrrules;
	LinkedHashMap<IOptionFamily,LinkedHashSet<IOptionValue>> matchoptval;

	private int childSrlNo;
	private TCComponentRevisionRule[] allrevrule;
	private String revRuleSelected;
	private String closureRuleSelected;
	private String viewSelected;
	private LinkedHashMap<String,LinkedHashMap<TCComponentSavedVariantRule,LinkedHashSet<String>>> arc_svr_bom_map;
	private LinkedHashMap<String,LinkedHashMap<TCComponentSavedVariantRule,Integer>> arc_svr_bom_map_size;
	private LinkedHashMap<String, LinkedHashSet<String>> ref_arc_bom_map;
	private boolean isAllOption;

	public SVRUtil()
	{
		
		exptype_fam_val=new HashMap<TCComponentItem,Map<IOptionFamily,LinkedHashSet<IOptionValue>>>();
		exptype_fam_val1=new HashMap<TCComponentItem,Map<IOptionFamily, LinkedHashSet<IOptionValue>>>();
		m_savedVariantRules= new ArrayList<TCComponentSavedVariantRule>();
		arc_svr_bom_map=new LinkedHashMap<String,LinkedHashMap<TCComponentSavedVariantRule,LinkedHashSet<String>>>();
		maxheader=0;

	}

	
	
	
	
	
	public boolean isAllOption() {
		return isAllOption;
	}






	public void setAllOption(boolean isAllOption) {
		this.isAllOption = isAllOption;
	}






	public String getRevRuleSelected() {
		return revRuleSelected;
	}






	public void setRevRuleSelected(String revRuleSelected) {
		this.revRuleSelected = revRuleSelected;
	}






	





	public String getClosureRuleSelected() {
		return closureRuleSelected;
	}






	public void setClosureRuleSelected(String closureRuleSelected) {
		this.closureRuleSelected = closureRuleSelected;
	}


	public void setViewSelected(String viewSelected) {
		this.viewSelected = viewSelected;
	}




	public TCComponentItemRevision getPlatformRevision() {
		return platformRevision;
	}




	public void setPlatformRevision(TCComponentItemRevision platformRevision) {
		this.platformRevision = platformRevision;
	}


	


	public TCComponentRevisionRule[] getAllRevRules() {
		return allrevrule;
	}




	protected LoadExpressionEditorContentOperation getLoadEditorContentOperation(List<IVariantExpressionContainer> paramList, LoadExpressionEditorContentOperation.GridRefreshModeEnum paramGridRefreshModeEnum)
	{
		LoadExpEditorContentFromFormulaOperation localLoadExpEditorContentFromFormulaOperation = new LoadExpEditorContentFromFormulaOperation(this.m_configPerspective, paramList, paramGridRefreshModeEnum, /*false*/true);
		return localLoadExpEditorContentFromFormulaOperation;
	}

	private TCComponentSavedVariantRule getMatchedTCComponent(List<TCComponentSavedVariantRule> paramList, TCComponentSavedVariantRule paramTCComponentSavedVariantRule)
			throws TCException
			{
		String str1 = paramTCComponentSavedVariantRule.getProperty("fnd0objectId");
		Iterator localIterator = paramList.iterator();
		while (localIterator.hasNext())
		{
			TCComponentSavedVariantRule localTCComponentSavedVariantRule = (TCComponentSavedVariantRule)localIterator.next();
			String str2 = localTCComponentSavedVariantRule.getProperty("fnd0objectId");
			if (str1.equalsIgnoreCase(str2)) {
				return localTCComponentSavedVariantRule;
			}
		}
		return null;
			}

	public void setSVR(TCComponentSavedVariantRule svrule)
	{

		svarrule=svrule;


	}
	
	public static TCComponent[] queryDB(String queryname ,String []qryNames,String []qryValues) throws TCException
	 {

		// dbObjects=new ArrayList<String>();
		 System.out.println(" In Query for class ::"+queryname);  
		 TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();		        
		 try {
			 System.out.println(" Before setting the session ::");  
			 TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");                     
			 TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);//"Item...");
			 System.out.println(" After setting the session ::");                                                 
			 TCComponent []qryResults          = null;
			 
			 for(String n1:qryNames)
				 System.out.println(n1);
			 for(String v1:qryValues)
				  System.out.println(v1);

			 if (mmcomponentquery != null)				     
			 {
				 
				 qryResults=mmcomponentquery.execute(qryNames,qryValues);
				 System.out.println(" Results found size::"+ qryResults.length); 
				
			 }

			 return   qryResults;

		 } catch (TCException e2) {
			 // TODO Auto-generated catch block
			 e2.printStackTrace();
		 }

		 return null; 
	 }		
	
	public TCComponentSavedVariantRule setAnySVR() throws TCException
	{
	TCComponent[] obj=queryDB("General...",new String[]{"Type","Name"},new String[]{"VariantRule","*"});//54427424000R_NR
	if(obj!=null)
	{
	anysvrrule=(TCComponentSavedVariantRule) obj[0];
	 return anysvrrule;
	}
	return null;
	}
	
	public TCComponentSavedVariantRule getAnySVR()
	{
	
	 return anysvrrule;
	}

	public TCComponentSavedVariantRule getSVR()
	{

		return svarrule;


	}

	
	public TCComponentRevisionRule[] getAllRevRule(TCSession tcsession) throws TCException
	{
		

		System.out.println("Listing All Revision Rule");
		
		allrevrule=TCComponentRevisionRule.listAllRules(tcsession);
		/*String revrulename="Latest Working";
		
		for(int j=0;j<revrule.length;j++)
		{
			
			if(revrulename.equals(revrule[j].getProperty("object_name")))
			{
				currentrevrule=revrule[j];
					break;
			}
			
			//System.out.println(revrulename);
			
		}
		
		System.out.println("Found the Revision Rule "+revrulename);
		*/
		
		return allrevrule;
		
	}
	
	
	public TCComponent[] getAllSVRs(TCComponentItemRevision assemblyRevision)
	 {
		 
		 TCComponent[] rule = null;
		try {
			rule = assemblyRevision.getItem().getTCProperty("Smc0HasVariantConfigContext").getReferenceValueArray()[0].getTCProperty("IMAN_reference").getReferenceValueArray();
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 return rule;
	 }
	
	public  TCComponentBOMLine getParentBOMLine(TCComponentItemRevision assemblyRevision) throws TCException
    {
		TCSession tcsession=assemblyRevision.getSession();
		TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
        TCComponentBOMWindow bomWin = bowWinType.create(null);       // create bom window configured with the default revision rule 
      
        TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, null);
        
        return bl;
		
    }
	
	protected GetVariantCriteriaOperation getVariantCriteriaOperation(List<TCComponentSavedVariantRule> paramList)
	{
		GetVariantCriteriaOperation localVariantCriteriaOperationOperation = new GetVariantCriteriaOperation( paramList,this.m_configPerspective);
		return localVariantCriteriaOperationOperation;
	}
	
	public LinkedHashMap<IOptionFamily,LinkedHashMap<TCComponentSavedVariantRule,LinkedHashSet<IOptionValue>>> getSVRRuleData(String fullpath,TreeTableNodeLine refsvr,Object[] bomnode1,final CheckboxTreeViewer treeViewer,final boolean allselected) throws TCException, ServiceException
	{

		//	 this.assemblyRevision=assemblyRevision;
		
		
		
		 arc_svr_bom_map= new LinkedHashMap<String,LinkedHashMap<TCComponentSavedVariantRule,LinkedHashSet<String>>>();
		 
		 arc_svr_bom_map_size= new LinkedHashMap<String,LinkedHashMap<TCComponentSavedVariantRule,Integer>>();
		
		 LinkedHashMap<String,String> ref_opt_val_map=new LinkedHashMap<String,String>();
		
		 final LinkedHashMap<IOptionFamily,LinkedHashMap<TCComponentSavedVariantRule,LinkedHashSet<IOptionValue>>> opt_svr_valmap=new LinkedHashMap<IOptionFamily,LinkedHashMap<TCComponentSavedVariantRule,LinkedHashSet<IOptionValue>>>();
			
			LinkedHashMap<TCComponentSavedVariantRule,TreeTableNodeLine> svr_treetabmap=new LinkedHashMap<TCComponentSavedVariantRule,TreeTableNodeLine>();
			
		
		this.matchoptval=new LinkedHashMap<IOptionFamily,LinkedHashSet<IOptionValue>>();
		
		 svrrules=new ArrayList<TCComponentSavedVariantRule>();
		 
		 TCComponentSavedVariantRule refsvrrule=refsvr.getSvrrule();
		 
		// this.svrrules.add(refsvrrule);
		// svr_treetabmap.put(refsvrrule, refsvr);
		 
		 TreeTableNodeLine[] bomnode=new TreeTableNodeLine[bomnode1.length+1];
		 int svrnode_cnt=0;
		 bomnode[svrnode_cnt++]=refsvr;
		 
		 for(int t=0;t<bomnode1.length;t++)
			{
		 
			 bomnode[svrnode_cnt++]=(TreeTableNodeLine) bomnode1[t];
		 
			}
		for(int k=0;k<bomnode.length;k++)
		{
			//Object bomtreeNode=((TreeNode) bomnode[k]).getValue();
			childSrlNo=k;
			
			final TreeTableNodeLine treelineNode=(TreeTableNodeLine) bomnode[k];
			
			final TCComponentSavedVariantRule srule=treelineNode.getSvrrule();
			this.svarrule=srule;
			svrrules.add(srule);
			svr_treetabmap.put(srule, treelineNode);
			/*
			Thread thread = new Thread(new Runnable() {
				 @Override
			        public void run() {
			*/ 
		
			
		
		
		

		// LinkedHashMap<TCComponentSavedVariantRule,LinkedHashMap<IOptionFamily, LinkedHashSet<IOptionValue>>> m_ruletofamilyToValueMap = new LinkedHashMap<TCComponentSavedVariantRule,LinkedHashMap<IOptionFamily, LinkedHashSet<IOptionValue>>>();

		localTCSession = m_configPerspective.getSession();
		m_savedVariantRules=new ArrayList<TCComponentSavedVariantRule>();
		svrrulemap=new LinkedHashMap<IOptionFamily, LinkedHashSet<IOptionValue>>();
		all_svrrulemap=new LinkedHashMap<IOptionFamily, LinkedHashSet<IOptionValue>>();

		//  m_configPerspective = (TCComponentCfg0ConfiguratorPerspective)bl.getConfiguratorContext().getReferenceProperty("cfg0ConfigPerspective");

		localConfiguratorManagementService = ConfiguratorManagementService.getService(localTCSession.getSoaConnection());
		localTCComponentRevisionRule = m_configPerspective.getRevisionRule();
		variantRules=m_configPerspective.getVariantRules();
		//  System.out.println(bl.getConfiguratorContext().toDisplayString()+":localTCComponentCfg0ConfiguratorPerspective::"+m_configPerspective.toDisplayString());

		System.out.println("CHECK m_savedVariantRules::"+this.svarrule);	
		m_savedVariantRules.clear();
		m_savedVariantRules.add(svarrule);
		System.out.println("CHECK m_savedVariantRules::");
		if ((this.m_savedVariantRules == null) || (this.m_savedVariantRules.isEmpty())) {
			System.out.println("Empty m_savedVariantRules::");
			return opt_svr_valmap;
		}
		else
		{
			System.out.println("NOT Empty m_savedVariantRules::");
		}
		ModelObject[] arrayOfModelObject = (ModelObject[])this.m_savedVariantRules.toArray(new TCComponent[0]);
		ConfiguratorManagementService localConfiguratorManagementService = ConfiguratorManagementService.getService(localTCSession.getSoaConnection());
		TCComponentRevisionRule localTCComponentRevisionRule = this.m_configPerspective.getRevisionRule();
		GetVariantExpressionsResponse localGetVariantExpressionsResponse = localConfiguratorManagementService.getVariantExpressions(arrayOfModelObject, localTCComponentRevisionRule);
		BusinessObjectConfigExpression[] arrayOfBusinessObjectConfigExpression1 = localGetVariantExpressionsResponse.configObjectExpressions;
		if ((arrayOfBusinessObjectConfigExpression1 != null) && (arrayOfBusinessObjectConfigExpression1.length > 0))
		{
			HashMap<IOptionFamily, LinkedHashSet<IOptionValue>> localHashMap = new HashMap<IOptionFamily, LinkedHashSet<IOptionValue>>();
			for (BusinessObjectConfigExpression localBusinessObjectConfigExpression : arrayOfBusinessObjectConfigExpression1)
			{
				TCComponentSavedVariantRule localTCComponentSavedVariantRule = (TCComponentSavedVariantRule)localBusinessObjectConfigExpression.targetObject;
				System.out.println("localTCComponentSavedVariantRule::"+localTCComponentSavedVariantRule.toDisplayString()+":"+localTCComponentSavedVariantRule.getDescription());
				final TreeTableNodeLine treelineNode1=svr_treetabmap.get(localTCComponentSavedVariantRule);
				Display.getDefault().syncExec(new Runnable()
		        {
		          public void run()
		          {
		        	  treelineNode1.setStatus("Executing");
		        	  treeViewer.update(treelineNode1, null);
		        	  treeViewer.refresh();
		        	  
		          }
		        });

				
				////SOLVED BOM
				
				
				
				LinkedHashMap<String, LinkedHashSet<String>> arc_bom_map= this.getSolvedBOMITK(svarrule);
			//	LinkedHashMap<String, LinkedHashSet<String>> arc_bom_map= new LinkedHashMap<String, LinkedHashSet<String>>();
				
				if(k==0)
					ref_arc_bom_map=	arc_bom_map;
				
				
				for(Entry<String, LinkedHashSet<String>> entry_arc_bom : arc_bom_map.entrySet())
				{
					
					String arc_node_val=entry_arc_bom.getKey();
				
					LinkedHashSet<String> bom_vl_set=entry_arc_bom.getValue();
					
					LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<String>> svr_bom_map= arc_svr_bom_map.get(arc_node_val);
				
					if(svr_bom_map==null)
					{
						svr_bom_map=new LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<String>>();
						arc_svr_bom_map.put(arc_node_val, svr_bom_map);
					}
					svr_bom_map.put(svarrule, bom_vl_set);
					//arc_svr_bom_map.put(arc_node_val, svr_bom_map);
					
					
					
					
					LinkedHashMap<TCComponentSavedVariantRule, Integer> svr_bom_map_size= arc_svr_bom_map_size.get(arc_node_val);
					
					if(svr_bom_map_size==null)
					{
						svr_bom_map_size=new LinkedHashMap<TCComponentSavedVariantRule, Integer>();
						arc_svr_bom_map_size.put(arc_node_val, svr_bom_map_size);
						
					}
					svr_bom_map_size.put(svarrule, new Integer(bom_vl_set.size()));
					//arc_svr_bom_map_size.put(arc_node_val, svr_bom_map_size);
				}
				//////
				
				ArrayList<TCComponentSavedVariantRule> svrlist=new ArrayList<TCComponentSavedVariantRule>();
				
				svrlist.add(this.svarrule);
				
				final GetVariantCriteriaOperation localObjectOp1=    getVariantCriteriaOperation(svrlist);
				((GetVariantCriteriaOperation)localObjectOp1).addOperationListener(new InterfaceAIFOperationExecutionListener()
				{
					public void startOperation(String paramAnonymousString) {}

					public void endOperation()
					{
						//Display.getDefault().asyncExec(new Runnable()
						Display.getDefault().syncExec(new Runnable()
						{
							public void run()
							{

								
									Map<IOptionFamily, LinkedHashSet<IOptionValue>> m_familyToOptionValuesMap =localObjectOp1.getUnconfiguredVariabilityMap();
									
									//Map<TCComponentSavedVariantRule, GridExpression> m_grid_exp= localObjectOp1.getRuleExpressionMap();
									Map<IVariantExpressionContainer, GridExpression> m_grid_exp= localObjectOp1.getRuleExpressionMap();
									
									
									for (Entry<IVariantExpressionContainer, GridExpression> grid_var_entry : m_grid_exp.entrySet())  
									{
										TCComponentSavedVariantRule varexp=(TCComponentSavedVariantRule) grid_var_entry.getKey();
										GridExpression gridexp=grid_var_entry.getValue();

										System.out.println("Printing VAR EXP Values **************");
										System.out.println("varexp Text:::"+ varexp.getTextRepresentation());
										System.out.println("varexp Type:::"+ varexp.getExpressionType());
										/*List<ExpressionEditModeEnum> varlistedit=varexp.getExpressionEditModes();
										for(int r=0;r<varlistedit.size();r++)
										{
											System.out.println(varlistedit.get(r).getCode()+":"+":varexp EDIT Mode::"+varlistedit.get(r).toString());
										}
										System.out.println("Printing END  VAR EXP Values **************");

		*/
										System.out.println("Printing GRID EXP Values **************");
										// System.out.println("gridexp getExpressionState:::"+ gridexp.getExpressionState().name());
										System.out.println("gridexp Type:::"+ gridexp.getContainer().toString());
							
										

									List<GridSubExpression> gridsubexp=gridexp.getSubExpressions();
									for(int r=0;r<gridsubexp.size();r++)
									{
										GridSubExpression subexp=gridsubexp.get(r);

										Set localSet2 = subexp.get().keySet();
										if ((localSet2 != null) && (localSet2.size() > 0))
										{
											Iterator localIterator3 = localSet2.iterator();
											while (localIterator3.hasNext())
											{
												IOptionValue localIOptionValue = (IOptionValue)localIterator3.next();
												if (localIOptionValue != null)
												{
													IOptionFamily localIOptionFamily = localIOptionValue.getOptionFamily();

													LinkedHashSet<IOptionValue> svrfamval=svrrulemap.get(localIOptionFamily);
													if(svrfamval==null)
													svrfamval=new  LinkedHashSet<IOptionValue>();
													svrfamval.add(localIOptionValue);
													svrrulemap.put(localIOptionFamily, svrfamval);

													System.out.println("SVR subexp::"+localIOptionFamily.getName()+":"+localIOptionValue.getObjectName());

													
													
													LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>> svr_opvalmap=opt_svr_valmap.get(localIOptionFamily);
													
													if(svr_opvalmap==null)
													{
														
														svr_opvalmap=new LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>>();
													}
													
													svr_opvalmap.put(srule, svrfamval);
													
													opt_svr_valmap.put(localIOptionFamily, svr_opvalmap);
													
												}
											}
										}
									}
										//m_familyToOptionValuesMap_f.putAll(svr_svrrulemap);
									}
									//m_familyToOptionValuesMap_f.putAll(m_familyToOptionValuesMap);
									
										//svrrulemap.putAll(svr_svrrulemap);
									
										System.out.println("NOT NULL MAP ::->>>>>>>>>>");

										System.out.println("START MAP ::->>>>>>>>>>");
										for (Map.Entry<IOptionFamily, LinkedHashSet<IOptionValue>> entry2 : svrrulemap.entrySet())  
										{
											IOptionFamily optionFamily=entry2.getKey();
											LinkedHashSet<IOptionValue> optionSet=entry2.getValue();

											System.out.println("OptionFamily::"+optionFamily.getName());


											Iterator<IOptionValue> iterator = optionSet.iterator(); 


											while (iterator.hasNext()) 
											{
												IOptionValue optionvalue=	iterator.next();
												System.out.println("Option Value::"+optionvalue.getObjectName());
											}

										} 
										System.out.println("END MAP ::->>>>>>>>>>");
									}
									
								});  

					}

					@Override
					public void exceptionThrown(Exception arg0) {
						// TODO Auto-generated method stub
						
						arg0.printStackTrace();
						
					}});

				try
				{
					localObjectOp1.setName("Processing "+srule.toDisplayString());
					localObjectOp1.getSession().queueOperation((Job)localObjectOp1);
					localObjectOp1.join();
				}
				catch (Exception localException)
				{
					// Logger.getLogger(getClass()).error(localException.getClass().getName(), localException);
					localException.printStackTrace();
				}

				
				
				/////
				
				
				ArrayList  localArrayList3=new ArrayList();

				/*System.out.println("GRIDEX getTextRepresentation::"+gridex.getTextRepresentation());
				System.out.println("GRIDEX getExpressionType::"+gridex.getExpressionType());
				System.out.println("GRIDEX isExpressionContainerEditable::"+gridex.isExpressionContainerEditable());
				System.out.println("SZZZ::"+gridex.getExpressionEditModes().size());
				IVariantExpressionContainer varex=(IVariantExpressionContainer)gridex;
				
				*/

				SavedVariantRule localSavedVariantRule = new SavedVariantRule();
			      localSavedVariantRule.setReferenceComponent(this.m_configPerspective.getProductItems()[0]);
			      localSavedVariantRule.setRuleName(srule.getName());
			      localSavedVariantRule.setDescription(srule.getDescription());
			      localSavedVariantRule.setComponent(srule);
			      
			      
			      
			      
			      IGridExpressionContainer localObject1= (IGridExpressionContainer)localSavedVariantRule;
			      
			      localArrayList3.add((IVariantExpressionContainer)localObject1);
				
				
			    // final Map<IOptionFamily, LinkedHashSet<IOptionValue>> m_familyToOptionValuesMap_f=new HashMap<IOptionFamily, LinkedHashSet<IOptionValue>>();

					final LoadExpressionEditorContentOperation localObjectOp=    getLoadEditorContentOperation(localArrayList3, GridRefreshModeEnum.CONTAINERS_ONLY/*GridRefreshModeEnum.CONTAINERS_ONLY,GridRefreshModeEnum.ALL*/);
					((LoadExpressionEditorContentOperation)localObjectOp).addOperationListener(new InterfaceAIFOperationExecutionListener()
					{
						public void startOperation(String paramAnonymousString) {}

						public void endOperation()
						{
							//Display.getDefault().asyncExec(new Runnable()
							Display.getDefault().syncExec(new Runnable()
							{
								public void run()
								{
									//Map<IOptionFamily, LinkedHashSet<IOptionValue>> 
									//if(allselected)
									all_svrrulemap.putAll(localObjectOp.getLoadedFamilies());
									
									
		////
									
									
									Map<ExpressionEditModeEnum, LinkedHashMap<IVariantExpressionContainer, GridExpression>> m_expEditModeToVariantExpMap = localObjectOp.getLoadedVEByEditMode();
									
									System.out.println("getLoadedVEByEditMode::"+m_expEditModeToVariantExpMap.size());

									for (Map.Entry<ExpressionEditModeEnum, LinkedHashMap<IVariantExpressionContainer, GridExpression>> entry1 : m_expEditModeToVariantExpMap.entrySet())  
									{
										ExpressionEditModeEnum expEditMode=entry1.getKey();
										LinkedHashMap<IVariantExpressionContainer, GridExpression> grid_var_map=entry1.getValue();
										System.out.println("expEditMode::"+expEditMode.toString());
										System.out.println("getLoadedVEByEditMode2::"+grid_var_map.size());
										

										for (Map.Entry<IVariantExpressionContainer, GridExpression> grid_var_entry : grid_var_map.entrySet())  
										{
											IVariantExpressionContainer varexp=grid_var_entry.getKey();
											GridExpression gridexp=grid_var_entry.getValue();
											System.out.println("IVariantExpressionContainer::"+varexp.toString());
							
									List<GridSubExpression> gridsubexp=gridexp.getSubExpressions();
									System.out.println("gridsubexp::"+gridsubexp.size());
									for(int r=0;r<gridsubexp.size();r++)
									{
										GridSubExpression subexp=gridsubexp.get(r);
										System.out.println("GridSubExpression::"+subexp.toString());

										Set localSet2 = subexp.get().keySet();
										System.out.println("localSet2.size()::"+localSet2.size());
										if ((localSet2 != null) && (localSet2.size() > 0))
										{
											
											Iterator localIterator3 = localSet2.iterator();
											while (localIterator3.hasNext())
											{
												IOptionValue localIOptionValue = (IOptionValue)localIterator3.next();
												if (localIOptionValue != null)
												{
													IOptionFamily localIOptionFamily = localIOptionValue.getOptionFamily();

													LinkedHashSet<IOptionValue> svrfamval=svrrulemap.get(localIOptionFamily);
													if(svrfamval==null)
													svrfamval=new  LinkedHashSet<IOptionValue>();
													svrfamval.add(localIOptionValue);
													svrrulemap.put(localIOptionFamily, svrfamval);

													System.out.println("xxSVR subexp::"+localIOptionFamily.getName()+":"+localIOptionValue.getObjectName());

													
													
													
												}
											}
										}
									}
									
									}	
									}
									
									
								//	svrrulemap.putAll(svr_svrrulemap);
									/////
									
									
									
									//m_familyToOptionValuesMap_f.putAll(all_svrrulemap);
									
									
									
									
									
									for (Map.Entry<IOptionFamily, LinkedHashSet<IOptionValue>> svrrulemapall_ent : all_svrrulemap.entrySet())  
									{
										IOptionFamily localIOptionFamily1=svrrulemapall_ent.getKey();
										System.out.println("xx1111ALL OptionFamily::"+localIOptionFamily1.getName());
										LinkedHashSet<IOptionValue> opval_set=svrrulemap.get(localIOptionFamily1);
										if(opval_set==null)
										{
											opval_set=new LinkedHashSet<IOptionValue>();
											svrrulemap.put(localIOptionFamily1, opval_set);
											
											System.out.println("BLANK yy1111ALLOption Value::"+localIOptionFamily1.getName());
										}
										else
										{
											System.out.println("zzz1111ALLOption Value::"+localIOptionFamily1.getName()+":"+opval_set.toString());
										}
										
										
										LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>> svr_opvalmap=opt_svr_valmap.get(localIOptionFamily1);
										
										if(svr_opvalmap==null)
										{
											
											svr_opvalmap=new LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>>();
										}
										
										svr_opvalmap.put(srule, opval_set);
										
										opt_svr_valmap.put(localIOptionFamily1, svr_opvalmap);
										
									}
									
									
									

									//Map<ExpressionEditModeEnum, LinkedHashMap<IVariantExpressionContainer, GridExpression>> m_expEditModeToVariantExpMap = localObjectOp.getLoadedVEByEditMode();

								}
							});
						}    

						@Override
						public void exceptionThrown(Exception arg0) {
							// TODO Auto-generated method stub
							arg0.printStackTrace();

						}   
					} );

					try
					{

						localObjectOp.setName("Processing "+srule.toDisplayString());
						localObjectOp.getSession().queueOperation((Job)localObjectOp);
						localObjectOp.join();
					}
					catch (Exception localException)
					{
						// Logger.getLogger(getClass()).error(localException.getClass().getName(), localException);
						localException.printStackTrace();
					}
					
				
				
				
				
				
				//////
				
				
				
				// m_ruletofamilyToValueMap.put(matchedrule,svrrulemap);
				 Display.getDefault().syncExec(new Runnable()
			        {
			          public void run()
			          {
			        	  treelineNode1.setStatus("Completed");
			        	  treeViewer.update(treelineNode1, null);
			        	  treeViewer.refresh();
			        	  
			          }
			        });
			}
			
			
		}
		SoaUtil.handlePartialErrors(localGetVariantExpressionsResponse.serviceData, null, null, true);
		
		}
		
		
		for(Entry<IOptionFamily, LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>>> entry_0 : opt_svr_valmap.entrySet())
		{
			
			IOptionFamily fam=entry_0.getKey();
			LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>> svr_opval=entry_0.getValue();
			LinkedHashSet<IOptionValue> op_vl_set=svr_opval.get(refsvrrule);
			
			String opt_val_str="";
			if(op_vl_set!=null)
			{
			Iterator<IOptionValue> op_vl_set_it=op_vl_set.iterator();
			while(op_vl_set_it.hasNext())
			{
				
				IOptionValue op_val=op_vl_set_it.next();
				if(opt_val_str.length()>0)
					opt_val_str+=CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR;
				
				opt_val_str+=op_val.getObjectName();
				
			}
			
			}
			ref_opt_val_map.put(fam.getName(), opt_val_str);
			
		}
	
		/*
		 //FOR UNIQUE MATCH --WORKING FINE
		for(Entry<IOptionFamily, LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>>> entry_0 : opt_svr_valmap.entrySet())
		{
			
			IOptionFamily fam=entry_0.getKey();
			LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>> svr_opval=entry_0.getValue();
			
			//LinkedHashSet<IOptionValue> unqmatch=this.matchoptval.get(fam);
			//if(unqmatch==null)
				LinkedHashSet<IOptionValue> unqmatch=new LinkedHashSet<IOptionValue>();
			
			Collection<LinkedHashSet<IOptionValue>> all_opt=	svr_opval.values();
			
			Iterator<LinkedHashSet<IOptionValue>> all_opt_it=	all_opt.iterator();
			
			while(all_opt_it.hasNext())
				unqmatch.addAll(all_opt_it.next());
			
			for(Entry<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>> entry_1 : svr_opval.entrySet())
			{
				
				
				TCComponentSavedVariantRule svrobj=entry_1.getKey();
				LinkedHashSet<IOptionValue> opvalSet=entry_1.getValue();
				Iterator<IOptionValue> iterator = opvalSet.iterator(); 
				
				ArrayList<IOptionValue> del_val=new ArrayList<IOptionValue>();
				
				Iterator<IOptionValue> unqmatch_It = unqmatch.iterator(); 
				
				while(unqmatch_It.hasNext())
				{
					IOptionValue optionvalue1=	unqmatch_It.next();
					
					if(opvalSet.contains(optionvalue1)==false)
						del_val.add(optionvalue1);
					
					
				}
				
				for(int d=0;d<del_val.size();d++)
				{
				
					
						unqmatch.remove(del_val.get(d));
						
					
				}
				
				while (iterator.hasNext()) 
				{
					IOptionValue optionvalue=	iterator.next();
				
					
					System.out.println("SVR Option Value00::"+fam.getName()+":"+svrobj.toDisplayString()+":"+optionvalue.getObjectName());
					
					
				}
				
				
				
				
			}
			
			
			this.matchoptval.put(fam, unqmatch);
			
			
		}
*/
/*
		for(int r=0;r<svrrules.size();r++)
		{
			
			
		TCComponentSavedVariantRule svr_rule_val=	svrrules.get(r)	;
		
		System.out.println("Getting Value:::"+ svr_rule_val.toDisplayString());
		
		Map<IOptionFamily, LinkedHashSet<IOptionValue>> svr_exp_opt_map=m_ruletofamilyToValueMap.get(svr_rule_val);
		if(svr_exp_opt_map!=null)
		{
		for (Entry<IOptionFamily, LinkedHashSet<IOptionValue>> entry1 : svr_exp_opt_map.entrySet())  
		{
		
		//for(Entry<GridExpression, Map<IOptionFamily, LinkedHashSet<IOptionValue>>> entry : svr_exp_opt_map.entrySet())
		{
			{
				
				
				IOptionFamily	optionFamily =	entry1.getKey()	;
			System.out.println("SVR OptionFamily::"+optionFamily.getName());

			Set<IOptionValue> optionSet=entry1.getValue();

			Iterator<IOptionValue> iterator = optionSet.iterator(); 


			while (iterator.hasNext()) 
			{
				IOptionValue optionvalue=	iterator.next();
				System.out.println("SVR Option Value::"+optionvalue.getObjectName());
			}
			}
		} 
		
		}	
		}
		else
		{
			
			System.out.println("NO SVR Option Value::");
		}
		}*/
		
		
		
		try {
			writeToXLS( fullpath, opt_svr_valmap,ref_opt_val_map, svrrules) ;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return opt_svr_valmap;
	}

	
	
	
	public static TCComponent []  queryObjTCUA(String queryname,String type,String [] qryNames,String [] qryValues) throws TCException
	{

		
		TCSession tcsession=(TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		
		com.teamcenter.rac.kernel.TCComponentContextList imancomponentcontextlist = null;
		

		TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");

		TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find(queryname);

		TCComponent []qryResults	= null;
		
		


		if (mmcomponentquery != null)

		{
			System.out.println(" In Query for qryValues ::"+qryValues[0]);
			System.out.println(" In Query for qryNames ::"+qryNames[0]);
			
			qryResults=mmcomponentquery.execute( qryNames, qryValues );

			
		}
		return qryResults;

	}
	

	public void setCfg0Perspective( TCComponentBOMLine parentbl)
	{
		TCComponentCfg0ConfiguratorPerspective localTCComponentCfg0ConfiguratorPerspective = null;//(TCComponentCfg0ConfiguratorPerspective)((IVariantConfiguratorAdapter)localObject).getVariantConfiguratorContext().getReferenceProperty("cfg0ConfigPerspective");

		if(localTCComponentCfg0ConfiguratorPerspective==null)
		{

			try {
				localTCComponentCfg0ConfiguratorPerspective= (TCComponentCfg0ConfiguratorPerspective)parentbl.getConfiguratorContext().getReferenceProperty("cfg0ConfigPerspective");

				System.out.println("localTCComponentCfg0ConfiguratorPerspective NIVA::"+localTCComponentCfg0ConfiguratorPerspective.toDisplayString());
				this.m_configPerspective=localTCComponentCfg0ConfiguratorPerspective;
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else
		{
			System.out.println("localTCComponentCfg0ConfiguratorPerspective IVA::"+localTCComponentCfg0ConfiguratorPerspective.toDisplayString());
		}

	}
/*
	public void processModuleOptionValues(TCComponentItemRevision itemrev,boolean incolor)
	{


		System.out.println("itemrev11::"+itemrev.toDisplayString());
		BOMLineNode localBOMLineNode3=null;
		TCComponentBOMLine bl1 = null;
		Object localObject = null ;
		try {

			Map<TCComponentBOMLine ,ArrayList<TreeTableNodeLine>> bl_children1=bomExpansion.getTCUAStructure(itemrev.getSession(), itemrev,incolor);



			System.out.println("itemrev12::"+bl_children1.size());
			for (Map.Entry<TCComponentBOMLine ,ArrayList<TreeTableNodeLine>> entry1 : bl_children1.entrySet())  
			{
				bl1=entry1.getKey();
				ArrayList<TreeTableNodeLine> children1=entry1.getValue();

				System.out.println("itemrev123::"+children1.size());


				for(int s=0;s<children1.size();s++)
				{
					//childSrlNo=s;
					final TCComponentBOMLine bl2=children1.get(s).getBomline();
					localBOMLineNode3=new BOMLineNode(bl2);
					System.out.println("itemrev1234::"+localBOMLineNode3.toString());
					getModuleOptionValues( localBOMLineNode3);

				}
			}
		}catch(TCException e)
		{
		}

	}*/
	
	/*private void setBordersToMergedCells(XSSFWorkbook workBook, XSSFSheet sheet) {
		  
		  int regioncnt=sheet.getNumMergedRegions();
		  for (int k=0;k<regioncnt;k++) {
			  org.apache.poi.ss.util.CellRangeAddress cellRangeAddress =sheet.getMergedRegion(k);
			  RegionUtil.setBorderTop(CellStyle.BORDER_MEDIUM, cellRangeAddress, sheet, workBook);
			  RegionUtil.setBorderLeft(CellStyle.BORDER_MEDIUM, cellRangeAddress, sheet, workBook);
			  RegionUtil.setBorderRight(CellStyle.BORDER_MEDIUM, cellRangeAddress, sheet, workBook);
			  RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, cellRangeAddress, sheet, workBook);
		  }
		}
*/
	public void getModuleOptionValues(BOMLineNode localBOMLineNode3)
	{





		//Object bomtreeNode=((TreeNode) bomnode[k]).getValue();

		TCComponent localTCComponent = (TCComponent)AdapterUtil.getAdapter(localBOMLineNode3, TCComponent.class);
		IGridExpressionContainer gridex = null;
		if ((localBOMLineNode3 instanceof IGridExpressionContainer)) {
			gridex=(IGridExpressionContainer)localBOMLineNode3;
			System.out.println("IGRIDx1::"+gridex);
			//  localArrayList2.add((IGridExpressionContainer)localObject);
		} else if ((localTCComponent instanceof IGridExpressionContainer)) {
			gridex=(IGridExpressionContainer)localTCComponent;
			System.out.println("IGRIDx2::"+gridex);
			//  localArrayList2.add((IGridExpressionContainer)localTCComponent);

		}




		ArrayList  localArrayList3=new ArrayList();

		IVariantExpressionContainer varex=(IVariantExpressionContainer)gridex;

		localArrayList3.add(varex);



		final LoadExpressionEditorContentOperation localObjectOp=    getLoadEditorContentOperation(localArrayList3, /*GridRefreshModeEnum.FAMILIES_VALUES_ONLY*/GridRefreshModeEnum.ALL);
		((LoadExpressionEditorContentOperation)localObjectOp).addOperationListener(new InterfaceAIFOperationExecutionListener()
		{
			public void startOperation(String paramAnonymousString) {}

			public void endOperation()
			{
				Display.getDefault().asyncExec(new Runnable()
				{
					public void run()
					{

						Map<ExpressionEditModeEnum, LinkedHashMap<IVariantExpressionContainer, GridExpression>> m_expEditModeToVariantExpMap = localObjectOp.getLoadedVEByEditMode();

						for (Map.Entry<ExpressionEditModeEnum, LinkedHashMap<IVariantExpressionContainer, GridExpression>> entry1 : m_expEditModeToVariantExpMap.entrySet())  
						{
							ExpressionEditModeEnum expEditMode=entry1.getKey();
							LinkedHashMap<IVariantExpressionContainer, GridExpression> grid_var_map=entry1.getValue();



							for (Map.Entry<IVariantExpressionContainer, GridExpression> grid_var_entry : grid_var_map.entrySet())  
							{
								IVariantExpressionContainer varexp=grid_var_entry.getKey();
								GridExpression gridexp=grid_var_entry.getValue();

								System.out.println("Printing VAR EXP Values **************");
								System.out.println("varexp Text:::"+ varexp.getTextRepresentation());
								System.out.println("varexp Type:::"+ varexp.getExpressionType());
								List<ExpressionEditModeEnum> varlistedit=varexp.getExpressionEditModes();
								for(int r=0;r<varlistedit.size();r++)
								{
									System.out.println(varlistedit.get(r).getCode()+":"+":varexp EDIT Mode::"+varlistedit.get(r).toString());
								}
								System.out.println("Printing END  VAR EXP Values **************");


								System.out.println("Printing GRID EXP Values **************");
								// System.out.println("gridexp getExpressionState:::"+ gridexp.getExpressionState().name());
								System.out.println("gridexp Type:::"+ gridexp.getContainer().toString());


								List<GridSubExpression> gridsubexp=gridexp.getSubExpressions();
								for(int r=0;r<gridsubexp.size();r++)
								{
									GridSubExpression subexp=gridsubexp.get(r);

									Set localSet2 = subexp.get().keySet();
									if ((localSet2 != null) && (localSet2.size() > 0))
									{
										Iterator localIterator3 = localSet2.iterator();
										while (localIterator3.hasNext())
										{
											IOptionValue localIOptionValue = (IOptionValue)localIterator3.next();
											if (localIOptionValue != null)
											{
												IOptionFamily localIOptionFamily = localIOptionValue.getOptionFamily();

												System.out.println("subexp::"+localIOptionFamily.getName()+":"+localIOptionValue.getObjectName());

											}
										}
									}
									GridExpression gridexp2=subexp.getExpression();
									Map<IOptionValue, GridExpressionSelection> option_gridexp=subexp.get();

									for (Map.Entry<IOptionValue, GridExpressionSelection> entry3 : option_gridexp.entrySet())  
									{
										IOptionValue optionValue=entry3.getKey();
										GridExpressionSelection gridsel=entry3.getValue();

										if (optionValue != null)
										{
											IOptionFamily optionFamily = optionValue.getOptionFamily();

											System.out.println("GRID SEL subexp::"+optionFamily.getName()+":"+optionValue.getObjectName());

										}

										// System.out.println("optionValuegrid::"+optionValue);
										System.out.println("getDisplayValue1::"+gridsel.getDisplayValue());


									}


								}

								System.out.println("Printing END  GRID EXP Values **************");




							}

							Map<IOptionFamily, LinkedHashSet<IOptionValue>> m_familyToOptionValuesMap =localObjectOp.getLoadedFamilies();

							/*	try {
					m_bom_familyToOptionValuesMap.put(itemrev, new BOMFamilyMap(bl2.getItemRevision(),m_familyToOptionValuesMap));
				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
							if(m_expEditModeToVariantExpMap!=null)
							{

								System.out.println("NOT NULL MAP ::->>>>>>>>>>");

								System.out.println("START MAP ::->>>>>>>>>>");
								for (Map.Entry<IOptionFamily, LinkedHashSet<IOptionValue>> entry2 : m_familyToOptionValuesMap.entrySet())  
								{
									IOptionFamily optionFamily=entry2.getKey();
									LinkedHashSet<IOptionValue> optionSet=entry2.getValue();

									System.out.println("OptionFamily::"+optionFamily.getName());


									Iterator<IOptionValue> iterator = optionSet.iterator(); 


									while (iterator.hasNext()) 
									{
										IOptionValue optionvalue=	iterator.next();
										System.out.println("Option Value::"+optionvalue.getObjectName());
									}

								} 
								System.out.println("END MAP ::->>>>>>>>>>");
							}
							else
							{


								System.out.println(" NULL MAP ::->>>>>>>>>>");
							}

						}  

					}
				});
			}    

			@Override
			public void exceptionThrown(Exception arg0) {
				// TODO Auto-generated method stub
				arg0.printStackTrace();

			}   
		} );

		try
		{

			((TCSession)localBOMLineNode3.getSession()).queueOperation((Job)localObjectOp);
			localObjectOp.join();
		}
		catch (Exception localException)
		{
			// Logger.getLogger(getClass()).error(localException.getClass().getName(), localException);
			localException.printStackTrace();
		}



	}
	
	public void writeToXLS(String fullpath,LinkedHashMap<IOptionFamily,LinkedHashMap<TCComponentSavedVariantRule,LinkedHashSet<IOptionValue>>> opt_svr_valmap,LinkedHashMap<String,String> ref_opt_val_map,ArrayList<TCComponentSavedVariantRule> selsvrs) throws IOException
	{

		

			maxheader=selsvrs.size();
		
			System.out.println("Strting For EXCEL Writing.....::");
			System.out.println("Strting For EXCEL Writing.....::"+maxheader);
			int rownum=1;
			int cellnum;
			int cellctr;
			
			 Pattern pattern = Pattern.compile("[#0-9]");
			
			//Create a Work Book
			XSSFWorkbook workbook = new XSSFWorkbook();

			IndexedColorMap colorMap = workbook.getStylesSource().getIndexedColors();


			//RED , not Matching
			XSSFCellStyle style_red = workbook.createCellStyle();

			style_red.setFillForegroundColor(new XSSFColor(new Color(255,0,0),colorMap));//RED CELL COLOR
			style_red.setVerticalAlignment(VerticalAlignment.CENTER);
			style_red.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_red.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_red.setBorderBottom(BorderStyle.THICK);
			style_red.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_red.setBorderLeft(BorderStyle.DOUBLE);
			style_red.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_red.setBorderRight(BorderStyle.HAIR);
			style_red.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_red.setBorderTop(BorderStyle.THICK);
			style_red.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_red= workbook.createFont();
			font_red.setBold(true);
			font_red.setFontHeightInPoints((short)11);
			font_red.setFontName("Calibri");
			//font4.setItalic(true);
			//font_red.setColor(new XSSFColor(new Color(255,255,255)));
			 font_red.setColor(new XSSFColor(new Color(0,0,0),colorMap));
			style_red.setFont(font_red);
			
			
			


			//RED SOLVED , not Matching
			XSSFCellStyle style_red_solved = workbook.createCellStyle();

			style_red_solved.setFillForegroundColor(new XSSFColor(new Color(255,0,0),colorMap));//RED CELL COLOR
			style_red_solved.setVerticalAlignment(VerticalAlignment.CENTER);
			style_red_solved.setAlignment(HorizontalAlignment.CENTER);
			style_red_solved.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_red_solved.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_red_solved.setBorderBottom(BorderStyle.THICK);
			style_red_solved.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_red_solved.setBorderLeft(BorderStyle.THICK);
			style_red_solved.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_red_solved.setBorderRight(BorderStyle.HAIR);
			style_red_solved.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_red_solved.setBorderTop(BorderStyle.THICK);
			style_red_solved.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_red_solved= workbook.createFont();
			font_red_solved.setBold(true);
			font_red_solved.setFontHeightInPoints((short)11);
			font_red_solved.setFontName("Calibri");
			//font4.setItalic(true);
			//font_red.setColor(new XSSFColor(new Color(255,255,255)));
			font_red_solved.setColor(new XSSFColor(new Color(0,0,0),colorMap));
			style_red_solved.setFont(font_red_solved);
			
			
			
			//LIGHT BLUE  , not Matching
			 XSSFCellStyle style_lightblue = workbook.createCellStyle();

			 style_lightblue.setFillForegroundColor(new XSSFColor(new Color(37,42,235),colorMap));//RED CELL COLOR new XSSFColor(new Color(153,243,91)
			 style_lightblue.setVerticalAlignment(VerticalAlignment.CENTER);
			 style_lightblue.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			 style_lightblue.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			 style_lightblue.setBorderBottom(BorderStyle.THICK);
			 style_lightblue.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			 style_lightblue.setBorderLeft(BorderStyle.DOUBLE);
			 style_lightblue.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			 style_lightblue.setBorderRight(BorderStyle.HAIR);
			 style_lightblue.setRightBorderColor(IndexedColors.GREEN.getIndex());
			 style_lightblue.setBorderTop(BorderStyle.THICK);
			 style_lightblue.setTopBorderColor(IndexedColors.GREEN.getIndex());


				XSSFFont font_lightblue= workbook.createFont();
				font_lightblue.setBold(true);
				font_lightblue.setFontHeightInPoints((short)11);
				font_lightblue.setFontName("Calibri");
				//font4.setItalic(true);
				//font_lightblue.setColor(new XSSFColor(new Color(255,255,255)));
				font_lightblue.setColor(new XSSFColor(new Color(0,0,0),colorMap));
				style_lightblue.setFont(font_lightblue);
				   
				
				//STYLE OTH SVR
				
				
				//LIGHT BLUE  , not Matching
				 XSSFCellStyle style_oth_svr = workbook.createCellStyle();

				 style_oth_svr.setFillForegroundColor(new XSSFColor(new Color(0,255,255),colorMap));//RED CELL COLOR new XSSFColor(new Color(153,243,91)
				 style_oth_svr.setVerticalAlignment(VerticalAlignment.CENTER);
				 style_oth_svr.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				 style_oth_svr.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				 style_oth_svr.setBorderBottom(BorderStyle.THICK);
				 style_oth_svr.setBottomBorderColor(IndexedColors.GREEN.getIndex());
				 style_oth_svr.setBorderLeft(BorderStyle.DOUBLE);
				 style_oth_svr.setLeftBorderColor(IndexedColors.GREEN.getIndex());
				 style_oth_svr.setBorderRight(BorderStyle.HAIR);
				 style_oth_svr.setRightBorderColor(IndexedColors.GREEN.getIndex());
				 style_oth_svr.setBorderTop(BorderStyle.THICK);
				 style_oth_svr.setTopBorderColor(IndexedColors.GREEN.getIndex());


					XSSFFont font_oth_svr= workbook.createFont();
					font_oth_svr.setBold(true);
					font_oth_svr.setFontHeightInPoints((short)11);
					font_oth_svr.setFontName("Calibri");
					//font4.setItalic(true);
					//font_lightblue.setColor(new XSSFColor(new Color(255,255,255)));
					font_oth_svr.setColor(new XSSFColor(new Color(255,255,255),colorMap));
					style_oth_svr.setFont(font_oth_svr);
					
					
					
					
					//LIGHT PARTIAL GREEN

					XSSFCellStyle style_light_partial_green = workbook.createCellStyle();

					style_light_partial_green.setFillForegroundColor(new XSSFColor(new Color(146,208,80),colorMap));
					style_light_partial_green.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					style_light_partial_green.setVerticalAlignment(VerticalAlignment.CENTER);
					//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
					style_light_partial_green.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					style_light_partial_green.setBorderBottom(BorderStyle.THICK);
					style_light_partial_green.setBottomBorderColor(IndexedColors.GREEN.getIndex());
					style_light_partial_green.setBorderLeft(BorderStyle.DOUBLE);
					style_light_partial_green.setLeftBorderColor(IndexedColors.GREEN.getIndex());
					style_light_partial_green.setBorderRight(BorderStyle.HAIR);
					style_light_partial_green.setRightBorderColor(IndexedColors.GREEN.getIndex());
					style_light_partial_green.setBorderTop(BorderStyle.THICK);
					style_light_partial_green.setTopBorderColor(IndexedColors.GREEN.getIndex());


					XSSFFont font_light_partial_green= workbook.createFont();


					font_light_partial_green.setBold(true);
					font_light_partial_green.setFontHeightInPoints((short)11);
					font_light_partial_green.setFontName("Calibri");
					//font4.setItalic(true);
					font_light_partial_green.setColor(new XSSFColor(new Color(255,255,255),colorMap));
					// font_drkgreen.setColor(new XSSFColor(new Color(0,0,0)));
					style_light_partial_green.setFont(font_light_partial_green);
					   
				   

			//DARK GREEN

			XSSFCellStyle style_drkgreen = workbook.createCellStyle();

			style_drkgreen.setFillForegroundColor(new XSSFColor(new Color(0,176,80),colorMap));
			style_drkgreen.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_drkgreen.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_drkgreen.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_drkgreen.setBorderBottom(BorderStyle.THICK);
			style_drkgreen.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen.setBorderLeft(BorderStyle.DOUBLE);
			style_drkgreen.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen.setBorderRight(BorderStyle.HAIR);
			style_drkgreen.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen.setBorderTop(BorderStyle.THICK);
			style_drkgreen.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_drkgreen= workbook.createFont();


			font_drkgreen.setBold(true);
			font_drkgreen.setFontHeightInPoints((short)11);
			font_drkgreen.setFontName("Calibri");
			//font4.setItalic(true);
			font_drkgreen.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			// font_drkgreen.setColor(new XSSFColor(new Color(0,0,0)));
			style_drkgreen.setFont(font_drkgreen);
			
			
			//SOLVED DRK GREEN
			
			XSSFCellStyle style_drkgreen_solved = workbook.createCellStyle();

			style_drkgreen_solved.setFillForegroundColor(new XSSFColor(new Color(0,176,80),colorMap));
			style_drkgreen_solved.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_drkgreen_solved.setVerticalAlignment(VerticalAlignment.CENTER);
			style_drkgreen_solved.setAlignment(HorizontalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_drkgreen_solved.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_drkgreen_solved.setBorderBottom(BorderStyle.THICK);
			style_drkgreen_solved.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen_solved.setBorderLeft(BorderStyle.DOUBLE);
			style_drkgreen_solved.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen_solved.setBorderRight(BorderStyle.HAIR);
			style_drkgreen_solved.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen_solved.setBorderTop(BorderStyle.THICK);
			style_drkgreen_solved.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_drkgreen_solved= workbook.createFont();


			font_drkgreen_solved.setBold(true);
			font_drkgreen_solved.setFontHeightInPoints((short)11);
			font_drkgreen_solved.setFontName("Calibri");
			//font4.setItalic(true);
			font_drkgreen_solved.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			// font_drkgreen.setColor(new XSSFColor(new Color(0,0,0)));
			style_drkgreen_solved.setFont(font_drkgreen_solved);
			
			//GREEN_RED
			
			XSSFCellStyle style_drkgreen_red = workbook.createCellStyle();

			style_drkgreen.setFillForegroundColor(new XSSFColor(new Color(0,176,80),colorMap));
			style_drkgreen.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_drkgreen.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_drkgreen.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_drkgreen.setBorderBottom(BorderStyle.THICK);
			style_drkgreen.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen.setBorderLeft(BorderStyle.DOUBLE);
			style_drkgreen.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen.setBorderRight(BorderStyle.HAIR);
			style_drkgreen.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_drkgreen.setBorderTop(BorderStyle.THICK);
			style_drkgreen.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_drkgreen_red= workbook.createFont();


			font_drkgreen_red.setBold(true);
			font_drkgreen_red.setFontHeightInPoints((short)11);
			font_drkgreen_red.setFontName("Calibri");
			//font4.setItalic(true);
			font_drkgreen_red.setColor(new XSSFColor(new Color(255,0,0),colorMap));
			// font_drkgreen.setColor(new XSSFColor(new Color(0,0,0)));
			style_drkgreen_red.setFont(font_drkgreen_red);


			///GREEN

			XSSFCellStyle style_green = workbook.createCellStyle();

			style_green.setFillForegroundColor(new XSSFColor(new Color(0,176,80),colorMap));
			style_green.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_green.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_green.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_green.setBorderBottom(BorderStyle.THICK);
			style_green.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_green.setBorderLeft(BorderStyle.DOUBLE);
			style_green.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_green.setBorderRight(BorderStyle.HAIR);
			style_green.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_green.setBorderTop(BorderStyle.THICK);
			style_green.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_green= workbook.createFont();


			font_green.setBold(true);
			font_green.setFontHeightInPoints((short)11);
			font_green.setFontName("Calibri");
			//font4.setItalic(true);
			font_green.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			// font_green.setColor(new XSSFColor(new Color(0,0,0)));
			style_green.setFont(font_green);

			///YELLOW


			XSSFCellStyle style_yellow = workbook.createCellStyle();

			style_yellow.setFillForegroundColor(new XSSFColor(new Color(255,192,0),colorMap));
			style_yellow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_yellow.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_yellow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_yellow.setBorderBottom(BorderStyle.THICK);
			style_yellow.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_yellow.setBorderLeft(BorderStyle.DOUBLE);
			style_yellow.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_yellow.setBorderRight(BorderStyle.HAIR);
			style_yellow.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_yellow.setBorderTop(BorderStyle.THICK);
			style_yellow.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_yellow= workbook.createFont();


			font_yellow.setBold(true);
			font_yellow.setFontHeightInPoints((short)11);
			font_yellow.setFontName("Calibri");
			//font4.setItalic(true);
			//font_yellow.setColor(new XSSFColor(new Color(0,0,0)));
			font_yellow.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			style_yellow.setFont(font_yellow);
			
			
			/// GREY
			
			XSSFCellStyle style_grey = workbook.createCellStyle();

			style_grey.setFillForegroundColor(new XSSFColor(new Color(128,128,128),colorMap));
			style_grey.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_grey.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_grey.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_grey.setBorderBottom(BorderStyle.THICK);
			style_grey.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_grey.setBorderLeft(BorderStyle.DOUBLE);
			style_grey.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_grey.setBorderRight(BorderStyle.HAIR);
			style_grey.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_grey.setBorderTop(BorderStyle.THICK);
			style_grey.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_grey= workbook.createFont();


			font_grey.setBold(true);
			font_grey.setFontHeightInPoints((short)11);
			font_grey.setFontName("Calibri");
			//font4.setItalic(true);
			font_grey.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			// font_drkgreen.setColor(new XSSFColor(new Color(0,0,0)));
			style_grey.setFont(font_grey);


			/////
			
			/// LightPink
			
			XSSFCellStyle style_lightpink = workbook.createCellStyle();

			style_lightpink.setFillForegroundColor(new XSSFColor(new Color(248,203,173),colorMap));
			style_lightpink.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_lightpink.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_lightpink.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_lightpink.setBorderBottom(BorderStyle.THICK);
			style_lightpink.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_lightpink.setBorderLeft(BorderStyle.DOUBLE);
			style_lightpink.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_lightpink.setBorderRight(BorderStyle.HAIR);
			style_lightpink.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_lightpink.setBorderTop(BorderStyle.THICK);
			style_lightpink.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_lightpink= workbook.createFont();


			font_lightpink.setBold(true);
			font_lightpink.setFontHeightInPoints((short)11);
			font_lightpink.setFontName("Calibri");
			//font4.setItalic(true);
			font_lightpink.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			// font_drkgreen.setColor(new XSSFColor(new Color(0,0,0)));
			style_lightpink.setFont(font_lightpink);


			/////
			
			
/// LightGreen
			
			XSSFCellStyle style_lightgreen = workbook.createCellStyle();

			style_lightgreen.setFillForegroundColor(new XSSFColor(new Color(155,194,230),colorMap));
			style_lightgreen.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_lightgreen.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style_lightgreen.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style_lightgreen.setBorderBottom(BorderStyle.THICK);
			style_lightgreen.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style_lightgreen.setBorderLeft(BorderStyle.DOUBLE);
			style_lightgreen.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style_lightgreen.setBorderRight(BorderStyle.HAIR);
			style_lightgreen.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style_lightgreen.setBorderTop(BorderStyle.THICK);
			style_lightgreen.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font_lightgreen= workbook.createFont();


			font_lightgreen.setBold(true);
			font_lightgreen.setFontHeightInPoints((short)11);
			font_lightgreen.setFontName("Calibri");
			//font4.setItalic(true);
			font_lightgreen.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			// font_drkgreen.setColor(new XSSFColor(new Color(0,0,0)));
			style_lightgreen.setFont(font_lightgreen);


			/////
			

			//FIRST HEADER STYLE
			
			XSSFCellStyle style0 = workbook.createCellStyle();

			style0.setFillForegroundColor(new XSSFColor(new Color(255,242,204),colorMap));
			style0.setVerticalAlignment(VerticalAlignment.CENTER);
			style0.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style0.setBorderBottom(BorderStyle.THICK);
			style0.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style0.setBorderLeft(BorderStyle.DOUBLE);
			style0.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style0.setBorderRight(BorderStyle.HAIR);
			style0.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style0.setBorderTop(BorderStyle.THICK);
			style0.setTopBorderColor(IndexedColors.GREEN.getIndex());

			XSSFFont font0= workbook.createFont();

			font0.setBold(true);
			font0.setFontHeightInPoints((short)20);
			font0.setFontName("Calibri");
			//font0.setItalic(true);
			font0.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			style0.setFont(font0);

			
			/////
			//SECOND HEADER STYLE
			

			XSSFCellStyle style1 = workbook.createCellStyle();

			style1.setFillForegroundColor(new XSSFColor(new Color(0,176,240),colorMap));
			style1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			//  style1.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style1.setVerticalAlignment(VerticalAlignment.CENTER);
			style1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style1.setBorderBottom(BorderStyle.THICK);
			style1.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style1.setBorderLeft(BorderStyle.DOUBLE);
			style1.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style1.setBorderRight(BorderStyle.HAIR);
			style1.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style1.setBorderTop(BorderStyle.THICK);
			style1.setTopBorderColor(IndexedColors.GREEN.getIndex());

			XSSFFont font1= workbook.createFont();

			font1.setBold(true);
			font1.setFontHeightInPoints((short)11);
			font1.setFontName("Calibri");
			//font1.setItalic(true);
			font1.setColor(new XSSFColor(new Color(0,0,0),colorMap));
			style1.setFont(font1);

			////
			
			//THIRD HEADER STYLE
			
			XSSFCellStyle style3 = workbook.createCellStyle();

			style3.setFillForegroundColor(new XSSFColor(new Color(217,217,217),colorMap));
			style3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			//style3.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style3.setVerticalAlignment(VerticalAlignment.CENTER);
			style3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style3.setBorderBottom(BorderStyle.THICK);
			style3.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style3.setBorderLeft(BorderStyle.DOUBLE);
			style3.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style3.setBorderRight(BorderStyle.HAIR);
			style3.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style3.setBorderTop(BorderStyle.THICK);
			style3.setTopBorderColor(IndexedColors.GREEN.getIndex());
			style3.setAlignment(HorizontalAlignment.CENTER);
			style3.setVerticalAlignment(VerticalAlignment.CENTER);

			XSSFFont font3= workbook.createFont();

			font3.setBold(true);
			font3.setFontHeightInPoints((short)14);
			font3.setFontName("Calibri");
			//font3.setItalic(true);
			//   font3.setColor(new XSSFColor(new Color(0,0,0)));
			style3.setFont(font3);
			
			///
			
			///
			
			XSSFCellStyle style40 = workbook.createCellStyle();

			style40.setFillForegroundColor(new XSSFColor(new Color(255,255,255),colorMap));
			style40.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			//style40.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style40.setVerticalAlignment(VerticalAlignment.CENTER);
			style40.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style40.setBorderBottom(BorderStyle.THICK);
			style40.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style40.setBorderLeft(BorderStyle.DOUBLE);
			style40.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style40.setBorderRight(BorderStyle.HAIR);
			style40.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style40.setBorderTop(BorderStyle.THICK);
			style40.setTopBorderColor(IndexedColors.GREEN.getIndex());

			XSSFFont font40= workbook.createFont();

			font40.setBold(true);
			font40.setFontHeightInPoints((short)11);
			font40.setFontName("Calibri");
			//font40.setItalic(true);
			// font40.setColor(new XSSFColor(new Color(0,0,0)));
			style40.setFont(font40);

			
			///
			
			////
			

			XSSFCellStyle style4 = workbook.createCellStyle();

			style4.setFillForegroundColor(new XSSFColor(new Color(0,176,240),colorMap));
			style4.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style4.setVerticalAlignment(VerticalAlignment.CENTER);
			//style4.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			style4.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style4.setBorderBottom(BorderStyle.THICK);
			style4.setBottomBorderColor(IndexedColors.GREEN.getIndex());
			style4.setBorderLeft(BorderStyle.DOUBLE);
			style4.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			style4.setBorderRight(BorderStyle.HAIR);
			style4.setRightBorderColor(IndexedColors.GREEN.getIndex());
			style4.setBorderTop(BorderStyle.THICK);
			style4.setTopBorderColor(IndexedColors.GREEN.getIndex());


			XSSFFont font4= workbook.createFont();


			font4.setBold(true);
			font4.setFontHeightInPoints((short)11);
			font4.setFontName("Calibri");
			//font4.setItalic(true);
			// font4.setColor(new XSSFColor(new Color(0,0,0)));
			font4.setColor(new XSSFColor(new Color(255,255,255),colorMap));
			style4.setFont(font4);
			
			/////
			
			XSSFCellStyle style_y=workbook.createCellStyle();
			style_y.setAlignment(HorizontalAlignment.CENTER);
			style_y.setVerticalAlignment(VerticalAlignment.CENTER);
			style_y.setBorderBottom(BorderStyle.THIN);
			style_y.setBorderLeft(BorderStyle.THIN);
			style_y.setBorderRight(BorderStyle.THIN);
			style_y.setBorderTop(BorderStyle.THIN);
			
			///
			
			XSSFCellStyle style_white_black=workbook.createCellStyle();
			style_white_black.setAlignment(HorizontalAlignment.CENTER);
			style_white_black.setVerticalAlignment(VerticalAlignment.CENTER);
			style_white_black.setBorderBottom(BorderStyle.THIN);
			style_white_black.setBorderLeft(BorderStyle.THIN);
			style_white_black.setBorderRight(BorderStyle.THIN);
			style_white_black.setBorderTop(BorderStyle.THIN);
			////

			XSSFCellStyle blankStyle = workbook.createCellStyle();

			blankStyle.setFillForegroundColor(new XSSFColor(new Color(255,255,255),colorMap));
			blankStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			//style40.setFillForegroundColor(new XSSFColor(new Color(255,242,204)));
			/*   blankStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	      blankStyle.setBorderBottom(BorderStyle.THICK);
	      blankStyle.setBottomBorderColor(IndexedColors.GREEN.getIndex());
	      blankStyle.setBorderLeft(BorderStyle.DOUBLE);
	      blankStyle.setLeftBorderColor(IndexedColors.GREEN.getIndex());
	      blankStyle.setBorderRight(BorderStyle.HAIR);
	      blankStyle.setRightBorderColor(IndexedColors.GREEN.getIndex());
	      blankStyle.setBorderTop(BorderStyle.THICK);
	      blankStyle.setTopBorderColor(IndexedColors.GREEN.getIndex());
			 */   
			XSSFFont blankfont= workbook.createFont();

			blankfont.setBold(true);
			blankfont.setFontHeightInPoints((short)11);
			blankfont.setFontName("Calibri");
			//blankfont.setItalic(true);
			// font40.setColor(new XSSFColor(new Color(0,0,0)));
			blankStyle.setFont(blankfont);

			
			
			
			//Create a Spread Sheet
			XSSFSheet spreadsheet = workbook.createSheet("SVR-SVR Comparision");
			
			int note_idx_start=4;
			
			
		    
		    XSSFRow row_lightbluecd= spreadsheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell fcell_lightbluecd = (XSSFCell) row_lightbluecd.createCell(cellnum++);
			fcell_lightbluecd.setCellValue("Reference SVR");
			fcell_lightbluecd.setCellStyle(style_lightblue);
			
			
			XSSFRow row_ot_svr_cd= spreadsheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell fcell_ot_cd = (XSSFCell) row_ot_svr_cd.createCell(cellnum++);
			fcell_ot_cd.setCellValue("Other SVR");
			fcell_ot_cd.setCellStyle(style_oth_svr);
			
		    
		    XSSFRow row_greencd= spreadsheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell fcell_greencd = (XSSFCell) row_greencd.createCell(cellnum++);
			fcell_greencd.setCellValue("Value match with SVR value");
			fcell_greencd.setCellStyle(style_green);
			
			XSSFRow row_light_greencd= spreadsheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell fcell_light_greencd = (XSSFCell) row_light_greencd.createCell(cellnum++);
			fcell_light_greencd.setCellValue("Partial Value match with SVR value");
			fcell_light_greencd.setCellStyle(style_light_partial_green);
		    
		    XSSFRow row_yellowcd= spreadsheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell fcell_yelowcd = (XSSFCell) row_yellowcd.createCell(cellnum++);
			fcell_yelowcd.setCellValue("Value not match with SVR value");
			fcell_yelowcd.setCellStyle(style_yellow);
			
			XSSFRow row_greycd= spreadsheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell fcell_greycd = (XSSFCell) row_greycd.createCell(cellnum++);
			fcell_greycd.setCellValue("SVR having Blank value");
			fcell_greycd.setCellStyle(style_grey);
			
			rownum++;
			 
			 cellnum=0; 
			
			XSSFRow row0= spreadsheet.createRow((short) rownum++);
			cellnum=0;
			row0.setHeightInPoints((float)35.4);

			 XSSFCell fcell1 = (XSSFCell) row0.createCell(cellnum++);
			 fcell1.setCellStyle(blankStyle);
			
			//row0.setRowStyle(style0);
			

			 //  for(int i = 0; i <= maxheader; i++)
			 cellctr=-1;
			 int hdr_cnt=maxheader+4;
				   while(++cellctr<hdr_cnt)
			   {
				   //For each cell in the row 
				   
					XSSFCell cell0 = (XSSFCell) row0.createCell(cellnum++);
					cell0.setCellValue("Option values comparison report for  SVR Vs SVR");
					cell0.setCellStyle(style0);
			    	  
			   }
			   if(cellnum>2)
			   spreadsheet.addMergedRegion(new CellRangeAddress(rownum-1, rownum-1, 1, cellnum-1));


			
			XSSFRow row1 = spreadsheet.createRow((short) rownum++);
			row1.setHeightInPoints((float)14);
			cellnum=0;

			XSSFCell fcell2 = (XSSFCell) row1.createCell(cellnum++);
			fcell2.setCellStyle(blankStyle);

			XSSFCell   cell1 = (XSSFCell) row1.createCell(cellnum++);



			//row1.setRowStyle(style1);
			cell1.setCellStyle(style1);

			cell1.setCellValue("Platform Name");

			XSSFCell   cell12 = (XSSFCell) row1.createCell(cellnum++);
			cell12.setCellValue(this.getPlatformRevision().toDisplayString());
			cell12.setCellStyle(style1);
			
			// for(int i = cellnum; i <= maxheader; i++)
			cellctr=-1;
			   while(++cellctr<maxheader)
			   {
				   //For each cell in the row 
				 XSSFCell   cell12_1 = (XSSFCell) row1.createCell(cellnum++);
				 cell12_1.setCellValue("");
				 cell12_1.setCellStyle(style1);
			    	  
			   }


			   
				   
				   XSSFRow row32 = spreadsheet.createRow((short) rownum++);
				   row32.setHeightInPoints((float)14);
					cellnum=0;
					XSSFCell fcell41 = (XSSFCell) row32.createCell(cellnum++);
					fcell41.setCellStyle(blankStyle);

					XSSFCell   cell311 = (XSSFCell) row32.createCell(cellnum++);






					//row2.setRowStyle(style1);
					cell311.setCellValue("Report Date:");
					cell311.setCellStyle(style1) ;  

					XSSFCell   cell321 = (XSSFCell) row32.createCell(cellnum++);

					//row2.setRowStyle(style1);

					DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					Date date = new Date();
					System.out.println(dateFormat.format(date));

					cell321.setCellValue(dateFormat.format(date));
					cell321.setCellStyle(style1) ;
					
					// for(int i = cellnum; i <=maxheader; i++)
					cellctr=-1;
					   while(++cellctr<maxheader)
					   {
						   //For each cell in the row 
						 XSSFCell   cell3_1 = (XSSFCell) row32.createCell(cellnum++);
						 cell3_1.setCellValue("");
						 cell3_1.setCellStyle(style1);
					    	  
					   }
				   
			   ///
					   
					   /////
					   
					   
					   XSSFRow row32_1 = spreadsheet.createRow((short) rownum++);
					   row32_1.setHeightInPoints((float)14);
						cellnum=0;
						XSSFCell fcell41_1 = (XSSFCell) row32_1.createCell(cellnum++);
						fcell41.setCellStyle(blankStyle);

						XSSFCell   cell31_2 = (XSSFCell) row32_1.createCell(cellnum++);






						//row2.setRowStyle(style1);
						cell31_2.setCellValue("Revision Rule:");
						cell31_2.setCellStyle(style1) ;  

						XSSFCell   cell31_3 = (XSSFCell) row32_1.createCell(cellnum++);

						//row2.setRowStyle(style1);

						

						cell31_3.setCellValue(this.revRuleSelected);
						cell31_3.setCellStyle(style1) ;
						
						// for(int i = cellnum; i <=maxheader; i++)
						cellctr=-1;
						   while(++cellctr<maxheader)
						   {
							   //For each cell in the row 
							 XSSFCell   cell31_4 = (XSSFCell) row32_1.createCell(cellnum++);
							 cell31_4.setCellValue("");
							 cell31_4.setCellStyle(style1);
						    	  
						   }
					   
					   
					   /////
						   
						   //////////
						   
						   
						   ////CLOSURERULE
						   
						   /////
						   
						   
						   XSSFRow row3cl_1 = spreadsheet.createRow((short) rownum++);
						   row3cl_1.setHeightInPoints((float)14);
							cellnum=0;
							XSSFCell fcell41c_1 = (XSSFCell) row3cl_1.createCell(cellnum++);
							fcell41c_1.setCellStyle(blankStyle);

							XSSFCell   cell31cl_2 = (XSSFCell) row3cl_1.createCell(cellnum++);






							//row2.setRowStyle(style1);
							cell31cl_2.setCellValue("View:");
							cell31cl_2.setCellStyle(style1) ;  

							XSSFCell   cell31cl_3 = (XSSFCell) row3cl_1.createCell(cellnum++);

							//row2.setRowStyle(style1);

							

							cell31cl_3.setCellValue(this.viewSelected);
							cell31cl_3.setCellStyle(style1) ;
							
							// for(int i = cellnum; i <=maxheader; i++)
							cellctr=-1;
							   while(++cellctr<maxheader)
							   {
								   //For each cell in the row 
								 XSSFCell   cell31c_4 = (XSSFCell) row3cl_1.createCell(cellnum++);
								 cell31c_4.setCellValue("");
								 cell31c_4.setCellStyle(style1);
							    	  
							   }
						   
						   
						   /////
							   
						   
						   
						   
						   
						   
						   ///////
						   
						   XSSFRow row32_2 = spreadsheet.createRow((short) rownum++);
						   row32_1.setHeightInPoints((float)14);
							cellnum=0;
							XSSFCell fcell41_2 = (XSSFCell) row32_2.createCell(cellnum++);
							fcell41.setCellStyle(blankStyle);

							XSSFCell   cell31_5 = (XSSFCell) row32_2.createCell(cellnum++);






							//row2.setRowStyle(style1);
							cell31_5.setCellValue("Show Blank Option:");
							cell31_5.setCellStyle(style1) ;  

							XSSFCell   cell31_6 = (XSSFCell) row32_2.createCell(cellnum++);

							//row2.setRowStyle(style1);

							

							cell31_6.setCellValue(this.isAllOption);
							cell31_6.setCellStyle(style1) ;
							
							// for(int i = cellnum; i <=maxheader; i++)
							cellctr=-1;
							   while(++cellctr<maxheader)
							   {
								   //For each cell in the row 
								 XSSFCell   cell31_7 = (XSSFCell) row32_2.createCell(cellnum++);
								 cell31_7.setCellValue("");
								 cell31_7.setCellStyle(style1);
							    	  
							   }
						   
						   
						   /////


			XSSFRow row3 = spreadsheet.createRow((short) rownum++);

			row3.setHeightInPoints((float)28);

			cellnum=0;

			XSSFCell fcell4 = (XSSFCell) row3.createCell(cellnum++);
			fcell4.setCellStyle(blankStyle);

			
			//row3.setRowStyle(style3);

			XSSFCell   cell30 = (XSSFCell) row3.createCell( cellnum++);
			cell30.setCellStyle(style3);

			cell30.setCellValue("Srl No");

			cellctr=-1;
			++cellctr;
			 XSSFCell   cell12_1 = (XSSFCell) row3.createCell(cellnum++);
			 cell12_1.setCellValue("SVR Option");
			 cell12_1.setCellStyle(style3);
			 
			 ++cellctr;
			 XSSFCell   cell12_2 = (XSSFCell) row3.createCell(cellnum++);
			 cell12_2.setCellValue("Reference SVR Value");
			 cell12_2.setCellStyle(style_lightblue);
			
			   while(++cellctr<maxheader)
			   {
				   //For each cell in the row 
				 XSSFCell   cell12_3 = (XSSFCell) row3.createCell(cellnum++);
				 cell12_3.setCellValue("SVR Value");
				 cell12_3.setCellStyle(style_oth_svr);
			    	  
			   }
			
			int countidx=cellnum;
			
			if(maxheader>1)
			spreadsheet.addMergedRegion(new CellRangeAddress(rownum-1, rownum-1, 3+1, maxheader+3));
			
			
			
			
			
			
			boolean isheader=true;
			int startrow=rownum;
			int endrow=rownum;

			
				
				if(isheader)
				{


					XSSFRow row4 = spreadsheet.createRow((short) rownum++);
					cellnum=0;   
					row4.setHeightInPoints((float)20);

					XSSFCell fcell5 = (XSSFCell) row4.createCell(cellnum++);
					fcell5.setCellStyle(blankStyle);

					
				//	row4.setRowStyle(style4);

					XSSFCell   cell40 = (XSSFCell) row4.createCell(cellnum++);
					cell40.setCellStyle(style40);

					cell40.setCellValue("");

					XSSFCell   cell41 = (XSSFCell) row4.createCell(cellnum++);
					cell41.setCellStyle(style4);

					cell41.setCellValue("Option");



					
					
					
					Iterator<TCComponentSavedVariantRule> mod_val4it=selsvrs.iterator();

					
				//	cell43.setCellStyle(style_white_black);
					int svr_col=0;

					System.out.println("EXH:"+"Option Name,All Value,SVR Value , ");
					if(mod_val4it!=null )
					{
						while( mod_val4it.hasNext())//mod_val2it!=null && mod_val2it.hasNext())
						{

							

							TCComponentSavedVariantRule svrobj= mod_val4it.next();
							XSSFCell cell=row4.createCell(cellnum++);
							
							cell.setCellValue(svrobj.toDisplayString()+"-"+svrobj.getDescription());//.replaceAll("/ (Design Master)" , ""));
							if(svr_col>0)
								cell.setCellStyle(style_oth_svr);
							else
							cell.setCellStyle(style_lightblue);
							svr_col++;
						}
				}
					
					
					
					
					isheader=false;

					startrow=rownum;
				}


				int srlno=0;
				
				for(Entry<IOptionFamily, LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>>> entry_0 : opt_svr_valmap.entrySet())
				{
					++srlno;
					IOptionFamily fam=entry_0.getKey();
					
					
					
					String ref_opt_str=ref_opt_val_map.get(fam.getName());
					
					if(ref_opt_str==null || ref_opt_str.length()==0)
						ref_opt_str=CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR;
					
					System.out.println("WIRTEXL::"+fam.getName()+":"+ref_opt_str);
					
					boolean isMultiValueRef=false;
					 String[] svr_vals_ary = null;
					if(ref_opt_str!=null)
						svr_vals_ary=ref_opt_str.split(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR);
					System.out.println("svr_vals_ary::"+svr_vals_ary.length);
					if(svr_vals_ary!=null && svr_vals_ary.length>1)
						isMultiValueRef=true;
					ArrayList<String> ref_op_ary_list=new ArrayList<String>();
					
					if(svr_vals_ary!=null)
					{
						for(int q=0;q<svr_vals_ary.length;q++)
					ref_op_ary_list.add(svr_vals_ary[q]);
					}
					LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<IOptionValue>> svr_opval=entry_0.getValue();
					/*
					LinkedHashSet<IOptionValue> unqmatch=this.matchoptval.get(fam);
					
					String unq_opt_str="";
					Iterator<IOptionValue> unqmatchit=unqmatch.iterator();
					while(unqmatchit.hasNext())
					{
						
						IOptionValue un_op=unqmatchit.next();
						if(unq_opt_str.length()>0)
							unq_opt_str+=CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR;
						
						unq_opt_str+=un_op.getObjectName();
						
					}
					
					 Pattern op_pattern = Pattern.compile(unq_opt_str);
					 */
					cellnum=0;
					XSSFRow xlrow_1=spreadsheet.createRow(rownum++);
					cellnum=1;
					
					XSSFCell srlcell=xlrow_1.createCell(cellnum++);
					srlcell.setCellValue(srlno);
					srlcell.setCellStyle(style_white_black);

					
					
					
					
					XSSFCell optcell=xlrow_1.createCell(cellnum++);
					optcell.setCellValue(fam.getName());
					optcell.setCellStyle(style_white_black);

				
				
			
					
					for(int y=0;y<selsvrs.size();y++)
					{
						TCComponentSavedVariantRule svr_r1=selsvrs.get(y);
						
						LinkedHashSet<IOptionValue> opt_set=	svr_opval.get(svr_r1);
					
						boolean isValmatch=false;
						boolean isValmatchAll=true;
					
						if(opt_set==null)
							opt_set=new LinkedHashSet<IOptionValue>();	
						
						
						Iterator<IOptionValue> iterator = opt_set.iterator(); 
						String opt_set_val="";
						ArrayList<String> ref_op_ary_list1=new ArrayList<String>();
								ref_op_ary_list1.addAll(ref_op_ary_list);
						while (iterator.hasNext()) 
						{
							IOptionValue optionvalue=	iterator.next();
							String op_value_str=optionvalue.getObjectName();
							
							if(ref_op_ary_list.contains(op_value_str) && isValmatch==false)
								isValmatch=true;
							
							
							ref_op_ary_list1.remove(op_value_str);
								
							
							
							if(opt_set_val.length()>0)
								opt_set_val+=CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR;
							opt_set_val+=op_value_str;
							System.out.println("SVR Option Value::"+fam.getName()+":"+svr_r1.toDisplayString()+":"+op_value_str);
						}
						
						if(ref_op_ary_list.size()>0 && ref_op_ary_list1.size()==0)
							isValmatchAll=true;
						else
							isValmatchAll=false;
						
						/*
						XSSFCell optval=xlrow_1.createCell(cellnum++);
						
						
						if(opt_set_val.length()==0)
						{
							optval.setCellStyle(style_grey);
						}
						else
						{
						if(opt_set_val.equalsIgnoreCase(ref_opt_str)==false)
						{
							
							optval.setCellStyle(style_yellow);//yellow
						}
						else
						{
						optval.setCellStyle(style_drkgreen);
						}
						}
						
						optval.setCellValue(opt_set_val.replaceAll(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR, CfgReportPref.DISPLAY_OPTION_SEPARATOR_STR));
						*/
						
						String opt_set_val1=opt_set_val;
					//	Matcher op_matcher = op_pattern.matcher(opt_set_val);
						
					
						XSSFCell optval=xlrow_1.createCell(cellnum++);
						if(opt_set_val.length()==0)//Blank Value
						{
							optval.setCellStyle(style_grey);
						}
						
						
						else if(isValmatchAll ==true)//Full Match
						{
							//optval.setCellStyle(style_grey);
							optval.setCellStyle(style_drkgreen);
							optval.setCellValue(opt_set_val.replaceAll(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR, CfgReportPref.DISPLAY_OPTION_SEPARATOR_STR));
							System.out.println("Full Match OPTION:"+fam.getName()+":"+ref_opt_str+":"+opt_set_val+ ":"+isValmatchAll+":"+isValmatch);
							
						}
						else if(isValmatchAll ==false &&isValmatch==true )// Partial Match
						{
							//optval.setCellStyle(style_grey);
							optval.setCellStyle(style_light_partial_green);
							optval.setCellValue(opt_set_val.replaceAll(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR, CfgReportPref.DISPLAY_OPTION_SEPARATOR_STR));
							System.out.println("Partial Match OPTION:"+fam.getName()+":"+ref_opt_str+":"+opt_set_val+ ":"+isValmatchAll+":"+isValmatch);
							
						}
						
						else if(isValmatchAll ==false &&isValmatch==false )// NO Match
						{
							//optval.setCellStyle(style_grey);
							optval.setCellStyle(style_yellow);
							optval.setCellValue(opt_set_val.replaceAll(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR, CfgReportPref.DISPLAY_OPTION_SEPARATOR_STR));
							
							System.out.println("NO Match OPTION:"+fam.getName()+":"+ref_opt_str+":"+opt_set_val+ ":"+isValmatchAll+":"+isValmatch);
							
						}
						
						
						
					 if(svr_vals_ary!=null&& isValmatchAll ==false &&isValmatch==true)
						{
					//	optval.setCellStyle(style_drkgreen);
						
						 RichTextString richString = new XSSFRichTextString(opt_set_val1.replaceAll(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR, CfgReportPref.DISPLAY_OPTION_SEPARATOR_STR));
						 richString.applyFont(0, opt_set_val1.length(), font_drkgreen_red);
						 
						 System.out.println("MULL::"+ref_opt_str);
						 
						// String[] svr_vals_ary=ref_opt_str.split(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR);
					     if(ref_opt_str.length()>0)
					     {
					     for (int u=0;u<svr_vals_ary.length;u++)
					     {
							String svr_val_1=svr_vals_ary[u]; 
						int fromidx=0;
						int st_mat=-1;
						int end_mat=-1;
						
						if(opt_set_val.contains(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR))
						{
						int act_len=opt_set_val.length();
						int svr_len=svr_val_1.length();
						boolean run=true;
						do
						{
							st_mat=opt_set_val.indexOf(svr_val_1,fromidx);
							end_mat=st_mat+svr_val_1.length();
							fromidx=end_mat;
							System.out.println("MUL0::"+":"+st_mat+":"+end_mat+":"+svr_len+":"+act_len);
							if(st_mat==-1)
								run=false;	
							if(st_mat==0 &&(opt_set_val.charAt(0)==CfgReportPref.INTERNAL_OPTION_SEPARATOR_CHR||opt_set_val.charAt(end_mat)==CfgReportPref.INTERNAL_OPTION_SEPARATOR_CHR))
								run=false;
							if(end_mat==act_len &&(opt_set_val.charAt(st_mat-1)==CfgReportPref.INTERNAL_OPTION_SEPARATOR_CHR ||opt_set_val.charAt(end_mat-1)==CfgReportPref.INTERNAL_OPTION_SEPARATOR_CHR))
								run=false;
							if(st_mat>1 && end_mat<act_len &&opt_set_val.charAt(st_mat-1)==CfgReportPref.INTERNAL_OPTION_SEPARATOR_CHR && opt_set_val.charAt(end_mat)==CfgReportPref.INTERNAL_OPTION_SEPARATOR_CHR)
								run=false;
							
							System.out.println("MUL1::"+":"+st_mat+":"+end_mat+":"+svr_len+":"+act_len);
						}while(run);
						
						}
						else
							
						{
							
							st_mat=opt_set_val.indexOf(svr_val_1);
							end_mat=st_mat+svr_val_1.length();
							System.out.println("ELSE MUL1::"+":"+st_mat+":"+end_mat+":");
						}
						//int end_mat=st_mat+svr_val1.length();
						//System.out.println("MUL::"+svr_val_1+":"+mod_val_pair1.isMultivalue()+":"+st_mat+":"+end_mat+":"+ac_opt_val);
						// RichTextString richString = new XSSFRichTextString(ac_opt_val);
						 ////RichTextString richString = new XSSFRichTextString(ac_opt_val.replaceAll(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR, CfgReportPref.DISPLAY_OPTION_SEPARATOR_STR));
						//// richString.applyFont(0, ac_opt_val.length(), font_drkgreen_red);
						 if(st_mat>=0 &&end_mat>=0)
						 richString.applyFont(st_mat, end_mat, font_drkgreen);
					     } 
					     }
						
					/*	
						
						
					       while (op_matcher.find()) {
					          
					           
					           richString.applyFont(op_matcher.start(), op_matcher.end(), font_drkgreen);
					       }
						*/
					      // optval.setCellValue(richString);
						//}
						
					}
					
				}
				}
				
				
				

			System.out.println("END1 For EXCEL Writing.....::");
			int b=0;
		if (spreadsheet.getPhysicalNumberOfRows() > 0) {
				            XSSFRow autorow = spreadsheet.getRow(10);
				            Iterator<Cell> cellIterator = autorow.cellIterator();
				            while (cellIterator.hasNext()) {
				            //	if(b<=1)
				            //		continue;
				            	b++;
				                Cell cell = cellIterator.next();
				                int columnIndex = cell.getColumnIndex();
				                spreadsheet.autoSizeColumn(columnIndex);
				            }
				        }
	
		////BOMSOLVE COMPARISION///
		
		
		
		
		
		
		    XSSFSheet solve_sheet=workbook.createSheet("BOM-Solve Comparision");
		    		
		    		
		    rownum=1;		
		    
		    
		  
		    
		    XSSFRow sol_row_lightbluecd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell sol_fcell_lightbluecd = (XSSFCell) sol_row_lightbluecd.createCell(cellnum++);
			sol_fcell_lightbluecd.setCellValue("Reference SVR");
			sol_fcell_lightbluecd.setCellStyle(style_lightblue);
			
			
			XSSFRow sol_row_ot_svr_cd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell sol_fcell_ot_cd = (XSSFCell) sol_row_ot_svr_cd.createCell(cellnum++);
			sol_fcell_ot_cd.setCellValue("Other SVR");
			sol_fcell_ot_cd.setCellStyle(style_oth_svr);
			
		    
		    XSSFRow sol_row_greencd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell sol_fcell_greencd = (XSSFCell) sol_row_greencd.createCell(cellnum++);
			//sol_fcell_greencd.setCellValue("Module Solved");
			sol_fcell_greencd.setCellValue("Common Module");
			sol_fcell_greencd.setCellStyle(style_green);
			
			XSSFRow dup_sol_row_greencd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell dup_sol_fcell_greencd = (XSSFCell) dup_sol_row_greencd.createCell(cellnum++);
			//dup_sol_fcell_greencd.setCellValue("Duplicate Module Solved");
			dup_sol_fcell_greencd.setCellValue("Duplicate Module");
			dup_sol_fcell_greencd.setCellStyle(style_lightgreen);
			
		/*	XSSFRow sol_row_light_greencd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell sol_fcell_light_greencd = (XSSFCell) sol_row_light_greencd.createCell(cellnum++);
			sol_fcell_light_greencd.setCellValue("Partial Value match with SVR value");
			sol_fcell_light_greencd.setCellStyle(style_light_partial_green);
		 */   
		    XSSFRow sol_row_yellowcd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell sol_fcell_yelowcd = (XSSFCell) sol_row_yellowcd.createCell(cellnum++);
			//sol_fcell_yelowcd.setCellValue("Module Not Solved");
			sol_fcell_yelowcd.setCellValue("Change from Reference list");
			sol_fcell_yelowcd.setCellStyle(style_yellow);
			
			
			
			XSSFRow dup_not_sol_row_lightpinkcd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell dup_not_sol_fcell_lightpinkcd = (XSSFCell) dup_not_sol_row_lightpinkcd.createCell(cellnum++);
			//dup_not_sol_fcell_lightpinkcd.setCellValue("Duplicate Module Not Solved");
			dup_not_sol_fcell_lightpinkcd.setCellValue("Duplicate Module");
			dup_not_sol_fcell_lightpinkcd.setCellStyle(style_lightpink);
			
			XSSFRow sol_row_greycd= solve_sheet.createRow((short) rownum++);
			cellnum=note_idx_start;
			XSSFCell sol_fcell_greycd = (XSSFCell) sol_row_greycd.createCell(cellnum++);
			//sol_fcell_greycd.setCellValue("Blank value");
			sol_fcell_greycd.setCellValue("No Module solved");
			sol_fcell_greycd.setCellStyle(style_grey);
			
			rownum++;
			 
			 cellnum=0; 
			
			XSSFRow srow0= solve_sheet.createRow((short) rownum++);
			cellnum=0;
			srow0.setHeightInPoints((float)35.4);

			 XSSFCell sfcell1 = (XSSFCell) srow0.createCell(cellnum++);
			 sfcell1.setCellStyle(blankStyle);
			
			//row0.setRowStyle(style0);
			

			 //  for(int i = 0; i <= maxheader; i++)
			 cellctr=-1;
			  hdr_cnt=maxheader+4;
				   while(++cellctr<hdr_cnt)
			   {
				   //For each cell in the row 
				   
					XSSFCell scell0 = (XSSFCell) srow0.createCell(cellnum++);
					scell0.setCellValue("BOM Solve comparision");
					scell0.setCellStyle(style0);
			    	  
			   }
			       if(cellnum>2)
				   solve_sheet.addMergedRegion(new CellRangeAddress(rownum-1, rownum-1, 1, cellnum-1));


			
			XSSFRow srow1 = solve_sheet.createRow((short) rownum++);
			srow1.setHeightInPoints((float)14);
			cellnum=0;

			XSSFCell sfcell2 = (XSSFCell) srow1.createCell(cellnum++);
			sfcell2.setCellStyle(blankStyle);

			XSSFCell   scell1 = (XSSFCell) row1.createCell(cellnum++);



			//row1.setRowStyle(style1);
			scell1.setCellStyle(style1);

			scell1.setCellValue("Platform Name");

			XSSFCell   scell12 = (XSSFCell) srow1.createCell(cellnum++);
			scell12.setCellValue(this.getPlatformRevision().toDisplayString());
			scell12.setCellStyle(style1);
			
			// for(int i = cellnum; i <= maxheader; i++)
			cellctr=-1;
			   while(++cellctr<maxheader)
			   {
				   //For each cell in the row 
				 XSSFCell   scell12_1 = (XSSFCell) srow1.createCell(cellnum++);
				 scell12_1.setCellValue("");
				 scell12_1.setCellStyle(style1);
			    	  
			   }


			   
				   
				   XSSFRow srow32 = solve_sheet.createRow((short) rownum++);
				   srow32.setHeightInPoints((float)14);
					cellnum=0;
					XSSFCell sfcell41 = (XSSFCell) srow32.createCell(cellnum++);
					sfcell41.setCellStyle(blankStyle);

					XSSFCell   scell311 = (XSSFCell) row32.createCell(cellnum++);






					//row2.setRowStyle(style1);
					scell311.setCellValue("Report Date:");
					scell311.setCellStyle(style1) ;  

					XSSFCell   scsell321 = (XSSFCell) srow32.createCell(cellnum++);

					//row2.setRowStyle(style1);

					

					scsell321.setCellValue(dateFormat.format(date));
					scsell321.setCellStyle(style1) ;
					
					// for(int i = cellnum; i <=maxheader; i++)
					cellctr=-1;
					   while(++cellctr<maxheader)
					   {
						   //For each cell in the row 
						 XSSFCell   scell3_1 = (XSSFCell) srow32.createCell(cellnum++);
						 scell3_1.setCellValue("");
						 scell3_1.setCellStyle(style1);
					    	  
					   }
				   
			   ///


			XSSFRow srow3 = solve_sheet.createRow((short) rownum++);

			srow3.setHeightInPoints((float)28);

			cellnum=0;

			XSSFCell sfcell4 = (XSSFCell) srow3.createCell(cellnum++);
			sfcell4.setCellStyle(blankStyle);

			
			//row3.setRowStyle(style3);

			XSSFCell   scell30 = (XSSFCell) srow3.createCell( cellnum++);
			scell30.setCellStyle(style3);

			scell30.setCellValue("Srl No");

			cellctr=-1;
			++cellctr;
			 XSSFCell   scell12_1 = (XSSFCell) srow3.createCell(cellnum++);
			 scell12_1.setCellValue("TCUA");
			 scell12_1.setCellStyle(style3);
			 
			 ++cellctr;
			 XSSFCell   scell12_2 = (XSSFCell) srow3.createCell(cellnum++);
			 scell12_2.setCellValue("Reference SVR");
			 scell12_2.setCellStyle(style_lightblue);
			
			   while(++cellctr<maxheader)
			   {
				   //For each cell in the row 
				 XSSFCell   scell12_3 = (XSSFCell) srow3.createCell(cellnum++);
				 scell12_3.setCellValue("Other SVR");
				 scell12_3.setCellStyle(style_oth_svr);
			    	  
			   }
			
			 countidx=cellnum;
			
            if(maxheader>1)
			 solve_sheet.addMergedRegion(new CellRangeAddress(rownum-1, rownum-1, 3+1, maxheader+3));
			
			
			
			
			
			
			 isheader=true;
			 startrow=rownum;
			 endrow=rownum;

			
				
				if(isheader)
				{


					XSSFRow srow4 = solve_sheet.createRow((short) rownum++);
					cellnum=0;   
					srow4.setHeightInPoints((float)20);

					XSSFCell sfcell5 = (XSSFCell) srow4.createCell(cellnum++);
					sfcell5.setCellStyle(blankStyle);

					
				//	row4.setRowStyle(style4);

					XSSFCell   scell40 = (XSSFCell) srow4.createCell(cellnum++);
					scell40.setCellStyle(style40);

					scell40.setCellValue("");

					XSSFCell   scell41 = (XSSFCell) srow4.createCell(cellnum++);
					scell41.setCellStyle(style4);

					scell41.setCellValue("Architecture Node");



					
					
					
					Iterator<TCComponentSavedVariantRule> mod_val4it=selsvrs.iterator();

					
				//	cell43.setCellStyle(style_white_black);
					int svr_col=0;

					System.out.println("EXH:"+"Option Name,All Value,SVR Value , ");
					if(mod_val4it!=null )
					{
						while( mod_val4it.hasNext())//mod_val2it!=null && mod_val2it.hasNext())
						{

							

							TCComponentSavedVariantRule svrobj= mod_val4it.next();
							XSSFCell scell=srow4.createCell(cellnum++);
							
							scell.setCellValue(svrobj.toDisplayString()+"-"+svrobj.getDescription());//.replaceAll("/ (Design Master)" , ""));
							if(svr_col>0)
								scell.setCellStyle(style_oth_svr);
							else
							scell.setCellStyle(style_lightblue);
							svr_col++;
						}
				}
					
					
					
					
					isheader=false;

					startrow=rownum;
				}

		    
				for(Entry<String, LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<String>>> arc_svr_bom_map_ent : arc_svr_bom_map.entrySet())
				{
				
					String arc_name=arc_svr_bom_map_ent.getKey();
					LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<String>> svr_bom_val=arc_svr_bom_map_ent.getValue();
					
					
					
					System.out.println("*****************START for "+arc_name+"*********************");
					
					for(Entry<TCComponentSavedVariantRule, LinkedHashSet<String>> svr_bom_val_0 : svr_bom_val.entrySet())
					{
						
					TCComponentSavedVariantRule rule0=	svr_bom_val_0.getKey();
					LinkedHashSet<String> bom_set=svr_bom_val_0.getValue();
					
					
					
					Iterator<String> bom_it= bom_set.iterator();
					while(bom_it.hasNext())
					{
						System.out.println("*****************"+arc_name+":"+rule0.toDisplayString()+":"+bom_it.next().toString());
					}
					System.out.println("***************END**************");
					
					}
				}
		    
		  
		    
		    
		    
		     srlno=0;
			
			for(Entry<String, LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<String>>> arc_svr_bom_map_ent : arc_svr_bom_map.entrySet())
			{
			
				String arc_name=arc_svr_bom_map_ent.getKey();
				
				
				LinkedHashMap<TCComponentSavedVariantRule, LinkedHashSet<String>> svr_bom_val=arc_svr_bom_map_ent.getValue();
				
				LinkedHashMap<TCComponentSavedVariantRule, Integer> svr_bom_val_size=arc_svr_bom_map_size.get(arc_name);

			
				LinkedHashSet<String> ref_bom_set=ref_arc_bom_map.get(arc_name);
				if(ref_bom_set==null)
					ref_bom_set=new LinkedHashSet<String>();
				
				System.out.println("REFSET LEN::"+arc_name+ ":"+ref_bom_set.size());
				
				Iterator<String> ref_bom_it=ref_bom_set.iterator();
				
				while(ref_bom_it.hasNext())
				{
					
					System.out.println("REfSet::"+ref_bom_it.next());
					
				}
			
				++srlno;
				
				cellnum=0;
				XSSFRow sxlrow_1=solve_sheet.createRow(rownum++);
				cellnum=1;
				
				XSSFCell ssrlcell=sxlrow_1.createCell(cellnum++);
				ssrlcell.setCellValue(srlno);
				ssrlcell.setCellStyle(style_white_black);

				
				
				
				
				XSSFCell soptcell=sxlrow_1.createCell(cellnum++);
				soptcell.setCellValue(arc_name);
				soptcell.setCellStyle(style_white_black);
				
				int maxrownum=0;
				
				for(int y=0;y<selsvrs.size();y++)
				{
					TCComponentSavedVariantRule svr_r1=selsvrs.get(y);
					
					LinkedHashSet<String> bom_v_set=	svr_bom_val.get(svr_r1);
					int sz_val_sz=0;
					if(bom_v_set==null)
					{
						bom_v_set=new LinkedHashSet<String>();///////
					}
					int bom_v_set_sz=bom_v_set.size();
					
					
					Iterator<String> bom_it=bom_v_set.iterator();
					
					
					Integer sz_val=svr_bom_val_size.get(svr_r1);
					
					
					try
					{
						sz_val_sz=sz_val.intValue();
					}catch(Exception e)
					{
						
						
					}
					
					System.out.println("ALL::"+srlno+":"+ arc_name+":"+":"+svr_r1.toDisplayString()+":"+selsvrs.size()+":"+bom_v_set_sz+"::"+bom_v_set_sz+":"+sz_val_sz);
					
					
					
					if(bom_v_set_sz==0)
					{
						XSSFCell soptval=sxlrow_1.createCell(cellnum++);
						
						soptval.setCellValue("");
						soptval.setCellStyle(style_grey);
					}
					
					int temprownum=rownum;
				
					
					for(int v=0;v<sz_val_sz;v++)
					{
						XSSFCell soptval=null;
						if(v>0)
						{
					/*++srlno;
					
					cellnum=0;
					 sxlrow_1=solve_sheet.createRow(rownum++);
					
					 ssrlcell=sxlrow_1.createCell(cellnum++);
					ssrlcell.setCellValue(srlno);
					ssrlcell.setCellStyle(style_white_black);

					
					
					
					
					 soptcell=sxlrow_1.createCell(cellnum++);
					soptcell.setCellValue(arc_name);
					soptcell.setCellStyle(style_white_black);
					*/
							sxlrow_1=solve_sheet.getRow(temprownum);
							if(sxlrow_1==null)
							sxlrow_1=solve_sheet.createRow(temprownum++);
							int cellnum_tmp=cellnum-1;
							
							ssrlcell=sxlrow_1.getCell(1);
							if(ssrlcell==null)
								ssrlcell=sxlrow_1.createCell(1);
							
							ssrlcell.setCellValue(srlno);
							ssrlcell.setCellStyle(style_white_black);
							
							XSSFCell sarccell=sxlrow_1.getCell(2);
							if(sarccell==null)
								sarccell=sxlrow_1.createCell(2);
							
							sarccell.setCellValue(arc_name);
							sarccell.setCellStyle(style_white_black);
							
							soptval=sxlrow_1.getCell(cellnum_tmp);
							if(soptval==null)
								soptval=sxlrow_1.createCell(cellnum_tmp);
							
							
							soptval=sxlrow_1.getCell(cellnum_tmp);
							if(soptval==null)
								soptval=sxlrow_1.createCell(cellnum_tmp);
						}
						else
						{
							sxlrow_1=solve_sheet.getRow(rownum-1);
					 soptval=sxlrow_1.createCell(cellnum++);
						}
					if(bom_v_set_sz>0)
					{
						
						
					if (bom_it.hasNext()) 
					{
					//ref_bom_set
					
						
						String bom_value=	bom_it.next();
						soptval.setCellValue(bom_value);
						
						System.out.println("REfSetMatch::"+bom_value+":"+ref_bom_set.contains(bom_value));
						
						if(ref_bom_set.contains(bom_value))
						{
							if(v>0)
								soptval.setCellStyle(style_lightgreen);//style_lightgreen
							else
							soptval.setCellStyle(style_drkgreen);
						}
						else
						{
							if(v>0)
								soptval.setCellStyle(style_lightpink);//style_lightpink
							else
							soptval.setCellStyle(style_yellow);//yellow
						}
							
					}
					}
					else
					{
						soptval.setCellValue("");
						soptval.setCellStyle(style_grey);
					}
					
					
					}
					
					if(temprownum>maxrownum)
						maxrownum=temprownum;
		    
				}
				
				rownum=maxrownum;
			} 		
			
			
			b=0;
			if (solve_sheet.getPhysicalNumberOfRows() > 0) {
	            XSSFRow autorow = solve_sheet.getRow(10);
	            Iterator<Cell> cellIterator = autorow.cellIterator();
	            while (cellIterator.hasNext()) {
	            //	if(b<=1)
	            //		continue;
	            	b++;
	                Cell cell = cellIterator.next();
	                int columnIndex = cell.getColumnIndex();
	                solve_sheet.autoSizeColumn(columnIndex);
	            }
	        }
			
		 ////END BOMSOLVE COMPARISION///
		
			FileOutputStream out = new FileOutputStream( new File(fullpath));

			workbook.write(out);
			out.close();
			System.out.println(fullpath+" written successfully");


		
	}
	public int isValueMatchedSVR_Actual(String svroptionSetStr,String actoptionSetStr)
	{
		
	int isMatched=1;
	
	if(svroptionSetStr.length()==0 )
	{
		isMatched=-1;
		return isMatched;
	}
	
	if( actoptionSetStr.length()==0)
	{
		isMatched=-1;
		return isMatched;
	}
	
	//String[] svrs=svroptionSetStr.split("/");
	
	//String[] acts=actoptionSetStr.split("/");
	
	String[] svrs=svroptionSetStr.split(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR);
	
	String[] acts=actoptionSetStr.split(CfgReportPref.INTERNAL_OPTION_SEPARATOR_STR);
	
	for(int i=0;i<acts.length;i++)
	{
		for(int j=0;j<svrs.length;j++)
		{
			if(acts[i].equals(svrs[j]))
			{
				isMatched=0;
				return isMatched;
			}
		}
	}
	return isMatched;
		
	}
	
	
	public LinkedHashMap<String,LinkedHashSet<String>> getSolvedBOMITK(TCComponentSavedVariantRule sv_rule)
	{
		
		LinkedHashMap<String,LinkedHashSet<String>> solvedbom =new LinkedHashMap<String,LinkedHashSet<String>>();
		
		
		
		
		Object[] inputArgs = new Object[4];
		inputArgs[0] = this.platformRevision;//Platform Revision
		inputArgs[1] = sv_rule;//Variant Rule
		inputArgs[2] = this.revRuleSelected;//revRuleSelected
		inputArgs[3] = this.closureRuleSelected;//closureRuleSelected
		for(int k=0;k<inputArgs.length;k++)
		System.out.println(inputArgs[k]);
		
		TCUserService userService =localTCSession.getUserService();
		System.out.println("Before call ApplyBOMVariantRuleFunc1");
		try {
			String serv_name="ApplyBOMVariantRuleFunc1";//"expand_bom1"
			//String serv_name="expand_bom1";
			Object[] retdata=(Object[]) userService.call(serv_name, inputArgs);
			
			for(int x=0;x<retdata.length;x++)
			{
				
				String ret_val=(String) retdata[x];
				
				String[] ret_ary=ret_val.split("#");
				System.out.println("DATA RET::"+retdata[x]+":"+ret_ary[0]+":"+ret_ary[1]);
				
				LinkedHashSet<String> bom_set=solvedbom.get(ret_ary[0]);
				if(bom_set==null)
				{
					bom_set=new LinkedHashSet<String>();
				}
					bom_set.add(ret_ary[1]);
					solvedbom.put(ret_ary[0], bom_set);
				
				
				
				
				
				
			}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return solvedbom;
	}
	
	//For Faster
////Working
	
	public void processSVRCompare(final CheckboxTreeViewer treeViewer,TreeTableNodeLine refsvrrule,Object[] bomnode,/*Map<String ,ArrayList<String>> svrbom,*/ String fullpath,boolean incolor,boolean allselected) throws IOException
	{

		
		try {

			
			
			this.getSVRRuleData( fullpath,refsvrrule,bomnode,treeViewer,allselected);
				}catch(Exception e)
			{
				
				e.printStackTrace();
			}
		
		
	}
}
