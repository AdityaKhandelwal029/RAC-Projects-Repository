package tm.cfg.svrcompare.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class ModuleCompareRow {
	
	String srlno;
	String archNode;
	String alloption;
	String svrvalue;
	String moduleno_value;
	String allvalue;
	LinkedHashMap<String,String> modulemap;
	
	public ModuleCompareRow(String srlno, String archNode, String alloption,
			String svrvalue,String allvalue, String moduleno_value) {
		super();
		this.srlno = srlno;
		this.archNode = archNode;
		this.alloption = alloption;
		this.allvalue = allvalue;
		this.svrvalue = svrvalue;
		this.moduleno_value = moduleno_value;
		modulemap=new LinkedHashMap<String,String>();
	}

	public String getSrlno() {
		return srlno;
	}

	public void setSrlno(String srlno) {
		this.srlno = srlno;
	}

	public String getArchNode() {
		return archNode;
	}

	public void setArchNode(String archNode) {
		this.archNode = archNode;
	}

	public String getAlloption() {
		return alloption;
	}

	public void setAlloption(String alloption) {
		this.alloption = alloption;
	}

	public String getSvrvalue() {
		return svrvalue;
	}

	public void setSvrvalue(String svrvalue) {
		this.svrvalue = svrvalue;
	}

	public String getModuleno_value() {
		return moduleno_value;
	}

	public void setModuleno_value(String moduleno_value) {
		this.moduleno_value = moduleno_value;
	}

	public String getAllvalue() {
		return allvalue;
	}

	public void setAllvalue(String allvalue) {
		this.allvalue = allvalue;
	}

	
	
	public LinkedHashMap<String,String> getModulemap() {
		return modulemap;
	}

	public void setModulemap(LinkedHashMap<String,String> modulemap) {
		this.modulemap = modulemap;
	}

	@Override
	public String toString() {
		return "ModuleCompareRow [srlno=" + srlno + ", archNode=" + archNode
				+ ", alloption=" + alloption + ", svrvalue=" + svrvalue
				+ ", moduleno_value=" + moduleno_value + ", allvalue="
				+ allvalue + "]";
	}

	
	
	
	
	
	

}
