package tm.cfg.svrcompare.core;

public class ModuleValuePair {
	
	private String moduleno;
	private boolean modmatch;
	String option;
	String value;
	int valmatch;//0-> Match,1->No Match ,-1->blank match
	boolean multivalue;
	public ModuleValuePair(String moduleno, boolean modmatch, String option,
			String value, int valmatch,boolean multivalue) {
		super();
		this.moduleno = moduleno;
		this.modmatch = modmatch;
		this.option = option;
		this.value = value;
		this.valmatch = valmatch;
		this.multivalue=multivalue;
	}
	
	public String getModuleno() {
		return moduleno;
	}
	public void setModuleno(String moduleno) {
		this.moduleno = moduleno;
	}
	
	
	public boolean isModmatch() {
		return modmatch;
	}

	public void setModmatch(boolean modmatch) {
		this.modmatch = modmatch;
	}

	public int isValmatch() {
		return valmatch;
	}

	public void setValmatch(int valmatch) {
		this.valmatch = valmatch;
	}

	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
	public boolean isMultivalue() {
		return multivalue;
	}

	public void setMultivalue(boolean multivalue) {
		this.multivalue = multivalue;
	}

	@Override
	public String toString() {
		return "ModuleValuePair [moduleno=" + moduleno + ", modmatch="
				+ modmatch + ", option=" + option + ", value=" + value
				+ ", valmatch=" + valmatch + ", multivalue=" + multivalue + "]";
	}
	
	

}
