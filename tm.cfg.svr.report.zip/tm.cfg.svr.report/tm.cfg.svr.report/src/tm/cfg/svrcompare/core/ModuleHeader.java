package tm.cfg.svrcompare.core;

public class ModuleHeader {
	
	private String moduleno;
	private boolean modulealmatch;
	
	public ModuleHeader(String moduleno, boolean modulealmatch) {
		
		this.moduleno = moduleno;
		this.modulealmatch = modulealmatch;
	}

	public String getModuleno() {
		return moduleno;
	}

	public void setModuleno(String moduleno) {
		this.moduleno = moduleno;
	}

	public boolean isModulealmatch() {
		return modulealmatch;
	}

	public void setModulealmatch(boolean modulealmatch) {
		this.modulealmatch = modulealmatch;
	}

	@Override
	public String toString() {
		return "ModuleHeader [moduleno=" + moduleno + ", modulealmatch="
				+ modulealmatch + "]";
	}
	
	

}
