package tm.cfg.svrcompare.core;

import java.util.LinkedHashSet;
import java.util.Map;

import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.variants.IOptionFamily;
import com.teamcenter.rac.kernel.variants.IOptionValue;

public class BOMFamilyMap {

	private TCComponentItemRevision itemRev;
	private Map<IOptionFamily, LinkedHashSet<IOptionValue>> fam_map;
	
	public BOMFamilyMap(TCComponentItemRevision itemRev,
			Map<IOptionFamily, LinkedHashSet<IOptionValue>> fam_map) {
		super();
		this.itemRev = itemRev;
		this.fam_map = fam_map;
	}

	public TCComponentItemRevision getItemRev() {
		return itemRev;
	}

	public void setItemRev(TCComponentItemRevision itemRev) {
		this.itemRev = itemRev;
	}

	public Map<IOptionFamily, LinkedHashSet<IOptionValue>> getFam_map() {
		return fam_map;
	}

	public void setFam_map(Map<IOptionFamily, LinkedHashSet<IOptionValue>> fam_map) {
		this.fam_map = fam_map;
	}
	
	
	
}
