package tm.cfg.svrcompare.core;

import com.teamcenter.rac.kernel.variants.IOptionValue;

public class SVROptionValue {
	
	private IOptionValue optval;

	public SVROptionValue(IOptionValue optval) {
		super();
		this.optval = optval;
	}

	public IOptionValue getOptval() {
		return optval;
	}

	public void setOptval(IOptionValue optval) {
		this.optval = optval;
	}


}
