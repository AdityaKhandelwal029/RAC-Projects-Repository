package tm.cfg.svr.report.ui;

import java.io.File;
import java.io.IOException;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.osgi.util.NLS;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Link;
import org.eclipse.ui.PlatformUI;

public class TMLLinkMessageDialog extends MessageDialog {

	/**
	 * @param args
	 */

	private File fLogLocation;
	private String message;
	private int messagetype;

	public TMLLinkMessageDialog(File logLocation,String message,int messagetype) {
		super(PlatformUI.getWorkbench().getDisplay().getActiveShell(), "Message", null, null, messagetype, new String[] {IDialogConstants.OK_LABEL}, 0);
		fLogLocation = logLocation;
		this.message=message;
		 this.messagetype= messagetype;
	}

	protected Control createMessageArea(Composite composite) {
		Link link = new Link(composite, SWT.WRAP);
		try {
			link.setText(NLS.bind(message+" {0} ", "<a>" + fLogLocation.getCanonicalPath() + "</a>")); //$NON-NLS-1$ //$NON-NLS-2$
		} catch (IOException e) {
			e.printStackTrace();
		}
		GridData data = new GridData();
		data.widthHint = convertHorizontalDLUsToPixels(IDialogConstants.MINIMUM_MESSAGE_AREA_WIDTH);
		link.setLayoutData(data);
		link.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				try {
					Program.launch(fLogLocation.getCanonicalPath());
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		});
		return link;
	}


}
