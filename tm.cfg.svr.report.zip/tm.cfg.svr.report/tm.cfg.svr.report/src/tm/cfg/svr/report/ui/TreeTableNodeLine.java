package tm.cfg.svr.report.ui;

import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;

public class TreeTableNodeLine {

	/**
	 * @param args
	 */
	private boolean selected;
	private int srl;
	private TCComponentSavedVariantRule svrrule;
	private String description;
	private String status ;
	
	
	
	
	
	
	public TreeTableNodeLine(boolean selected, int srl,
			TCComponentSavedVariantRule svrrule,String description) {
		super();
		this.selected = selected;
		this.srl = srl;
		this.svrrule = svrrule;
		this.description=description;
		this.status = "";
	}



	
	
	

	public boolean isSelected() {
		return selected;
	}



	public void setSelected(boolean selected) {
		this.selected = selected;
	}



	public int getSrl() {
		return srl;
	}

	public void setSrl(int srl) {
		this.srl = srl;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}







	public TCComponentSavedVariantRule getSvrrule() {
		return svrrule;
	}







	public void setSvrrule(TCComponentSavedVariantRule svrrule) {
		this.svrrule = svrrule;
	}







	public String getDescription() {
		return description;
	}







	public void setDescription(String description) {
		this.description = description;
	}







	@Override
	public String toString() {
		return "TreeTableNodeLine [selected=" + selected + ", srl=" + srl
				+ ", svrrule=" + svrrule + ", description=" + description
				+ ", status=" + status + "]";
	}



	
	
}
