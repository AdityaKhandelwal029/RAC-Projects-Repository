package tm.cfg.svr.report.ui;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;




public class SearchViewerFilter extends ViewerFilter {

    private String searchString;

    public void setSearchText(String s) {
        // ensure that the value can be used for matching
        this.searchString = s.toLowerCase();
    }

    @Override
    public boolean select(Viewer viewer,
            Object parentElement,
            Object element) {
        if (searchString == null || searchString.length() == 0) {
            return true;
        }
         if(element instanceof TreeTableNodeLine)
        {
        	 TreeTableNodeLine tabline = (TreeTableNodeLine) element;
        	
   		    	
   		    	
   		       if(tabline.getSvrrule().toDisplayString().toLowerCase().contains(searchString) || tabline.getDescription().toLowerCase().contains(searchString)||tabline.getStatus().toLowerCase().contains(searchString))
   		    	   return true;
        }  
        
       
        return false;
    }

}
