package tm.cfg.svr.report.ui;




import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;

import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.common.NotDefinedException;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTreeViewer;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.LabelProviderChangedEvent;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandImageService;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.wb.swt.SWTResourceManager;

import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;


import com.teamcenter.rac.aif.AbstractAIFOperation;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.InterfaceAIFOperationExecutionListener;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.commands.open.OpenCommand;
import com.teamcenter.rac.commands.properties.PropertiesCommand;
import com.teamcenter.rac.common.CommandTargetState;

import com.teamcenter.rac.common.TCTypeRenderer;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentCfg0ConfiguratorPerspective;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCComponentSavedVariantRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.variants.ExpressionEditModeEnum;
import com.teamcenter.rac.kernel.variants.GridExpression;
import com.teamcenter.rac.kernel.variants.GridSubExpression;
import com.teamcenter.rac.kernel.variants.GridSubExpression.GridExpressionSelection;
import com.teamcenter.rac.kernel.variants.IGridExpressionContainer;
import com.teamcenter.rac.kernel.variants.IOptionFamily;
import com.teamcenter.rac.kernel.variants.IOptionValue;
import com.teamcenter.rac.kernel.variants.IVariantConfiguratorAdapter;
import com.teamcenter.rac.kernel.variants.IVariantExpressionContainer;
import com.teamcenter.rac.pca.operations.LoadExpEditorContentFromFormulaOperation;
import com.teamcenter.rac.pca.operations.LoadExpressionEditorContentOperation;
import com.teamcenter.rac.pca.operations.LoadExpressionEditorContentOperation.GridRefreshModeEnum;
import com.teamcenter.rac.pse.common.BOMLineNode;
import com.teamcenter.rac.pse.pca.common.PCAPSEUtils;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.soa.client.model.ServiceData;





import org.eclipse.swt.widgets.Combo;



import tm.cfg.svrcompare.core.BOMFamilyMap;
import tm.cfg.svrcompare.core.SVRUtil;


import org.eclipse.swt.widgets.ProgressBar;





public class SVRComparisionDialog extends TitleAreaDialog {
	
	private Shell parentShell;
	private String filename;
	private TCComponentItemRevision selectedObj;
	
    private Text searchText;
    private SearchViewerFilter searchFilter;
    private TCSession session;
    private CheckboxTreeViewer treeViewer;
    private Tree tree;
    private Text text_1;
    private Text text;
    private String ruleSelected;
  //  private TableCombo combo;
    private TCComponentCfg0ConfiguratorPerspective m_configPerspective=null;
    private TreeMap<IVariantExpressionContainer,LoadExpressionEditorContentOperation>  localObjectOpList ;
    private TreeMap<BOMLineNode,IVariantExpressionContainer>  localObjectOpList1 ;
    private TreeMap<TCComponentItemRevision, BOMFamilyMap> m_bom_familyToOptionValuesMap;
    
    private SVRUtil svrutil;
    private TreeTableNodeLine refsvrrule;
    private Map<TCComponentSavedVariantRule,Map<GridExpression,Map<IOptionFamily, LinkedHashSet<IOptionValue>>>> m_rule_gridexptofamilyToValueMap = new HashMap();
	   ;
    //private boolean isdlgSuccess;
    private Map<String ,ArrayList<TreeTableNodeLine>> svrbom;
    private Text text_2;
    private String fullpath;
    private String sel_id;
    private Bundle bundle_ic;
    private Image completed_img;
    private Image pending_img;
    private Image current_img;
    private boolean selck=false;
    private ArrayList<TreeTableNodeLine> inputtree;
    private ArrayList<TreeTableNodeLine> subinputtree;
    private Button btnBrwButton;
    private Bundle bundle;
    private Button btndeselectAll;
    private boolean incolor;
    private ProgressBar progressBar;
    private TreeSet<String> ruleset;
    private String[] ruleary;
    private Combo refSVRcombo;
    private Combo comboRevRule;
    private Combo combo_view;
    private Button btnAllArch;
    private String viewSelected;
    private String closureRuleSelected;
    private String revRuleSelected;
    private LinkedHashMap<String,String> viewRuleMap;
    private boolean allselected;
    private Label lblClosureRuleLabel;
	

	/**
	 * Create the dialog.
	 * @param parentShell
	 * @param selectedObj 
	 */
	public SVRComparisionDialog(Shell parentShell,TCSession session,ExecutionEvent exe_evt, TCComponentItemRevision selectedObj) {
		super(parentShell);
		setShellStyle(SWT.DIALOG_TRIM | SWT.MIN | SWT.RESIZE);
		//parentShell.setMaximized(true);
		this.session=session;
		 svrutil=new SVRUtil();
		this.selectedObj=selectedObj;
		this.parentShell=parentShell;
		svrutil.setPlatformRevision(this.selectedObj);
		incolor=false;
		localObjectOpList=new TreeMap<IVariantExpressionContainer,LoadExpressionEditorContentOperation>();
		localObjectOpList1=new TreeMap<BOMLineNode,IVariantExpressionContainer>();
		svrbom=new LinkedHashMap<String ,ArrayList<TreeTableNodeLine>>();
		m_bom_familyToOptionValuesMap =new TreeMap<TCComponentItemRevision, BOMFamilyMap>() ;
		 bundle = FrameworkUtil.getBundle(this.getClass());
		this.allselected=false;
		 viewRuleMap=new LinkedHashMap<String,String>();
		 
		 try {
			populateView(viewRuleMap);
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		// viewRuleMap.put("ERC","BOMLineskipforunconfigured");
		
		
		bundle_ic = FrameworkUtil.getBundle(this.getClass());
		
		// use the org.eclipse.core.runtime.Path as import
		String path_ic="icons/apply_16x16.png";
			URL	url_ic = FileLocator.find(bundle_ic,
		    new Path(path_ic), null);
			completed_img   = ImageDescriptor.createFromURL(url_ic).createImage();
		
		
		 path_ic="icons/hourglass_32x32.png";
			url_ic = FileLocator.find(bundle_ic,
	    new Path(path_ic), null);
			current_img  = ImageDescriptor.createFromURL(url_ic).createImage();
	
	 path_ic="icons/hourglass_32x32.png";
		url_ic = FileLocator.find(bundle_ic,
    new Path(path_ic), null);
		pending_img  = ImageDescriptor.createFromURL(url_ic).createImage();
		
	}
	protected boolean ServiceDataError(final ServiceData data)
	{
		
	    if(data.sizeOfPartialErrors() > 0)
	    {
	            for(int i = 0; i < data.sizeOfPartialErrors(); i++)
	            {
	                     for(String msg :
	data.getPartialError(i).getMessages())
	                             System.out.println("ServiceDataError:"+msg);
	            }

	            return true;
	    }

	    return false;
	}
	
	private void populateView(LinkedHashMap<String,String> view_closuremap) throws TCException
	{
		
		

		
		String [] qryNames={"SYSCD","SUBSYSCD"};
		String [] qryValues={"VIEW","CLOSURE"};
		
		
		
		ArrayList<String> relclazlist;
		
		TCComponent[] objvec=SVRUtil.queryObjTCUA("Control Objects...","T5_ControlObject", qryNames,qryValues);
		
		if(objvec!=null)
		{
			for(int f=0;f<objvec.length;f++)
			{
				TCComponent objcntrl=objvec[f];
				
		
				String infostr="";
				
				String[] infoattr=new String[]{"t5_Userinfo1","t5_Userinfo2","t5_Userinfo3","t5_Userinfo4","t5_Userinfo5","t5_Userinfo6","t5_Userinfo7","t5_Userinfo8","t5_Userinfo9","t5_Userinfo10"};
				
				for(int r=0;r<infoattr.length;r++)
				{
				
				Object info=objcntrl.getTCProperty(infoattr[r]);
				
				if(info!=null)
					infostr+=info.toString();
							
				
				
				}
				
				
				StringTokenizer stkinfostr=new StringTokenizer(infostr,",");
				
				
				
				while(stkinfostr.hasMoreElements())
				{
					
					String attrs=stkinfostr.nextToken();
					
					String[] attrary=attrs.split(":");
					
					view_closuremap.put(attrary[0], attrary[1]);
					
					
				}
				
				
				
				
				
				
				
				
			}
		}
		
		
	
		
		
	}
	  private void populateViewCombo()
	  {
		  
		 for(Map.Entry<String, String> vent:viewRuleMap.entrySet())
		 {
		 
		 combo_view.add(vent.getKey());
		 }
		  
	  }
	
	  private List populateSVRRuleCombo(Table table, TCComponent[] svrs)
	  {
	   
		  List<TableItem> rowList = new ArrayList<TableItem>();
		  
		  if(svrs!=null)
		  {
			  TCComponentSavedVariantRule rule1=(TCComponentSavedVariantRule) svrs[0];
			  Image svrimage=TCTypeRenderer.getImage(rule1);
	    for (int index = 0; index < svrs.length; index++)
	    {
	      TableItem ti = new TableItem(table, 0);
	      TCComponentSavedVariantRule rule=(TCComponentSavedVariantRule) svrs[index];
	      ti.setImage(svrimage);
	      ti.setText(0, rule.toDisplayString());
	      ti.setText(1, rule.getDescription());
	      rowList.add(ti);
	    }
		  }
	    return rowList;
	  }


	 public Object[] getAllTreeItems(Tree tree,ArrayList<TreeItem> items) 
	 {
		 
	 ArrayList<Object> result=new ArrayList<Object>();
		 
	
	 TreeItem[] item_arr=tree.getItems();
	 
	 System.out.println("getAllTreeItems::"+item_arr.length);
	        for (int i = 0; i < item_arr.length; i++) {
	        	TreeItem item = item_arr[i];
	        	
	            if (item instanceof TreeItem ) {
	            	items.add(item);
	                Object data = item.getData();
	                if (data != null) {
						result.add(data);
					}
	            }
	 }
	        return result.toArray(new Object[result.size()]);
	        
	 }
	
	public Object[] getAllTreeObjects(ArrayList<TreeTableNodeLine> treeobjs)
	{
		
		if(treeobjs!=null)
    	return treeobjs.toArray();
    	
		
    	
		return null;
	}
	
	
	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle("Option values comparison report for  SVR Vs  SVR");
		final Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		//lblModuleNumber.
		final Group grpClassificationPropertiesValues = new Group(container, SWT.NONE);
		grpClassificationPropertiesValues.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpClassificationPropertiesValues.setText("SVR");
		grpClassificationPropertiesValues.setBounds(10, 222, 751, 524);

		searchText = new Text(grpClassificationPropertiesValues, SWT.BORDER);
		searchText.addKeyListener(new KeyAdapter() {
            
			public void keyReleased(KeyEvent e)
			{
				
				System.out.print("kjk:"+searchText.getText());
            	
		          
           	 searchFilter.setSearchText(searchText.getText());
           	
           	 treeViewer.refresh();
           	 treeViewer.expandAll();
           	 
           	 TreeItem[]  items = tree.getItems();//new  ArrayList<TreeItem>();
           	// Object[] bomnode_all=getAllTreeItems(tree,items);
           	 System.out.println("ttt00:"+items.length);
           	 
           	 for(int t=0;t<items.length;t++)
           	 {
   		
           		 
   			 TreeTableNodeLine ln=(TreeTableNodeLine)items[t].getData();
   			
   		      if(ln.getStatus().equals("Pending"))
   			 {
   				//items.get(t).setChecked(true);
   				treeViewer.setChecked(ln, true);
   			
   			 }
           	 }
           	 treeViewer.refresh();
			
			}
			
        });
		searchText.setBounds(120, 25, 609, 26);
		
		treeViewer = new CheckboxTreeViewer(grpClassificationPropertiesValues, SWT.BORDER | SWT.FULL_SELECTION);
		tree = treeViewer.getTree();
		
		searchFilter=new SearchViewerFilter();
		treeViewer.addFilter(searchFilter);
		
		tree.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		tree.setHeaderVisible(true);
		tree.setBounds(10, 57, 731, 457);
		
		TreeViewerColumn treeViewerColumn = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn trclmnSrlNo = treeViewerColumn.getColumn();
		trclmnSrlNo.setWidth(79);
		trclmnSrlNo.setText("Srl No");
		
		treeViewerColumn.setLabelProvider(new ColumnLabelProvider() {
			
		
			
			public Image getImage(Object element) {
				
		    	return null;
			}
		 
		    public String getText(Object element) {
		    	
		    	if(element instanceof TreeTableNodeLine) 
		    	{
					TreeTableNodeLine p = (TreeTableNodeLine) element;
		    		
		    		return p.getSrl()+"";
		    	}
		    	
		    	return null;
		    }
		    
		    
		});
		
		TreeViewerColumn treeViewerColumn_1 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn trclmnObject = treeViewerColumn_1.getColumn();
		trclmnObject.setWidth(523);
		trclmnObject.setText("Object");
		
		treeViewerColumn_1.setLabelProvider(new ColumnLabelProvider() {
			
		
			
			public Image getImage(Object element) {
				if(element instanceof TreeTableNodeLine) 
		    	{
					TreeTableNodeLine p = (TreeTableNodeLine) element;
		    		TCComponentSavedVariantRule tcobj=p.getSvrrule();
		    		
		    		return TCTypeRenderer.getImage(tcobj);
		    	}
		    	return null;
			}
		 
		    public String getText(Object element) {
		    	
		    	if(element instanceof TreeTableNodeLine) 
		    	{
					TreeTableNodeLine p = (TreeTableNodeLine) element;
					TCComponentSavedVariantRule tcobj=p.getSvrrule();
		    		
		    		return tcobj.toDisplayString()+"-"+p.getDescription();
		    	}
		    	return null;
		    }
		    
		    
		});
		
		TreeViewerColumn treeViewerStatus = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn trclmnStatus = treeViewerStatus.getColumn();
		trclmnStatus.setWidth(109);
		trclmnStatus.setText("Status");
		
	
		
		treeViewerStatus.setLabelProvider(new ColumnLabelProvider() {
			
		
			
			public Image getImage(Object element) {
				if(element instanceof TreeTableNodeLine) 
		    	{
					TreeTableNodeLine p = (TreeTableNodeLine) element;
		    		String status=p.getStatus();
		    		if(status!=null)
		    		{
		    		switch(status)
		    		{
		    		
		    		case "Completed" : return completed_img;
		    		case "Executing" : return current_img;
		    		case "Pending" : return pending_img;
		    		
		    		
		    		}
		    		}
		    		
		    		return null;
		    	}
		    	return null;
			}
		 
			
			public Color getForeground(final Object element) {
				if(element instanceof TreeTableNodeLine) 
		    	{
					TreeTableNodeLine p = (TreeTableNodeLine) element;
		    		String status=p.getStatus();
		    		if(status!=null)
		    		{
		    		switch(status)
		    		{
		    		
		    		case "Completed" : return  Display.getCurrent().getSystemColor(SWT.COLOR_DARK_GREEN);
		    		case "Executing" : return Display.getCurrent().getSystemColor(SWT.COLOR_DARK_YELLOW);
		    		case "Pending" : return  Display.getCurrent().getSystemColor(SWT.COLOR_RED);
		    		
		    		
		    		}
		    		}
		    		
		    		return super.getBackground(element);
		    	}
		 
		        
		        
		        return super.getBackground(element);
		    }
			
		    public String getText(Object element) {
		    	
		    	if(element instanceof TreeTableNodeLine) 
		    	{
					TreeTableNodeLine p = (TreeTableNodeLine) element;
		    		
		    		
		    		return p.getStatus();
		    	}
		    	return null;
		    }
		    
		    
		});
		
		
		
		
		
		
		btndeselectAll = new Button(grpClassificationPropertiesValues, SWT.NONE);
		btndeselectAll.setBounds(10, 23, 47, 30);
		
		String path_chk=null;
		if(selck)
			path_chk="icons/check.jpg";
		else
			path_chk="icons/uncheck.jpg";
				
		
		URL url_chk = FileLocator.find(bundle,
		    new Path(path_chk), null);
			
		btndeselectAll.setImage(ImageDescriptor.createFromURL(url_chk).createImage());
		//btnSearch.setText("New Button");
		
		Button btnErase = new Button(grpClassificationPropertiesValues, SWT.NONE);
		btnErase.setBounds(93, 23, 66, 30);
		btnErase.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				clearFilter();
				
			}
		});
		//Button btndeselectAll = new Button(grpClassificationPropertiesValues, SWT.NONE);
	//	btndeselectAll.setBounds(10, 23, 47, 30);
		
		
		
		// use the org.eclipse.core.runtime.Path as import
		String path="icons/eraser.PNG";
		
		
		URL url = FileLocator.find(bundle,
		    new Path(path), null);
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
	
		
		btnErase.setImage(imageDescriptor.createImage());
		
	
		/*btnSearch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				System.out.print("kjk:"+searchText.getText());
           	 searchFilter.setSearchText(searchText.getText());
           	 treeViewer.refresh();
			}
		});*/
		btnErase.setBounds(63, 23, 51, 30);
		
		// use the org.eclipse.core.runtime.Path as import
				 path="icons/search.jpg";
				
				
				 url = FileLocator.find(bundle,
				    new Path(path), null);
				 imageDescriptor = ImageDescriptor.createFromURL(url);
			
				
				// btnSearch.setImage(imageDescriptor.createImage());	
		
		Group grpInput = new Group(container, SWT.NONE);
		grpInput.setText("Input");
		grpInput.setBounds(18, 10, 743, 206);
		
		text = new Text(grpInput, SWT.BORDER);
		text.setEditable(false);
		text.setText(selectedObj.toDisplayString());
		text.setBounds(242, 23, 246, 26);
		
		
		
		Label lblPlatform = new Label(grpInput, SWT.NONE);
		lblPlatform.setBounds(148, 26, 70, 20);
		lblPlatform.setText("Platform :");
		
		
		try {
			TCComponentSavedVariantRule svr_val=null;
			svr_val = svrutil.setAnySVR();
			
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		text_2 = new Text(grpInput, SWT.BORDER);
		text_2.setEditable(false);
		text_2.setBounds(242, 170, 246, 26);
		
		try {
			sel_id=selectedObj.getTCProperty("item_id").getDisplayableValue();
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		btnBrwButton = new Button(grpInput, SWT.NONE);
		btnBrwButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				
				 DirectoryDialog dlg = new DirectoryDialog(parentShell);

			        // Set the initial filter path according
			        // to anything they've selected or typed in
			        dlg.setFilterPath(text.getText());

			        // Change the title bar text
			        dlg.setText("Repot Location");

			        // Customizable message displayed in the dialog
			        dlg.setMessage("Select a directory");

			        // Calling open() will open and run the dialog.
			        // It will return the selected directory, or
			        // null if user cancels
			        String dir = dlg.open();
			        if (dir != null) {
			          // Set the text box to the new selection
			        	
			        	DateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
						Date date = new Date();
						String dateval=dateFormat.format(date);
						System.out.println(dateval);
			        	
			        	filename=sel_id+"_"+"SVR"+"_"+dateval+".xlsx";
			        	fullpath=dir+"\\"+ filename;
			        	text_2.setText(fullpath);
			        	
			        	setOKEnabled();
			        }
				
			}
		});
		btnBrwButton.setBounds(500, 168, 114, 30);
		btnBrwButton.setText("Browse File");
		
		Bundle bundle1 = FrameworkUtil.getBundle(this.getClass());
		
		// use the org.eclipse.core.runtime.Path as import
		String path1="icons/excel.png";
			URL	url1 = FileLocator.find(bundle1,
		    new Path(path1), null);
		ImageDescriptor imageDescriptor1 = ImageDescriptor.createFromURL(url1);
	
		
		btnBrwButton.setImage(imageDescriptor1.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/Ok_16x16.png"));
		
		Label lblEportLocation = new Label(grpInput, SWT.NONE);
		lblEportLocation.setBounds(139, 173, 97, 20);
		lblEportLocation.setText("Report File :");
		
		progressBar = new ProgressBar(grpInput, SWT.SMOOTH | SWT.INDETERMINATE);
		progressBar.setBounds(500, 97, 210, 21);
		
		refSVRcombo = new Combo(grpInput, SWT.NONE);
		refSVRcombo.setBounds(242, 55, 246, 28);
		
		refSVRcombo.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				ruleSelected=refSVRcombo.getText();
				Display.getDefault().syncExec(new Runnable()
		        {
		          public void run()
		          {
		        
				setOKEnabled();
		          }
		        });
				
			}
		});
		refSVRcombo.addModifyListener(new ModifyListener() {
	           
			public void modifyText(ModifyEvent e) {
				// TODO Auto-generated method stub
			
	
				
				int d;
				for( d=0;d<ruleary.length;d++)
				{
					if(ruleary[d].equals(refSVRcombo.getText()))
						break;
				}
				refSVRcombo.select(d);
				
				System.out.print("keyevt:"+refSVRcombo.getSelectionIndex());
				
				if(refSVRcombo.getSelectionIndex()>=0)
				{
					

					ruleSelected=refSVRcombo.getText();
					
					
						subinputtree=new ArrayList<TreeTableNodeLine>();
						
						Iterator<TreeTableNodeLine> inputtreeIt=inputtree.iterator();
						while(inputtreeIt.hasNext())
						{
							TreeTableNodeLine treetabnode=inputtreeIt.next();
							String svrname=treetabnode.getSvrrule().toDisplayString();
							if(svrname.equals(ruleSelected)==false)
								subinputtree.add(treetabnode);
							else
								refsvrrule=treetabnode;
						}
						treeViewer.getTree().removeAll();
						treeViewer.refresh();
						treeViewer.setInput( subinputtree);
						treeViewer.refresh();
						treeViewer.expandAll();
					setOKEnabled();
				}
			}

        });
		
		
		Label lblRefSvr = new Label(grpInput, SWT.NONE);
		lblRefSvr.setBounds(111, 66, 107, 20);
		lblRefSvr.setText("Reference SVR :");
		
		comboRevRule = new Combo(grpInput, SWT.NONE);
		comboRevRule.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				revRuleSelected=comboRevRule.getText();
				svrutil.setRevRuleSelected(revRuleSelected);
			   	
				setOKEnabled();
			}
		});
		comboRevRule.setBounds(242, 97, 246, 28);
		
		Label lblNewLabel = new Label(grpInput, SWT.NONE);
		lblNewLabel.setBounds(121, 100, 97, 20);
		lblNewLabel.setText("Revision Rule :");
		
		combo_view = new Combo(grpInput, SWT.NONE);
		combo_view.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				
				viewSelected=combo_view.getText();
			    closureRuleSelected=viewRuleMap.get(viewSelected);
			  //  lblClosureRuleLabel.setText(closureRuleSelected);
				
			    svrutil.setClosureRuleSelected(closureRuleSelected);
			    svrutil.setViewSelected(viewSelected);
				setOKEnabled();
		        
				
			
			}
		});
		combo_view.setBounds(242, 131, 168, 28);
		
		populateViewCombo();
		
		Label lblView = new Label(grpInput, SWT.NONE);
		lblView.setBounds(178, 131, 45, 20);
		lblView.setText("View :");
		
		btnAllArch = new Button(grpInput, SWT.CHECK);
		btnAllArch.setVisible(false);
		btnAllArch.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				allselected=btnAllArch.getSelection();
				
				 svrutil.setAllOption(allselected);
					System.out.println("allselected::"+allselected);
					
			}
		});
		btnAllArch.setBounds(503, 100, 207, 20);
		btnAllArch.setText("Show Blank Architecture");
		
		lblClosureRuleLabel = new Label(grpInput, SWT.NONE);
		lblClosureRuleLabel.setBounds(434, 131, 276, 20);
		
		//Button btndeselectAll = new Button(group, SWT.NONE);
		btndeselectAll.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selck=!selck;
				treeViewer.setAllChecked(selck);
				
				
				String path_chk=null;
				if(selck)
					path_chk="icons/check.jpg";
				else
					path_chk="icons/uncheck.jpg";
						
				
				URL url_chk = FileLocator.find(bundle,
				    new Path(path_chk), null);
					
				btndeselectAll.setImage(ImageDescriptor.createFromURL(url_chk).createImage());
				
				 Object[] bomnode_all=null;
				 ArrayList<TreeItem>  items = new  ArrayList<TreeItem>();
				 if(selck)
				 bomnode_all= treeViewer.getCheckedElements();
				 else
					 bomnode_all=	 getAllTreeItems(tree,items);
				 if(bomnode_all!=null)
				 {
				for(int x=0;x<bomnode_all.length;x++)
				{
				  TreeTableNodeLine ln=(TreeTableNodeLine) bomnode_all[x];
		    	 
		    	  if(selck)
		    	  {
		    		ln.setStatus("Pending");
		    	  }
		    	  else
		    	  {
		    		  ln.setStatus("");
		    	  }
		    	  treeViewer.update(ln, null);
				}
			}
				 
				 Button okbutton= SVRComparisionDialog.this.getButton(IDialogConstants.OK_ID);
		    	  okbutton.setEnabled(false);
		    	  if(treeViewer.getCheckedElements()!=null)
		    	  {
		    		  
		    		 /* if(treeViewer.getCheckedElements().length>0&& svrrule!=null&&fullpath !=null)
		    		  {
		    			  
		    			 // okbutton.setEnabled(true);
		    			  
		    			  
		    		  }
		    		  */
		    		  
		    		  setOKEnabled();
		    	  }	 
				 
				 
			}
		});
	//	btndeselectAll.setBounds(618, 126, 115, 30);
		//btndeselectAll.setText("(De)-Select All");
	
		
		treeViewer.setContentProvider(new TreeContentProvider());//new TableContentProvider());
		Job job = new Job( "Expanding Platform-Revision" ) {
			  @Override
			  protected IStatus run( IProgressMonitor monitor ) {
			    monitor.beginTask( "Expanding Platform-Revision...", IProgressMonitor.UNKNOWN );
			    try
			    {
		
			monitor.subTask( "Expanding.." );
			
			 TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )session.getTypeComponent("BOMWindow"); 
	          TCComponentBOMWindow bomWin = bowWinType.create(null);       // create bom window configured with the default revision rule 
	        
	          TCComponentBOMLine bl= bomWin.setWindowTopLine(null, SVRComparisionDialog.this.selectedObj,null, null);
	          
	          svrutil.setCfg0Perspective(bl);
			
			TCComponent[] allsvr=svrutil.getAllSVRs(SVRComparisionDialog.this.selectedObj);
			
			
			
			
           inputtree =new ArrayList<TreeTableNodeLine>();
           ruleset=new TreeSet<String>();
           
           for(int x=0;x<allsvr.length;x++)
           {
        	   
        	  TCComponentSavedVariantRule svr_rule=(TCComponentSavedVariantRule) allsvr[x];
        	  String desc="NA";
        	  try
        	  {
        	   desc=svr_rule.getTCProperty("object_desc").getDisplayableValue();
        	   ruleset.add(svr_rule.toDisplayString());
           }catch(Exception e)
           {
        	   e.printStackTrace();
           }
        	  TreeTableNodeLine treetab=new  TreeTableNodeLine(false,x+1,svr_rule,desc);
        	  inputtree.add(treetab);
        	  
        	  
           
           }
           
          TCComponentBOMLine parentbl = null;
          
        /*  for (Map.Entry<TCComponentBOMLine ,ArrayList<TreeTableNodeLine>> entry : bl_inputtree.entrySet())  
          {
          	parentbl=entry.getKey();
          	inputtree=entry.getValue();
          	
          	
          	svrutil.setCfg0Perspective(parentbl);
	      	    
             
          } */
          getAllTreeObjects(inputtree);
			Display.getDefault().syncExec(new Runnable()
	        {
	          public void run()
	          {
	        	  
	        	  
          System.out.println("inputtree.size()="+inputtree.size());
          if(inputtree.size()>0)
          {
        	  
        	
        	  ruleary=ruleset.toArray(new String[ruleset.size()]);
        	  refSVRcombo.setItems(ruleary);
        	  refSVRcombo.setText("");
        	  
        	  AutoCompleteComboTextControls.enableContentProposal(refSVRcombo); 
        	  
        	  
        	  TCComponentRevisionRule[] revrule=null;
			try {
				revrule = svrutil.getAllRevRule(session);
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	  
        	  
        	  TreeSet<String> revruleset=new TreeSet<String>();
        	  
        	  
        	  
        	   for(int y=0;y<revrule.length;y++)
	  			{
        		   revruleset.add(revrule[y].toDisplayString());
	  			//	combo.add(rule[y].toDisplayString());
	  			}
	        	
        	   String[] revruleary=revruleset.toArray(new String[revruleset.size()]);
        	  
        	  comboRevRule.setItems(revruleary);
        	//  comboRevRule.setText("Latest Working");
        	  
        	  AutoCompleteComboTextControls.enableContentProposal(comboRevRule);
        	  
        //  treeViewer.setInput( inputtree);
		//	 treeViewer.expandAll();
			 
			          
          }
          setEnabledDisabled(true);
	          }
	        });
	         
          if(parentbl!=null)
      		parentbl.window().close(); 
			
		} catch ( TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			   finally {
			        monitor.done();
			      }
			      return Status.OK_STATUS;
			    }
			  };
			  job.schedule();
		
		/*
		
		area.addControlListener(new ControlAdapter() {
            public void controlResized(ControlEvent e) {
               System.out.println("jghgfgdfdf");
              Rectangle area1 = area.getClientArea();
              Point preferredSize = tree.computeSize(SWT.DEFAULT, SWT.DEFAULT);
              int width = area1.width - 2*tree.getBorderWidth();
              if (preferredSize.y > area1.height + tree.getHeaderHeight()) {
                // Subtract the scrollbar width from the total column width
                // if a vertical scrollbar will be required
                Point vBarSize = tree.getVerticalBar().getSize();
                width -= vBarSize.x;
              }
              Point oldSize = tree.getSize();
              if (oldSize.x > area1.width) {
                // table is getting smaller so make the columns 
                // smaller first and then resize the table to
                // match the client area width
            
                 grpClassificationPropertiesValues.setSize(area1.width, area1.height);
                 searchText.setSize(area1.width, searchText.getSize().y);
                // searchText.setSize(searchText.getSize().x, area1.height-160);
                // tree.setSize(area1.width-10, area1.height-160);
                 
                 tree.setSize(area1.width-20, area1.height-200);
                 int delta=(oldSize.x-area1.width)/(2*tree.getColumnCount());
                 for(int f=0;f<tree.getColumnCount();f++)
                 {
                       
                       tree.getColumn(f).setWidth(tree.getColumn(f).getWidth()-delta);
                       
                 }
              } else {
                // table is getting bigger so make the table 
                // bigger first and then make the columns wider
                // to match the client area width
                 grpClassificationPropertiesValues.setSize(area1.width, area1.height);
                 searchText.setSize(area1.width, searchText.getSize().y);
                 tree.setSize(area1.width-20, area1.height-200);
                 int delta=(area1.width-oldSize.x)/(2*tree.getColumnCount());
                 for(int f=0;f<tree.getColumnCount();f++)
                 {
                       
                       tree.getColumn(f).setWidth(tree.getColumn(f).getWidth()+delta);
                       
                 }
              
              }
            }
          });
  */
		//treeViewer.setLabelProvider(new TreeLabelProvider());
		//treeViewer.setInput("root"); // pass a non-null that will be ignored    
		
			  
			  
	   		  
		treeViewer.addCheckStateListener(new ICheckStateListener() {
		      public void checkStateChanged(CheckStateChangedEvent event) {
		        // If the item is checked . . .
		      
		    	  TreeTableNodeLine ln=(TreeTableNodeLine) event.getElement();
		    	  ln.setSelected(event.getChecked());
		    	  if(event.getChecked())
		    	  ln.setStatus("Pending");
		    	  else
		    		  ln.setStatus("");
		    	  treeViewer.update(ln, null);
		    	  treeViewer.setSubtreeChecked(event.getElement(), event.getChecked());
		        	//checkboxTreeViewer.setGrayChecked(event.getElement(), event.getChecked());
		    	  Button okbutton= SVRComparisionDialog.this.getButton(IDialogConstants.OK_ID);
		    	  okbutton.setEnabled(false);
		    	  treeViewer.refresh();
		    	  if(treeViewer.getCheckedElements()!=null)
		    	  {
		    		  
		    		 /* if(treeViewer.getCheckedElements().length>0&& svrrule!=null&&fullpath !=null)
		    		  {
		    			  
		    			  okbutton.setEnabled(true);
		    		  }
		    		  
		    		  */
		    		  
		    		  setOKEnabled();
		    	  }
		      }
		    });
		    


		 setEnabledDisabled(false);  
		return area;
	}
	
	protected void setOKEnabled() {
		// TODO Auto-generated method stub
		 Button okbutton= SVRComparisionDialog.this.getButton(IDialogConstants.OK_ID);
		 if(okbutton!=null)
		 {
		//if(treeViewer.getCheckedElements()!=null && treeViewer.getCheckedElements().length>0)
	  if(fullpath!=null && viewSelected!=null && revRuleSelected!=null && ruleSelected!=null )
		{
			okbutton.setEnabled(true);
		}
		else
		{
		okbutton.setEnabled(false);
		}
		}
	}
	// used to clear filter search	
	 public void clearFilter()
	 {
		 searchText.setText("");
		 System.out.print("kjk:"+searchText.getText());
		 searchFilter.setSearchText(searchText.getText());
		 
		 treeViewer.refresh();
     	 treeViewer.expandAll();     	
         	
         	 TreeItem[]  items = tree.getItems();//new  ArrayList<TreeItem>();
         	// Object[] bomnode_all=getAllTreeItems(tree,items);
         	 System.out.println("ttt00:"+items.length);
         	 
         	 for(int t=0;t<items.length;t++)
         	 {
 		
         		 
 			 TreeTableNodeLine ln=(TreeTableNodeLine)items[t].getData();
 			
 		      if(ln.getStatus().equals("Pending"))
 			 {
 				//items.get(t).setChecked(true);
 				treeViewer.setChecked(ln, true);
 			
 			 }
         	 }
         	 treeViewer.refresh();
	 }
	 
	 private static void getAllItems(Tree tree, List<TreeItem> allItems)
	 {
		
	     for(TreeItem item : tree.getItems())
	     {
	    	 allItems.add(item);
	         getAllItems(item, allItems);
	     }
	 }
	 
	 public void setEnabledDisabled(boolean editable)
	 {
		 btnBrwButton.setEnabled(editable);
		 refSVRcombo.setEnabled(editable);
		 comboRevRule.setEnabled(editable);
		 combo_view.setEnabled(editable);
		 Button okbutton= SVRComparisionDialog.this.getButton(IDialogConstants.OK_ID);
		 if(okbutton!=null)
   	  	 okbutton.setEnabled(editable);
   	     btndeselectAll.setEnabled(editable);
   	     progressBar.setVisible(!editable);
   	  btnAllArch.setEnabled(editable);
   	    //progressBar.setVisible(false);
	 }

	 private static void getAllItems(TreeItem currentItem, List<TreeItem> allItems)
	 {
	     TreeItem[] children = currentItem.getItems();

	     for(int i = 0; i < children.length; i++)
	     {
	    	 children[i].setExpanded(true);
	    	 
	         allItems.add(children[i]);

	         getAllItems(children[i], allItems);
	     }
	 }
	 
	

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button button = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
				true);
		button.setEnabled(false);
		
		Bundle bundle = FrameworkUtil.getBundle(this.getClass());
		
		// use the org.eclipse.core.runtime.Path as import
		String path="icons/Ok_16x16.png";
			URL	url = FileLocator.find(bundle,
		    new Path(path), null);
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
	
		
		button.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/Ok_16x16.png"));
		button.addSelectionListener(new SelectionAdapter() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		Button button_1 = createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);
		
		
		
		// use the org.eclipse.core.runtime.Path as import
		 path="icons/close_16x16.png";
		 
		
		 url=FileLocator.find(bundle,
		    new Path(path), null);
		imageDescriptor = ImageDescriptor.createFromURL(url);
		button_1.setImage(imageDescriptor.createImage());//ResourceManager.getPluginImage("tm.teamcenter.techspec", "icons/close_16x16.png"));
		
			}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
        Rectangle size=getShell().getDisplay().getPrimaryMonitor().getClientArea();
        //System.out.println("SSSSSSSSSSSSSSSSSSSSSS::"+size);
        return new Point(787,952);//789, 809);

	}
	
	
	
	
	@Override
	   protected void okPressed() {
	       // TODO Auto-generated method stub
	/*	 Thread thread = new Thread(new Runnable() {
			 @Override
		        public void run() {
		 
		Display.getDefault().asyncExec(new Runnable()
        {
          public void run()
          {*/
		final Object[] bomnode=treeViewer.getCheckedElements();
		setEnabledDisabled(false);
		Job job = new Job( "Generating SVR Comparision Report..." ) {
			  @Override
			  protected IStatus run( IProgressMonitor monitor ) {
			    monitor.beginTask( "Generating Report...", IProgressMonitor.UNKNOWN );
			    try
			    {
	try
	{
			 monitor.subTask( "Getting SVR Data.." );
		//	m_rule_gridexptofamilyToValueMap=svrutil.getSVRRuleData();
		
		
		
			//FF
			//svrutil.processModuleCompare(bomnode,bomExpansion.getSvrbom(),fullpath);
		//	svrutil.processModuleCompare1(bomnode,fullpath);
		//monitor.subTask( "Getting Module Data.." );
			svrutil.processSVRCompare(treeViewer,refsvrrule,bomnode,fullpath,incolor,allselected);
			Display.getDefault().asyncExec(new Runnable()
	        {
	          public void run()
	          {
	        	  setEnabledDisabled(true);
			TMLLinkMessageDialog infodlg=new TMLLinkMessageDialog(new File(fullpath),"Report Completed !!. Click to Open",MessageDialog.INFORMATION);
			infodlg.open();
	          }
	        });
	         
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Map<TCComponentItem,Map<IOptionFamily,LinkedHashSet<IOptionValue>>> exptype_fam_val=svrutil.exptype_fam_val;
		Map<TCComponentItem,Map<IOptionFamily, LinkedHashSet<IOptionValue>>> exptype_fam_val1=svrutil.exptype_fam_val1;
			    } finally {
			        monitor.done();
			      }
			      return Status.OK_STATUS;
			    }
			  };
			  job.schedule();
        /*  }
        });
			 }
		 });
		 thread.start();
		*/
		
	      // super.okPressed();
	   }
	
	
	@Override
	   protected void cancelPressed() {
		
	
		  	
		super.cancelPressed();
	}
	
	//used to set the Title in the dialog window
	@Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        newShell.setText("Option values comparison report for  SVR Vs SVR");
       
    } 
}

class TreeContentProvider implements ITreeContentProvider {
	  /**
	   * Gets the children of the specified object
	   * 
	   * @param arg0
	   *            the parent object
	   * @return Object[]
	   */
	  public Object[] getChildren(Object inputElement) {
	    // Return the files and subdirectories in this directory
	    return null;
	  }

	  /**
	   * Gets the parent of the specified object
	   * 
	   * @param arg0
	   *            the object
	   * @return Object
	   */
	  public Object getParent(Object inputElement) {
	    // Return this file's parent file
	    return null;
	  }

	  /**
	   * Returns whether the passed object has children
	   * 
	   * @param arg0
	   *            the parent object
	   * @return boolean
	   */
	  public boolean hasChildren(Object inputElement) {
	    // Get the children
	    Object[] obj = null;

	    // Return whether the parent has children
	    return obj == null ? false : obj.length > 0;
	  }

	  /**
	   * Gets the root element(s) of the tree
	   * 
	   * @param arg0
	   *            the input data
	   * @return Object[]
	   */
	  public Object[] getElements(Object inputElement) {
	    // These are the root elements of the tree
	    // We don't care what arg0 is, because we just want all
	    // the root nodes in the file system
		  return ArrayContentProvider.getInstance().getElements(inputElement);
	  }

	  /**
	   * Disposes any created resources
	   */
	  public void dispose() {
	    // Nothing to dispose
	  }

	  /**
	   * Called when the input changes
	   * 
	   * @param arg0
	   *            the viewer
	   * @param arg1
	   *            the old input
	   * @param arg2
	   *            the new input
	   */
	  public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
	    // Nothing to change
	  }
	}

	/**
	 * This class provides the labels for the file tree
	 */

	