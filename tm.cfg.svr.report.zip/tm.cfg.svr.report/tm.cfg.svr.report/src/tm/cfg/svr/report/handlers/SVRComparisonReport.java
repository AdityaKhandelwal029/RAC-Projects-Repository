package tm.cfg.svr.report.handlers;

import java.util.ArrayList;
import java.util.Map;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;

import tm.cfg.svr.report.ui.SVRComparisionDialog;



import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.common.handlers.AbstractTCHandler;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.pca.common.PCAUtils;
import com.teamcenter.rac.pse.common.BOMLineNode;
import com.teamcenter.rac.pse.common.BOMTreeTableModel;
import com.teamcenter.rac.pse.pca.common.PCAPSEUtils;
import com.teamcenter.rac.pse.services.IPSEUIService;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;


/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class SVRComparisonReport extends AbstractTCHandler {
	/**
	 * The constructor.
	 */
	public SVRComparisonReport() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 */
	
	public void tcExecute() throws Exception {
	
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(this.m_event);
		final Shell shell=window.getShell();
			AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
			final TCSession session=(TCSession) app.getSession();
			System.out.println("Session User:----------  "+session.getUser());
			AIFComponentContext selectedobject=null;
			final ISelection selection = HandlerUtil.getCurrentSelection(this.m_event);
			
			final InterfaceAIFComponent[] selectedobjs=getTargetComponents();
			
			//calling
			
					
		   // selectedobject=(AIFComponentContext)((IStructuredSelection)selection).getFirstElement();
		    
		   
		    if(selectedobjs[0] instanceof TCComponentItemRevision)
		    {
		    	
		    	SVRComparisionDialog dlg=new SVRComparisionDialog(shell,session,SVRComparisonReport.this.m_event, (TCComponentItemRevision)  selectedobjs[0]);
		    	dlg.open();
	                
		    }
		    	
		    
		
		
		return ;
		}
	
}
