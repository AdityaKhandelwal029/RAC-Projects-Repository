package tm.cfg.svr.report;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;

import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.common.IContextInputService;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.OSGIUtil;

/**
 * General class to get the current selected TCComponent / BOMLine objects in TC
 * 
 * @author sbb914605
 * 
 */
public class SelectionUtil
{
	static List<TCComponent>	selectionList	= new ArrayList<TCComponent>();

	public static final List<TCComponent> getSelection()
	{
		List<TCComponent> selectionList = new ArrayList<TCComponent>();
		ISelection selection = Activator.getDefault().getSelectionService().getSelection();
		ISelection m_selection = selection;
		if (selection == null || selection.isEmpty())
		{
			IContextInputService contextInputService = (IContextInputService) OSGIUtil.getService(Activator.getDefault(), IContextInputService.class);
			if (contextInputService != null)
			{
				m_selection = contextInputService.getInput();
			}
		}
		if (m_selection instanceof IStructuredSelection)
		{
			IStructuredSelection sel = (IStructuredSelection) m_selection;
			for (Iterator<?> itr = sel.iterator(); itr.hasNext();)
			{
				Object obj = itr.next();
				TCComponent comp = null;
				AIFComponentContext ctxt = (AIFComponentContext) AdapterUtil.getAdapter(obj, AIFComponentContext.class, true);
				if (ctxt != null)
				{
					comp = (TCComponent) ctxt.getComponent();
				}
				if (comp != null && comp instanceof TCComponent)
				{
					selectionList.add(comp);
				}
			}
		}
		return selectionList;

	}

}
