package tm.cfg.ecu.report;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellUtil;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;

import tm.cfg.svr.report.ui.TMLLinkMessageDialog;

import com.teamcenter.rac.aif.AbstractAIFApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.TCClassService;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;

public class ECU_ParameterPartReport {
	static TCSession session;
	protected Shell shlEcuReport;
	private Text text_Module;
	private Text text_FileLoc;
	String		EcuName		= null;
	String		EcuRev		= null;
	Row row;
	Cell cell;

	/**
	 * Launch the application.
	 * @param args
	 */
	
	
	public void SetECU_Report_PartNameSeq(String Ecu,String Rev)
	{
		System.out.println("Selected Parameter Part ::  " + Ecu +"" +Rev);
		EcuName = Ecu;
		EcuRev = Rev;
	}
	
	
	public static void main(String[] args) {
		try {
			ECUReport window = new ECUReport();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlEcuReport.open();
		shlEcuReport.layout();
		while (!shlEcuReport.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @wbp.parser.entryPoint
	 */
	protected void createContents() {
		shlEcuReport = new Shell();
		shlEcuReport.setSize(665, 381);
		shlEcuReport.setText("ECU Parameter Part Report");
		
		Label lblEcuModule = new Label(shlEcuReport, SWT.NONE);
		lblEcuModule.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblEcuModule.setAlignment(SWT.CENTER);
		lblEcuModule.setBounds(10, 87, 142, 21);
		lblEcuModule.setText("ECU Parameter Part");
		
		text_Module = new Text(shlEcuReport, SWT.BORDER | SWT.READ_ONLY | SWT.SEARCH);
		text_Module.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		text_Module.setBounds(158, 87, 360, 21);
		text_Module.setText(EcuName+"/"+EcuRev);
		
		Label lblFileLocation = new Label(shlEcuReport, SWT.NONE);
		lblFileLocation.setText("File Location");
		lblFileLocation.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblFileLocation.setAlignment(SWT.CENTER);
		lblFileLocation.setBounds(10, 47, 112, 21);
		
		text_FileLoc = new Text(shlEcuReport, SWT.BORDER | SWT.READ_ONLY | SWT.SEARCH);
		text_FileLoc.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		text_FileLoc.setBounds(158, 49, 360, 21);
		
		Button btn_File = new Button(shlEcuReport, SWT.NONE);
		btn_File.setBounds(525, 45, 112, 25);
		btn_File.setText("Select File Location");
		
		Button btnOk = new Button(shlEcuReport, SWT.NONE);
		btnOk.setBounds(185, 223, 75, 25);
		btnOk.setText("OK");
		
		Button btnCancel = new Button(shlEcuReport, SWT.NONE);
		btnCancel.setBounds(310, 223, 75, 25);
		btnCancel.setText("Cancel");
		
		
		
 	   AbstractAIFApplication app1;
 	   try {
   			app1 = new AbstractAIFApplication();
   			session  = (TCSession) app1.getSession();
   		} catch (Exception e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
 	   
 	
		
		btnCancel.addSelectionListener(new SelectionAdapter()
		{
              @Override
              public void widgetSelected(SelectionEvent e)
              {
            	  System.out.println("Cancel Button Press......");
            	  shlEcuReport.dispose();
              }
		});
		
		btnOk.addSelectionListener(new SelectionAdapter()
		{
			@SuppressWarnings("deprecation")
			@Override
			public void widgetSelected(SelectionEvent e)
			{
				System.out.println("ok Button Press......");
				DateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
				Date date = new Date();
				String dateval=dateFormat.format(date);
				System.out.println(dateval);
				
				if (text_FileLoc.getText().isEmpty())
				{
					MessageBox.post("Kindly please select File Location and then proceed.", "Unable To execute report", MessageBox.ERROR);
					
				}
				else
				{
					
					
					String FileName=EcuName+"_"+EcuRev.replace(';','_')+"_";
					String temECURev =EcuRev.replace(';','*');
					
					DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
					String timeStamp = format.format(new Date());
					 
					String filename="ECU_Parameter_Part_Report_"+FileName+timeStamp+".xls";	
					
					System.out.println("\nfilename=>"+filename);
					String fileLoc =text_FileLoc.getText()+"\\"+filename;	
					System.out.println("\nfileLoc=>"+fileLoc);
					 
					System.out.println("Filename"+FileName);
					 
					TCComponentQueryType qtype;
					TCComponentQueryType qtypeRev=null;
					
					try {
						
						qtype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
						
						TCComponentQuery EcuObjquery = (TCComponentQuery) qtype.find("Design Revision");
						TCComponent[] EcuObjArr = null;
						TCComponentItemRevision EcuObject = null;
						
						String[]  qvalue =  new String[] {EcuName,temECURev};
						String[] qname =  new String[] { "ID","Revision"};
						
						EcuObjArr = EcuObjquery.execute(qname, qvalue); 
						
						
					    System.out.println("Number of ECU  Parameter Founds..." + EcuObjArr.length);
					    
					    if (EcuObjArr.length>0)
					    {
					    	EcuObject = (TCComponentItemRevision) EcuObjArr[0];
					    	ArrayList<TCComponentItemRevision> listItem = new ArrayList<TCComponentItemRevision>();
					    	listItem.add(EcuObject);
					    	
					    	 Cell cellTitle;
					    
					    	 Workbook workbook=new HSSFWorkbook();
						    	
						   	 CellStyle cellStyleDataFirst=t5CellStyleDataFirstRow(workbook);
							 CellStyle cellStyleHeader=t5CellStyleHeader(workbook);
							 CellStyle cellStyleData=t5CellStyleData(workbook);
					    	
							Sheet sheetPara = null;
							int rowNumPara=0;
							int SrNosP=0;
							
							workbook.createSheet("ECU Parameter Report");
							sheetPara= workbook.getSheet("ECU Parameter Report");
							
							row = sheetPara.createRow(rowNumPara++);
							
							cellTitle = row.createCell(0);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Serial Nos");
							cellTitle = row.createCell(1);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Parameter   ");
							cellTitle = row.createCell(2);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Parameter Name");
							
							cellTitle = row.createCell(3);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("DID Value");
							
							cellTitle = row.createCell(4);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Parameter Desc");
							cellTitle = row.createCell(5);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Data Type");
							cellTitle = row.createCell(6);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Length");
							
							cellTitle = row.createCell(7);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("List");
							
							cellTitle = row.createCell(8);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Unit");
							
							cellTitle = row.createCell(9);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("ECU Type");
							
							cellTitle = row.createCell(10);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("User Entered value");
							
						/*	cellTitle = row.createCell(11);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Container   ");
							
							cellTitle = row.createCell(12);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Container Rev"); */
							
							cellTitle = row.createCell(11);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Applicability");
							
							cellTitle = row.createCell(12);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Read/Write");
							
							for (int zz=0;zz<listItem.size();zz++)
							{
								String SW_PartType=listItem.get(zz).getStringProperty("t5_SwPartType");
								
								if (SW_PartType==null)
								{
									System.out.println("\n SW_PartType :=> NULL");
								}
								else if (SW_PartType.equals("PRM"))
								{
									System.out.println("\n SW_PartType :=> "+SW_PartType);
									SrNosP++;			
									row = sheetPara.createRow(rowNumPara++);
									

									cellTitle = row.createCell(0);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(SrNosP);
									
									cellTitle = row.createCell(1);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(listItem.get(zz).getStringProperty("current_id"));
									
									String ParEcuType=listItem.get(zz).getStringProperty("t5_EcuType");
									System.out.println("\n ParEcuType :............................=> "+ParEcuType);
									
									//This loop is for container of parameter::And here this will always empty as we are just fatching parameter detials.
									
									/*for (int kk=0;kk<listItem.size();kk++)
									{
										String  ECUType=listItem.get(kk).getStringProperty("t5_EcuType");	
										String  P_PartType=listItem.get(kk).getStringProperty("t5_SwPartType");
										
										if(P_PartType !=null)
										{
											if (P_PartType.equals("CON"))
											{

												if (ParEcuType.equals(ECUType) )
												{
													System.out.println("\n Inside print loop ECUType  P_PartType:...........................=> "+P_PartType);
													System.out.println("\n Inside print loop ECUType :...........................=> "+ECUType);
													cellTitle = row.createCell(10);										 
													cellTitle.setCellStyle(cellStyleData);							 
													cellTitle.setCellValue(listItem.get(kk).getStringProperty("item_id"));

													System.out.println("\n Inside print loop ECUType :...........................=> "+listItem.get(kk).getStringProperty("item_id"));
													cellTitle = row.createCell(11);										 
													cellTitle.setCellStyle(cellStyleData);							 
													cellTitle.setCellValue(listItem.get(kk).getStringProperty("item_revision_id"));

													break;

												}
											}
											
										}
									}*/
									//
									TCComponent[] ParaMaster=null;
									
									ParaMaster=listItem.get(zz).getRelatedComponents("T5_EEPrm");
									int pp =0;
									int orginalRownNumPara=rowNumPara;
									for(pp=0;pp<ParaMaster.length;pp++)
									{
										if ( pp!=0)
										{
											row = sheetPara.createRow(rowNumPara++);
											cellTitle = row.createCell(0);										 
											cellTitle.setCellStyle(cellStyleData);
											cellTitle = row.createCell(1);										 
											cellTitle.setCellStyle(cellStyleData);
											cellTitle = row.createCell(10);										 
											cellTitle.setCellStyle(cellStyleData);
											cellTitle = row.createCell(11);										 
											cellTitle.setCellStyle(cellStyleData);
											
										}
										cellTitle = row.createCell(2);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(ParaMaster[pp].getStringProperty("item_id"));
										
										cellTitle = row.createCell(3);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPDidValue"));
										
										cellTitle = row.createCell(4);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(ParaMaster[pp].getStringProperty("item_id"));
										
										cellTitle = row.createCell(5);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPType"));
										
										cellTitle = row.createCell(6);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPLen"));
										
										cellTitle = row.createCell(7);										 
										cellTitle.setCellStyle(cellStyleData);							 
										///cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPValueList"));
										
										int ListLen=ParaMaster[pp].getTCProperty("t5_EPValueList").getStringArrayValue().length;
										String ParaListStr="";
										System.out.println("\n t5_EPValueList ListLen Para Rel Obj :=> " + ListLen);
										
										if (ListLen > 0)
										{
											int ll=0;
											for (ll=0;ll<ListLen;ll++)
											{
												String ParaStrL=null;
												ParaStrL=ParaMaster[pp].getTCProperty("t5_EPValueList").getStringArrayValue()[ll];
												int ListKK=0;
												if (ParaStrL!=null)
												{
													ListKK++;
													if (ListKK!=1)
													{
														ParaListStr=ParaListStr+"\n";
													}
													ParaListStr=ParaListStr+ParaStrL;
												}
											}
											cellTitle.setCellValue(ParaListStr);
										}
										
										cellTitle = row.createCell(8);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPUnit"));
										
										cellTitle = row.createCell(9);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_ECUType"));
										
										cellTitle = row.createCell(10);										 
										cellTitle.setCellStyle(cellStyleData);
										
										 TCComponent[] ParaRelObj=null;
										 
										 ParaRelObj = QueryParaRel(listItem.get(zz).getStringProperty("item_id"),listItem.get(zz).getStringProperty("item_revision_id"),ParaMaster[pp].getStringProperty("item_id"));
										 if(ParaRelObj==null)
										 {
											 System.out.println("\n NULL Para Rel Obj :=> ");
											 cellTitle.setCellValue(" ");
										 }
										 else if(ParaRelObj.length >0)
							             {
							            	 System.out.println("\n Para Rel Obj :=> "+ParaRelObj[0].getStringProperty("t5_BitValue"));
							            	 cellTitle.setCellValue(ParaRelObj[0].getStringProperty("t5_BitValue"));
							             }
										 String app =ParaMaster[pp].getStringProperty("t5_EPApplicable");
										 
										 cellTitle = row.createCell(11);										 
										 cellTitle.setCellStyle(cellStyleData);							 
										 cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPApplicable"));
										 
										 String read =ParaMaster[pp].getStringProperty("t5_EPReadable");
										 cellTitle = row.createCell(12);										 
										 cellTitle.setCellStyle(cellStyleData);							 
										 cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPReadable"));
										 
									}
									
									if (ParaMaster.length>1)
									{
										sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 0, 0));
										sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 1, 1));
										//sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 10, 10));     
										//sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 11, 11));     

									}
								}
							}
							
							sheetPara.autoSizeColumn(0);
							sheetPara.autoSizeColumn(1);   // 5445E4Z0116007
							sheetPara.autoSizeColumn(2);  
							sheetPara.autoSizeColumn(3);  
							sheetPara.autoSizeColumn(4);  
							sheetPara.autoSizeColumn(5);  
							sheetPara.autoSizeColumn(6);  
							sheetPara.autoSizeColumn(7);  
							sheetPara.autoSizeColumn(8);  
							sheetPara.autoSizeColumn(9);  
							sheetPara.autoSizeColumn(10);  
							sheetPara.autoSizeColumn(11);  
							sheetPara.autoSizeColumn(12);  
							//sheetPara.autoSizeColumn(13); 
							
							 FileOutputStream outputStream = null;	
							 try {

								outputStream = new FileOutputStream(fileLoc);
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}												
							 try {
								workbook.write(outputStream);
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}	
							 
							 try {
								outputStream.close();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
							
							
					    }
					    else
					    {
					    	System.out.println("Parameter not found...");
					    }
					
						
					} catch (TCException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					TMLLinkMessageDialog infodlg=new TMLLinkMessageDialog(new File(fileLoc),"Report Completed !!. Click to Open",MessageDialog.INFORMATION);
					infodlg.open();
					shlEcuReport.dispose();
				}
				
						    

			}
		});
		
		btn_File.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                DirectoryDialog dialog = new DirectoryDialog(shlEcuReport);
                dialog.setFilterPath("c:\\");
                dialog.setText("ECU Parameter part Report Location Selection");

          // Customizable message displayed in the dialog
                dialog.setMessage("Please select a Location");
                text_FileLoc.setText(dialog.open());
                
                //System.out.println("RESULT=" + dialog.open());
            }
      });

	}
	protected CellStyle t5CellStyleDataFirstRow(Workbook workbook)
	{
		System.out.println("\n******INSIDE t5CellStyleDataFirstRow******");
		
		HSSFPalette palette = ((HSSFWorkbook) workbook).getCustomPalette();
		HSSFColor myColor = palette.findSimilarColor(153,255,153);
		short palIndex = myColor.getIndex();
		
		CellStyle style = workbook.createCellStyle();
	    style.setFillForegroundColor(palIndex);
	    style.setFillPattern(FillPatternType.SOLID_FOREGROUND);   
	    Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(font);
        font.setFontHeightInPoints((short)12);
        
        style.setAlignment(HorizontalAlignment.LEFT);
        font.setFontName(HSSFFont.FONT_ARIAL);
        
        style.setBorderBottom(BorderStyle.MEDIUM);
        style.setBorderTop(BorderStyle.MEDIUM);
        style.setBorderRight(BorderStyle.MEDIUM);
        style.setBorderLeft(BorderStyle.MEDIUM);
        
         
       
        return style;
		
	}
	protected CellStyle t5CellStyleHeader(Workbook workbook)
	{
		HSSFPalette palette = ((HSSFWorkbook) workbook).getCustomPalette();
		HSSFColor myColor = palette.findSimilarColor(102,204,255);
		short palIndex = myColor.getIndex();
		
		CellStyle style = workbook.createCellStyle();
	    style.setFillForegroundColor(palIndex);
	    style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	    Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        font.setFontHeightInPoints((short)14);
        style.setFont(font);
        
        style.setBorderBottom(BorderStyle.MEDIUM);
        style.setBorderTop(BorderStyle.MEDIUM);
        style.setBorderRight(BorderStyle.MEDIUM);
        style.setBorderLeft(BorderStyle.MEDIUM);
        
        font.setFontName(HSSFFont.FONT_ARIAL);
        style.setAlignment(HorizontalAlignment.CENTER);
         
       
        return style;
		
	}
	protected CellStyle t5CellStyleData(Workbook workbook)
	{
				
		CellStyle style = workbook.createCellStyle();
	    Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(font);
        font.setFontHeightInPoints((short)12);
        
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setAlignment(HorizontalAlignment.CENTER);
        font.setFontName(HSSFFont.FONT_ARIAL);
        
        style.setBorderBottom(BorderStyle.MEDIUM);
        style.setBorderTop(BorderStyle.MEDIUM);
        style.setBorderRight(BorderStyle.MEDIUM);
        style.setBorderLeft(BorderStyle.MEDIUM);
        style.setWrapText(true);
        
        
        
        return style;
		
	}
	public TCComponent[] QueryParaRel(String ItemId,String ItemRev,String ParaId)
	{     
		   TCComponent[] CtrlObj = null;
		   String[] qvalue;
		   String[] qname;
		   
		   String tempItemRev = ItemRev.replace(';','*');
		   
		   System.out.println("\n----------Query Test Plan For---\n"+ItemId+","+ItemRev+","+ParaId);
		   qname =  new String[] {"ID","Revision","para_item_id"};
		   qvalue =  new String[] {ItemId,tempItemRev,ParaId};
		  
	     
	      
	      
	      TCComponentQueryType qtype;
	      try
	      {
	          qtype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
	          TCComponentQuery CtrlObjquery = (TCComponentQuery) qtype.find("EE_Parameter_Relation");
	          if (CtrlObjquery != null)
	          {
	        	  CtrlObj = CtrlObjquery.execute(qname, qvalue); 
	        	  System.out.println("Number of EE para Relation Founds..." + CtrlObj.length);
	          }
	      }
	      catch (TCException e1)
	      {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
	      }
      return CtrlObj;
	}
}
