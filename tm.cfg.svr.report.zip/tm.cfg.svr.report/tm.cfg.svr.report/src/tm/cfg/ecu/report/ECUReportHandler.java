package tm.cfg.ecu.report;
import java.util.ArrayList;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;


import com.teamcenter.rac.kernel.TCComponentItemRevision;
import tm.cfg.svr.report.SelectionUtil;


import com.teamcenter.rac.util.MessageBox;





public class ECUReportHandler extends AbstractHandler
{
	TCComponentItemRevision	Item_rev;
	ArrayList<String>		PartNumberRevSeq	= new ArrayList<String>();
	String					ModNameRev			= null;
	String					ModName			= null;

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException
	{
		try
		{
			System.out.println("Inside ECUReportHandler");
			
			if (SelectionUtil.getSelection().size() ==1)
			{

				if (SelectionUtil.getSelection().get(0).getStringProperty("t5_PartType").equals("EM") ) {
					
					ModName=SelectionUtil.getSelection().get(0).getStringProperty("item_id");
					ModNameRev=SelectionUtil.getSelection().get(0).getStringProperty("item_revision_id");
					
					ECUReport EcuDialog = new ECUReport();
					EcuDialog.SetECU_Report_PartNameSeq(ModName,ModNameRev);
					EcuDialog.open();
					
					
				} else {
					MessageBox.post("Kindly please select ECU Module Revision.",
									"Error", MessageBox.ERROR);
				}
			}
			else
			{
				MessageBox.post("Kindly please select single ECU Module.",
						"Error", MessageBox.ERROR);
				
			}
			
			
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return null;
	}
}
