package tm.cfg.ecu.report;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellUtil;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;

import tm.cfg.svr.report.ui.TMLLinkMessageDialog;

import com.teamcenter.rac.aif.AbstractAIFApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.TCClassService;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;

public class ECUReport {
	static TCSession session;
	protected Shell shlEcuReport;
	private Text text_Module;
	private Text text_FileLoc;
	String		EcuName		= null;
	String		EcuRev		= null;
	private Combo combo_RevRule;
	Row row;
	Cell cell;

	/**
	 * Launch the application.
	 * @param args
	 */
	
	
	public void SetECU_Report_PartNameSeq(String Ecu,String Rev)
	{
		System.out.println("Selected Domain:  " + Ecu +"" +Rev);
		EcuName = Ecu;
		EcuRev = Rev;
	}
	
	
	public static void main(String[] args) {
		try {
			ECUReport window = new ECUReport();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlEcuReport.open();
		shlEcuReport.layout();
		while (!shlEcuReport.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlEcuReport = new Shell();
		shlEcuReport.setSize(665, 381);
		shlEcuReport.setText("ECU Report");
		
		Label lblEcuModule = new Label(shlEcuReport, SWT.NONE);
		lblEcuModule.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblEcuModule.setAlignment(SWT.CENTER);
		lblEcuModule.setBounds(37, 87, 103, 21);
		lblEcuModule.setText("ECU Module");
		
		text_Module = new Text(shlEcuReport, SWT.BORDER | SWT.READ_ONLY | SWT.SEARCH);
		text_Module.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		text_Module.setBounds(158, 87, 360, 21);
		text_Module.setText(EcuName+"/"+EcuRev);
		
		Label lblRevisionRule = new Label(shlEcuReport, SWT.NONE);
		lblRevisionRule.setText("Revision Rule");
		lblRevisionRule.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblRevisionRule.setAlignment(SWT.CENTER);
		lblRevisionRule.setBounds(37, 129, 103, 21);
		
		Label lblFileLocation = new Label(shlEcuReport, SWT.NONE);
		lblFileLocation.setText("File Location");
		lblFileLocation.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblFileLocation.setAlignment(SWT.CENTER);
		lblFileLocation.setBounds(37, 49, 103, 21);
		
		text_FileLoc = new Text(shlEcuReport, SWT.BORDER | SWT.READ_ONLY | SWT.SEARCH);
		text_FileLoc.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		text_FileLoc.setBounds(158, 49, 360, 21);
		
		Button btn_File = new Button(shlEcuReport, SWT.NONE);
		btn_File.setBounds(525, 45, 112, 25);
		btn_File.setText("Select File Location");
		
		combo_RevRule = new Combo(shlEcuReport, SWT.NONE);
		//combo_RevRule.setItems(new String[] {"ERC Review And Above", "Latest Working"});
		combo_RevRule.setBounds(159, 129, 359, 23);
		
		Button btnOk = new Button(shlEcuReport, SWT.NONE);
		btnOk.setBounds(102, 192, 75, 25);
		btnOk.setText("OK");
		
		Button btnCancel = new Button(shlEcuReport, SWT.NONE);
		btnCancel.setBounds(365, 192, 75, 25);
		btnCancel.setText("Cancel");
		
		
		
 	   AbstractAIFApplication app1;
 	   try {
   			app1 = new AbstractAIFApplication();
   			session  = (TCSession) app1.getSession();
   		} catch (Exception e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
 	   
 	  GetRevRuleLOV();
		
		btnCancel.addSelectionListener(new SelectionAdapter()
		{
              @Override
              public void widgetSelected(SelectionEvent e)
              {
            	  System.out.println("Cancel Button Press......");
            	  shlEcuReport.dispose();
              }
		});
		
		btnOk.addSelectionListener(new SelectionAdapter()
		{
			@Override
			public void widgetSelected(SelectionEvent e)
			{
				System.out.println("ok Button Press......");
						    
	        	DateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
				Date date = new Date();
				String dateval=dateFormat.format(date);
				System.out.println(dateval);
				
				if (combo_RevRule.getText().isEmpty())
				{
					MessageBox.post("Kindly please select Revision Rule and then proceed.", "Unable To execute report", MessageBox.ERROR);
					
				}
				else if (text_FileLoc.getText().isEmpty())
				{
					MessageBox.post("Kindly please select File Location and then proceed.", "Unable To execute report", MessageBox.ERROR);
					
				}
				else
				{
					
				
				String RevRule=combo_RevRule.getText();
				
				String FileName=EcuName+"_"+EcuRev.replace(';','_')+"_";
				
				String temECURev =EcuRev.replace(';','*');
				
				
				 DateFormat format = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
				 String timeStamp = format.format(new Date());
				
				 String filename="ECU_Details_"+FileName+timeStamp+".xls";	
				 System.out.println("\nfilename=>"+filename);
				 String fileLoc =text_FileLoc.getText()+"\\"+filename;	
				 System.out.println("\nfileLoc=>"+fileLoc);
				 
				System.out.println("Filename"+FileName);
				TCComponentQueryType qtype;
				TCComponentQueryType qtypeRev=null;
				try {
					qtype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");

					TCComponentQuery EcuObjquery = (TCComponentQuery) qtype.find("Design Revision");
					TCComponent[] EcuObjArr = null;
					TCComponentItemRevision EcuObject = null;
					TCComponentBOMLine topBomLine=null;

					String[]  qvalue =  new String[] {EcuName,temECURev};
					String[] qname =  new String[] { "ID","Revision"};
					
					EcuObjArr = EcuObjquery.execute(qname, qvalue); 
				    System.out.println("Number of ECU Founds..." + EcuObjArr.length);   ///5445E2C0554001  // 5445E4Z0116007
				    
				    if (EcuObjArr.length>0)
				    {
				    	EcuObject=(TCComponentItemRevision) EcuObjArr[0];
				    	
						String[]  qvalueRev =  new String[] {"RevisionRule",RevRule};
						String[] qnameRev =  new String[] { "Type","Name"};
						TCComponent[] RevRuleObjArr = null;
						TCComponent RevRuleObj = null;
						//qtypeRev = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
						//if (qtypeRev==null) System.out.println("qTypeRev not found");
						//TCComponentQuery RevRuleObjquery = (TCComponentQuery) qtypeRev.find("General...");
						//if (RevRuleObjquery==null) System.out.println("RevRuleObjquery not found");
						//RevRuleObjArr = RevRuleObjquery.execute(qvalueRev, qnameRev); 
						
						//System.out.println("RevRuleObjquery length"+RevRuleObjArr.length);
						
						//if (RevRuleObjArr.length>0)
						//{
							//RevRuleObj=RevRuleObjArr[0];
						//}
						
						
						@SuppressWarnings("deprecation")
						TCClassService classService = session.getClassService();				
						@SuppressWarnings("deprecation")
						TCComponent[] RevisionRules = null;
						try {
							RevisionRules = classService.findByClass("RevisionRule", "object_type", "RevisionRule");
						} catch (TCException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
						
						int flagRevRule=0;
						
						for(TCComponent revTemp: RevisionRules)
						{

								System.out.println("Revision Rule Name-->"+revTemp.getStringProperty("object_name"));
								
								if(revTemp.getStringProperty("object_name").equals(RevRule))
								{
									flagRevRule=1;
									RevRuleObj= revTemp;
									break;
								}

						}
				    	
				    	TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )session.getTypeComponent("BOMWindow");
				    	TCComponentBOMWindow bomWin = bowWinType.create((TCComponentRevisionRule)RevRuleObj);
				    	topBomLine =bomWin.setWindowTopLine(null, EcuObject, null, null);
				    	
				    	int reqlvl=99;
						int lvl=0;
						ArrayList<TCComponentItemRevision> listItem = new ArrayList<TCComponentItemRevision>();
						ArrayList<TCComponentBOMLine> listBOMLine = new ArrayList<TCComponentBOMLine>();
						ArrayList<String> listBOMLineLvl = new ArrayList<String>();
						ArrayList<String> listBOMLineParent = new ArrayList<String>();
						
	
						if(!listItem.isEmpty())
							listItem.clear();
						
						if(!listBOMLine.isEmpty())
							listBOMLine.clear();
						
						if(!listBOMLineLvl.isEmpty())
							listBOMLineLvl.clear();
						if(!listBOMLineLvl.isEmpty())
							listBOMLineLvl.clear();
						
						if(!listBOMLineParent.isEmpty())
							listBOMLineParent.clear();
						int status =t5MultiGetBOMExpEcu(topBomLine,reqlvl,lvl,listItem,listBOMLine,listBOMLineLvl,listBOMLineParent);	
						System.out.println("\n******Inside t5MultiGetMBOMGetExp********>>>>>>>"+status);


						
						
						Sheet sheet = null;
						
						Workbook workbook=new HSSFWorkbook();;
						workbook.createSheet("ECU BOM Report");
						
						sheet= workbook.getSheet("ECU BOM Report");
						
						CellStyle cellStyleDataFirst=t5CellStyleDataFirstRow(workbook);
						CellStyle cellStyleHeader=t5CellStyleHeader(workbook);
						CellStyle cellStyleData=t5CellStyleData(workbook);
						
						int rowNum=0;
						  Cell cellTitle;
						  TCComponent[] Dataset_CAD=null;
						  
							row = sheet.createRow(rowNum++);
							
							cellTitle = row.createCell(0);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Level");
							cellTitle = row.createCell(1);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Part Nos");
							cellTitle = row.createCell(2);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Revision");
							cellTitle = row.createCell(3);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Software Part Type");
							cellTitle = row.createCell(4);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("ECU part Type");
							cellTitle = row.createCell(5);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Applicable For EOL/Service");
							cellTitle = row.createCell(6);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Read/Write");
							cellTitle = row.createCell(7);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Dataset");
							cellTitle = row.createCell(8);										 
							cellTitle.setCellStyle(cellStyleHeader);							 
							cellTitle.setCellValue("Named Reference");
							
							row = sheet.createRow(rowNum++);
							
							cellTitle = row.createCell(0);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue("0");
							
							cellTitle = row.createCell(1);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(EcuObject.getStringProperty("current_id"));
							
							
							cellTitle = row.createCell(2);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(EcuObject.getStringProperty("item_revision_id"));
							
						for (int zz=0;zz<listItem.size();zz++)
						{
							System.out.println("\n childPrtNumM :=> "+ listItem.get(zz).getStringProperty("current_id"));
							
							
							row = null;
							cellTitle= null;
							Dataset_CAD=null;
							 
							row = sheet.createRow(rowNum++);
							
							cellTitle = row.createCell(0);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(listBOMLineLvl.get(zz));
							
							cellTitle = row.createCell(1);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(listItem.get(zz).getStringProperty("current_id"));
							
							
							cellTitle = row.createCell(2);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(listItem.get(zz).getStringProperty("item_revision_id"));
							
							cellTitle = row.createCell(3);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(listItem.get(zz).getStringProperty("t5_SwPartType"));
							
							
							cellTitle = row.createCell(4);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(listItem.get(zz).getStringProperty("t5_EcuType"));
							
							
							cellTitle = row.createCell(5);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(listItem.get(zz).getStringProperty("t5_AppForEOL"));
							
							
							cellTitle = row.createCell(6);										 
							cellTitle.setCellStyle(cellStyleData);							 
							cellTitle.setCellValue(listItem.get(zz).getStringProperty("t5_EPReadable"));
							
							Dataset_CAD=listItem.get(zz).getRelatedComponents("IMAN_specification");  ///
							///object_name
							int i=0;
							System.out.println("\n childPrtNumM :=> "+Dataset_CAD.length +"row  "+rowNum);
							if (Dataset_CAD.length > 0)
							{ 
								int orginalRownNum=rowNum;
								for(i=0;i<Dataset_CAD.length;i++)
								{
									if ( i!=0)
									{
										row = sheet.createRow(rowNum++);
										cellTitle = row.createCell(0);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(1);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(2);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(3);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(4);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(5);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(6);										 
										cellTitle.setCellStyle(cellStyleData);

										
									}
									
									System.out.println("\n Dataset_CAD :=> "+Dataset_CAD[i].getStringProperty("object_name"));
									
									cellTitle = row.createCell(7);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(Dataset_CAD[i].getStringProperty("object_name"));
									cellTitle = row.createCell(8);										 
									cellTitle.setCellStyle(cellStyleData);
									if (Dataset_CAD[i].getRelatedComponents("ref_list").length>0)
									{
										cellTitle.setCellValue((Dataset_CAD[i].getRelatedComponents("ref_list"))[0].getStringProperty("original_file_name"));
									}
								}                                    // 5445E4Z0116007
								
								if (Dataset_CAD.length>1)
								{
								sheet.addMergedRegion(new CellRangeAddress(orginalRownNum-1,rowNum-1, 0, 0));
								sheet.addMergedRegion(new CellRangeAddress(orginalRownNum-1,rowNum-1, 1, 1));     
								sheet.addMergedRegion(new CellRangeAddress(orginalRownNum-1,rowNum-1, 2, 2));
								sheet.addMergedRegion(new CellRangeAddress(orginalRownNum-1,rowNum-1, 3, 3));
								sheet.addMergedRegion(new CellRangeAddress(orginalRownNum-1,rowNum-1, 4, 4));
								sheet.addMergedRegion(new CellRangeAddress(orginalRownNum-1,rowNum-1, 5, 5));
								sheet.addMergedRegion(new CellRangeAddress(orginalRownNum-1,rowNum-1, 6, 6));
								}
							}
						
						}
						
						sheet.autoSizeColumn(0);
						sheet.autoSizeColumn(1);
						sheet.autoSizeColumn(2);
						sheet.autoSizeColumn(3);
						sheet.autoSizeColumn(4);
						sheet.autoSizeColumn(5);
						sheet.autoSizeColumn(6);
						sheet.autoSizeColumn(7);
						sheet.autoSizeColumn(8);
						
						
						
						
						
						/////////////////////////////container Report start/////////////////////////////////
						
						Sheet sheetCont = null;
						int rowNumCont=0;
						int SrNos=0;
						
						workbook.createSheet("ECU Container Report");
						sheetCont= workbook.getSheet("ECU Container Report");
						
						
						row = sheetCont.createRow(rowNumCont++);
						
						cellTitle = row.createCell(0);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Serial Nos");
						cellTitle = row.createCell(1);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Container Part Nos");
						cellTitle = row.createCell(2);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Container Revision");
						cellTitle = row.createCell(3);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Cal_Part");
						cellTitle = row.createCell(4);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Cal_Part_Rev");
						cellTitle = row.createCell(5);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("ECU Type");
						
						cellTitle = row.createCell(6);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("HW_Part");
						
						cellTitle = row.createCell(7);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("HW_Rev");
						
						cellTitle = row.createCell(8);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("CFG_Part");
						
						cellTitle = row.createCell(9);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("CFG_Part_Rev");
						
						cellTitle = row.createCell(10);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("APP_Part");
						
						cellTitle = row.createCell(11);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("APP_Part_Rev");
						
						cellTitle = row.createCell(12);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("PBL_Part");
						
						cellTitle = row.createCell(13);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("PBL_Part_Rev");
						
						cellTitle = row.createCell(14);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("SBL_Part");
						
						cellTitle = row.createCell(15);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("SBL_Part_Rev");
						
						for (int zz=0;zz<listItem.size();zz++)
						{
							//String SW_PartType ="";
							String SW_PartType=listItem.get(zz).getStringProperty("t5_SwPartType");
							
							
							
							if (SW_PartType!=null)
							{
										System.out.println("\n SW_PartType :=> "+SW_PartType);
									if (SW_PartType.equals("CON"))
									{
										SrNos++;			
										row = sheetCont.createRow(rowNumCont++);
										
										cellTitle = row.createCell(0);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(SrNos);
										
										cellTitle = row.createCell(1);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(listItem.get(zz).getStringProperty("current_id"));
										
										cellTitle = row.createCell(2);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(listItem.get(zz).getStringProperty("item_revision_id"));
										
										cellTitle = row.createCell(5);										 
										cellTitle.setCellStyle(cellStyleData);							 
										cellTitle.setCellValue(listItem.get(zz).getStringProperty("t5_EcuType"));
										
										TCComponentBOMLine TcBOMLine=listBOMLine.get(zz);
										AIFComponentContext[] ChildPrtsC = null;
										
										ChildPrtsC = TcBOMLine.getChildren();
		
										
										for(int chld=0;chld<ChildPrtsC.length;chld++)
										{
		
											TCComponentBOMLine childbomC = null;
											TCComponentItemRevision childcompC=null;
										    
										    	childbomC =  (TCComponentBOMLine) ChildPrtsC[chld].getComponent();
		
										   		childcompC=childbomC.getItemRevision();	
										   		
										   		if(childcompC !=null)
										   		{
										   			//String SW_PartTypeC = "";
										   			String SW_PartTypeC=childcompC.getStringProperty("t5_SwPartType");
											   		
											   		if (SW_PartTypeC==null)
											   		{
											   			System.out.println("\n SW_PartType :=> null");
											   		}
											   		else if (SW_PartTypeC.equals("CAL"))
											   		{
														cellTitle = row.createCell(3);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("current_id"));
														
														//CellUtil.setCellStyleProperty(cellTitle, arg1, arg2, arg3)   setCellProperty(cell, CellUtil.VERTICAL_ALIGNMENT, CellStyle.VERTICAL_CENTER);
														
														cellTitle = row.createCell(4);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("item_revision_id"));
											   		}
											   		else if (SW_PartTypeC.equals("HWC"))
											   		{
														cellTitle = row.createCell(6);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("current_id"));
														
														cellTitle = row.createCell(7);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("item_revision_id"));
											   		}
											   		else if (SW_PartTypeC.equals("CFG"))
											   		{
														cellTitle = row.createCell(8);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("current_id"));
														
														cellTitle = row.createCell(9);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("item_revision_id"));
											   		}
											   		else if (SW_PartTypeC.equals("APP"))
											   		{
														cellTitle = row.createCell(10);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("current_id"));
														
														cellTitle = row.createCell(11);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("item_revision_id"));
											   		}
											   		else if (SW_PartTypeC.equals("PBL"))
											   		{
														cellTitle = row.createCell(12);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("current_id"));
														
														cellTitle = row.createCell(13);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("item_revision_id"));
											   		}
											   		else if (SW_PartTypeC.equals("SBL"))
											   		{
														cellTitle = row.createCell(14);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("current_id"));
														
														cellTitle = row.createCell(15);										 
														cellTitle.setCellStyle(cellStyleData);							 
														cellTitle.setCellValue(childcompC.getStringProperty("item_revision_id"));
											   		}
										   		}
										   	
		
										   			
										}
										
										
									}
								}
						}
						
						sheetCont.autoSizeColumn(0);
						sheetCont.autoSizeColumn(1);   // 5445E4Z0116007
						sheetCont.autoSizeColumn(2);  
						sheetCont.autoSizeColumn(3);  
						sheetCont.autoSizeColumn(4);  
						sheetCont.autoSizeColumn(5);  
						sheetCont.autoSizeColumn(6);  
						sheetCont.autoSizeColumn(7);  
						sheetCont.autoSizeColumn(8);  
						sheetCont.autoSizeColumn(9);  
						sheetCont.autoSizeColumn(10);  
						sheetCont.autoSizeColumn(11);  
						sheetCont.autoSizeColumn(12);  
						sheetCont.autoSizeColumn(13);  
						sheetCont.autoSizeColumn(14);  
						sheetCont.autoSizeColumn(15);  
						

						
						
						
						//////////////////////////////Parameter Report start////////////////////////////////////////////////////////////
						

						/////////////////////////////container Report start/////////////////////////////////
						
						Sheet sheetPara = null;
						int rowNumPara=0;
						int SrNosP=0;
						
						workbook.createSheet("ECU Parameter Report");
						sheetPara= workbook.getSheet("ECU Parameter Report");
						
						
						row = sheetPara.createRow(rowNumPara++);
						
						cellTitle = row.createCell(0);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Serial Nos");
						cellTitle = row.createCell(1);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Parameter   ");
						cellTitle = row.createCell(2);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Parameter Name");
						cellTitle = row.createCell(3);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Parameter Desc");
						cellTitle = row.createCell(4);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Parameter Type ");
						cellTitle = row.createCell(5);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Length");
						
						cellTitle = row.createCell(6);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("List");
						
						cellTitle = row.createCell(7);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Unit");
						
						cellTitle = row.createCell(8);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("ECU Type");
						
						cellTitle = row.createCell(9);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Default Value");
						
						cellTitle = row.createCell(10);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Container   ");
						
						cellTitle = row.createCell(11);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Container Rev");
						
						cellTitle = row.createCell(12);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Applicability");
						
						cellTitle = row.createCell(13);										 
						cellTitle.setCellStyle(cellStyleHeader);							 
						cellTitle.setCellValue("Read/Write");
						

						
						for (int zz=0;zz<listItem.size();zz++)
						{
							//String SW_PartType ="";
							String SW_PartType=listItem.get(zz).getStringProperty("t5_SwPartType");
							
							
							
							if (SW_PartType==null)
							{
								System.out.println("\n SW_PartType :=> NULL");
							}
							else if (SW_PartType.equals("PRM"))
							{
								System.out.println("\n SW_PartType :=> "+SW_PartType);
								SrNosP++;			
								row = sheetPara.createRow(rowNumPara++);
								
								cellTitle = row.createCell(0);										 
								cellTitle.setCellStyle(cellStyleData);							 
								cellTitle.setCellValue(SrNosP);
								
								cellTitle = row.createCell(1);										 
								cellTitle.setCellStyle(cellStyleData);							 
								cellTitle.setCellValue(listItem.get(zz).getStringProperty("current_id"));
								
								String ParEcuType=listItem.get(zz).getStringProperty("t5_EcuType");
								System.out.println("\n ParEcuType :............................=> "+ParEcuType);
								
								
								
								for (int kk=0;kk<listItem.size();kk++)
								{
									//String  ECUType ="";
									//String P_PartType ="";
									
									String  ECUType=listItem.get(kk).getStringProperty("t5_EcuType");	
									String  P_PartType=listItem.get(kk).getStringProperty("t5_SwPartType");
									
									//System.out.println("\n ECUType :=> "+ECUType);
									if(P_PartType !=null)
									{
										if (P_PartType.equals("CON"))
										{

											if (ParEcuType.equals(ECUType) )
											{
												System.out.println("\n Inside print loop ECUType  P_PartType:...........................=> "+P_PartType);
												System.out.println("\n Inside print loop ECUType :...........................=> "+ECUType);
												cellTitle = row.createCell(10);										 
												cellTitle.setCellStyle(cellStyleData);							 
												cellTitle.setCellValue(listItem.get(kk).getStringProperty("item_id"));

												System.out.println("\n Inside print loop ECUType :...........................=> "+listItem.get(kk).getStringProperty("item_id"));
												cellTitle = row.createCell(11);										 
												cellTitle.setCellStyle(cellStyleData);							 
												cellTitle.setCellValue(listItem.get(kk).getStringProperty("item_revision_id"));

												break;

											}
										}
										
									}
									
									
									
									
								}
								

								
								TCComponent[] ParaMaster=null;
								
								ParaMaster=listItem.get(zz).getRelatedComponents("T5_EEPrm");
								
								
								
								
								
								int pp =0;
								int orginalRownNumPara=rowNumPara;
								for(pp=0;pp<ParaMaster.length;pp++)
								{
									
									if ( pp!=0)
									{
										row = sheetPara.createRow(rowNumPara++);
										cellTitle = row.createCell(0);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(1);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(10);										 
										cellTitle.setCellStyle(cellStyleData);
										cellTitle = row.createCell(11);										 
										cellTitle.setCellStyle(cellStyleData);


										
									}
									cellTitle = row.createCell(2);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("item_id")+";"+ParaMaster[pp].getStringProperty("t5_EPDidValue"));
									
									
									cellTitle = row.createCell(3);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("item_id"));
									
									
									cellTitle = row.createCell(4);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPType"));
									
									
									cellTitle = row.createCell(5);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPLen"));
									
									
									cellTitle = row.createCell(6);										 
									cellTitle.setCellStyle(cellStyleData);							 
									///cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPValueList"));
									
									int ListLen=ParaMaster[pp].getTCProperty("t5_EPValueList").getStringArrayValue().length;
									String ParaListStr="";
									System.out.println("\n t5_EPValueList ListLen Para Rel Obj :=> " + ListLen);
									if (ListLen > 0)
									{
										int ll=0;
										for (ll=0;ll<ListLen;ll++)
										{
											String ParaStrL=null;
											ParaStrL=ParaMaster[pp].getTCProperty("t5_EPValueList").getStringArrayValue()[ll];
											int ListKK=0;
											if (ParaStrL!=null)
											{
												ListKK++;
												if (ListKK!=1)
												{
													ParaListStr=ParaListStr+"\n";
												}
												ParaListStr=ParaListStr+ParaStrL;
											}

										}
										//cellTitle.setCellStyle(wrapStyle);								
										cellTitle.setCellValue(ParaListStr);
									}
									
									
									cellTitle = row.createCell(7);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPUnit"));
									
									
									cellTitle = row.createCell(8);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_ECUType"));
									
									
									cellTitle = row.createCell(9);										 
									cellTitle.setCellStyle(cellStyleData);
									
									 TCComponent[] ParaRelObj=null;
											 ParaRelObj = QueryParaRel(listItem.get(zz).getStringProperty("item_id"),listItem.get(zz).getStringProperty("item_revision_id"),ParaMaster[pp].getStringProperty("item_id"));
									//cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPValueList"));  ///t5_BitValue
									 
									 if(ParaRelObj==null)
									 {
										 System.out.println("\n NULL Para Rel Obj :=> ");
										 cellTitle.setCellValue(" ");
									 }
									 else if(ParaRelObj.length >0)
						             {
						            	 System.out.println("\n Para Rel Obj :=> "+ParaRelObj[0].getStringProperty("t5_BitValue"));
						            	 cellTitle.setCellValue(ParaRelObj[0].getStringProperty("t5_BitValue"));
						             }
									
									

									
									cellTitle = row.createCell(12);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPApplicable"));
									
									
									cellTitle = row.createCell(13);										 
									cellTitle.setCellStyle(cellStyleData);							 
									cellTitle.setCellValue(ParaMaster[pp].getStringProperty("t5_EPReadable"));
									
									
									
								}
								

								
								if (ParaMaster.length>1)
								{
									sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 0, 0));
									sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 1, 1));     
									sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 10, 10));     
									sheetPara.addMergedRegion(new CellRangeAddress(orginalRownNumPara-1,rowNumPara-1, 11, 11));     

								}
							}
						}
						
						
						sheetPara.autoSizeColumn(0);
						sheetPara.autoSizeColumn(1);   // 5445E4Z0116007
						sheetPara.autoSizeColumn(2);  
						sheetPara.autoSizeColumn(3);  
						sheetPara.autoSizeColumn(4);  
						sheetPara.autoSizeColumn(5);  
						sheetPara.autoSizeColumn(6);  
						sheetPara.autoSizeColumn(7);  
						sheetPara.autoSizeColumn(8);  
						sheetPara.autoSizeColumn(9);  
						sheetPara.autoSizeColumn(10);  
						sheetPara.autoSizeColumn(11);  
						sheetPara.autoSizeColumn(12);  
						sheetPara.autoSizeColumn(13); 
						
						
						
						
						
						/////////////////////////////////////END////////////////////////////////////////////////////////////
	

						 
						 
						
						 FileOutputStream outputStream = null;	
						 try {

							outputStream = new FileOutputStream(fileLoc);
						} catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}												
						 try {
							workbook.write(outputStream);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}	
						 
						 try {
							outputStream.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
							
				    	

						
					

				    }
				    else
				    {
				    	 System.out.println("more than 1 ECU Found..." + EcuObjArr.length);
				    }
				
				} catch (TCException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
      	      	//String AllAltPrtList = null;
	           //AllAltPrtList = "File Wrote Successfully and present at........ "+FileName;
	             //MessageBox.post(AllAltPrtList, "Report Completed", MessageBox.INFORMATION);
	             
	             
	             
	 			TMLLinkMessageDialog infodlg=new TMLLinkMessageDialog(new File(fileLoc),"Report Completed !!. Click to Open",MessageDialog.INFORMATION);
				infodlg.open();
				shlEcuReport.dispose();
			}
			}
		});
		
		btn_File.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                DirectoryDialog dialog = new DirectoryDialog(shlEcuReport);
                dialog.setFilterPath("c:\\");
                dialog.setText("ECU Module Report Location Selection");

          // Customizable message displayed in the dialog
                dialog.setMessage("Please select a Location");
                text_FileLoc.setText(dialog.open());
                
                //System.out.println("RESULT=" + dialog.open());
            }
      });

	}
	
	protected int t5MultiGetBOMExpEcu( TCComponentBOMLine topBomLine,int reqLvl,int lvl,ArrayList<TCComponentItemRevision> listItem,ArrayList<TCComponentBOMLine> listBOMLine,ArrayList<String> listBOMLineLvl,ArrayList<String> listBOMLineParent)
	{	
	int childcount=0;
	int statusi=0;
	AIFComponentContext[] ChildPrts = null;
	String ParentPart=null;
	String ParentPartRev=null;
	
	
	try {
		
		if(lvl>=reqLvl)
			return 1;
		ChildPrts = topBomLine.getChildren();
		
		ParentPart=topBomLine.getStringProperty("bl_item_item_id");
		ParentPartRev=topBomLine.getStringProperty("bl_rev_item_revision_id");
		
		
		System.out.println("\n ParentPartRev num  : "+ ParentPart +"/"+ParentPartRev);

	childcount=ChildPrts.length;
	lvl=lvl+1;
	System.out.println("\n childcount num  : "+ childcount);
	for(int chld=0;chld<childcount;chld++)
	{

		TCComponentBOMLine childbom = null;
		TCComponentItemRevision childcomp=null;
	    
	    	childbom =  (TCComponentBOMLine) ChildPrts[chld].getComponent();

	   		childcomp=childbom.getItemRevision();	
	   			
	   		if(childcomp!=null)
	   		{
		   		    String childPrtNumM=childcomp.getStringProperty("current_id");		
					System.out.println("\n childPrtNumM : "+ childPrtNumM);
					
		   		    String EPartType = null;	
 		   		EPartType = childcomp.getProperty("t5_PartType");
 		   		System.out.println("Expansion EPartType: " + EPartType);
 		   		
		   		listItem.add(childcomp);
				listBOMLine.add(childbom);
				listBOMLineLvl.add(String.valueOf(lvl));
				listBOMLineParent.add(ParentPart+"/"+ParentPartRev);
				
				 statusi= t5MultiGetBOMExpEcu(childbom,reqLvl,lvl,listItem,listBOMLine,listBOMLineLvl,listBOMLineParent);
	   		 }
	    	
	}
	lvl=lvl-1;
	} catch (TCException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return 1;	
	}
	
	protected CellStyle t5CellStyleDataFirstRow(Workbook workbook)
	{
		System.out.println("\n******INSIDE t5CellStyleDataFirstRow******");
		
		HSSFPalette palette = ((HSSFWorkbook) workbook).getCustomPalette();
		HSSFColor myColor = palette.findSimilarColor(153,255,153);
		short palIndex = myColor.getIndex();
		
		CellStyle style = workbook.createCellStyle();
	    style.setFillForegroundColor(palIndex);
	    style.setFillPattern(FillPatternType.SOLID_FOREGROUND);   
	    Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(font);
        font.setFontHeightInPoints((short)12);
        
        style.setAlignment(HorizontalAlignment.LEFT);
        font.setFontName(HSSFFont.FONT_ARIAL);
        
        style.setBorderBottom(BorderStyle.MEDIUM);
        style.setBorderTop(BorderStyle.MEDIUM);
        style.setBorderRight(BorderStyle.MEDIUM);
        style.setBorderLeft(BorderStyle.MEDIUM);
        
         
       
        return style;
		
	}
	
	protected CellStyle t5CellStyleData(Workbook workbook)
	{
				
		CellStyle style = workbook.createCellStyle();
	    Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(font);
        font.setFontHeightInPoints((short)12);
        
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setAlignment(HorizontalAlignment.CENTER);
        font.setFontName(HSSFFont.FONT_ARIAL);
        
        style.setBorderBottom(BorderStyle.MEDIUM);
        style.setBorderTop(BorderStyle.MEDIUM);
        style.setBorderRight(BorderStyle.MEDIUM);
        style.setBorderLeft(BorderStyle.MEDIUM);
        style.setWrapText(true);
        
        
        
        return style;
		
	}
	
	protected CellStyle t5CellStyleHeader(Workbook workbook)
	{
		HSSFPalette palette = ((HSSFWorkbook) workbook).getCustomPalette();
		HSSFColor myColor = palette.findSimilarColor(102,204,255);
		short palIndex = myColor.getIndex();
		
		CellStyle style = workbook.createCellStyle();
	    style.setFillForegroundColor(palIndex);
	    style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	    Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        font.setFontHeightInPoints((short)14);
        style.setFont(font);
        
        style.setBorderBottom(BorderStyle.MEDIUM);
        style.setBorderTop(BorderStyle.MEDIUM);
        style.setBorderRight(BorderStyle.MEDIUM);
        style.setBorderLeft(BorderStyle.MEDIUM);
        
        font.setFontName(HSSFFont.FONT_ARIAL);
        style.setAlignment(HorizontalAlignment.CENTER);
         
       
        return style;
		
	}
	
	public TCComponent[] QueryParaRel(String ItemId,String ItemRev,String ParaId)
	{     
		   TCComponent[] CtrlObj = null;
		   String[] qvalue;
		   String[] qname;
		   
		   String tempItemRev = ItemRev.replace(';','*');
		   
		   System.out.println("\n----------Query Test Plan For---\n"+ItemId+","+ItemRev+","+ParaId);
		   qname =  new String[] {"ID","Revision","para_item_id"};
		   qvalue =  new String[] {ItemId,tempItemRev,ParaId};
		  
	     
	      
	      
	      TCComponentQueryType qtype;
	      try
	      {
	          qtype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
	          TCComponentQuery CtrlObjquery = (TCComponentQuery) qtype.find("EE_Parameter_Relation");
	          if (CtrlObjquery != null)
	          {
	        	  CtrlObj = CtrlObjquery.execute(qname, qvalue); 
	        	  System.out.println("Number of EE para Relation Founds..." + CtrlObj.length);
	          }
	      }
	      catch (TCException e1)
	      {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
	      }
      return CtrlObj;
	}
	
	public void GetRevRuleLOV()
	{
			String usrinfo1 = null; 
			TCComponent[] CtrlObj = null;
			String[] qvalue = { "RevRule","ECU"};
			String[] qname = { "SYSCD","SUBSYSCD" };
			TCComponentQueryType qtype;
			try
			{
				System.out.println("query");
				qtype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
				System.out.println("qtype");
				TCComponentQuery CtrlObjquery = (TCComponentQuery) qtype.find("Control Objects...");
				System.out.println("ctrlobj");
				CtrlObj = CtrlObjquery.execute(qname, qvalue);
				System.out.println("ctrl find");
				System.out.println("Number of cntrl objs found in database GetProgram =" + CtrlObj.length);
				if (CtrlObj.length > 0)
				{
					TCComponent CtrlObjItem = null;
					System.out.println("outside for loop GetProgram");
					for (int i = 0; i < CtrlObj.length; i++)
					{
						System.out.println("inside for loop GetProgram");
						CtrlObjItem = CtrlObj[i];
						System.out.println("add ctrl in new item GetProgram");

						usrinfo1 = CtrlObjItem.getTCProperty("t5_Userinfo2").toString();
						System.out.println("add ctrl in new item GetProgram <" + usrinfo1 +">");
						combo_RevRule.add(usrinfo1);
						System.out.println("After Adding GetProgram <" + usrinfo1 +">");

					}
				}
			}
			catch (TCException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	}
	
}
