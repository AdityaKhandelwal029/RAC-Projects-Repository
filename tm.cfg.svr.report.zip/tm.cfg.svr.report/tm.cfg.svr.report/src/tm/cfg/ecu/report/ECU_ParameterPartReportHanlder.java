package tm.cfg.ecu.report;

import java.util.ArrayList;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.Display;

import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.util.MessageBox;

import tm.cfg.svr.report.SelectionUtil;

public class ECU_ParameterPartReportHanlder extends AbstractHandler {

	TCComponentItemRevision	Item_rev;
	ArrayList<String>		PartNumberRevSeq	= new ArrayList<String>();
	String					ParaNameRev			= null;
	String					ParaName			= null;
	
	public Object execute(ExecutionEvent event) throws ExecutionException
	{
		System.out.println("Inside ECU_ParameterPartReport Handler");
		
		if (SelectionUtil.getSelection().size() ==1)
		{
			try {
					if (SelectionUtil.getSelection().get(0).getStringProperty("t5_SwPartType").equals("PRM") ) {
						
						ParaName=SelectionUtil.getSelection().get(0).getStringProperty("item_id");
						ParaNameRev=SelectionUtil.getSelection().get(0).getStringProperty("item_revision_id");
						
						//Display display = Display.getDefault();
						ECU_ParameterPartReport ecuParaReport = new ECU_ParameterPartReport();
						
						ecuParaReport.SetECU_Report_PartNameSeq(ParaName,ParaNameRev);
						ecuParaReport.open();
						
									
					}
					else
					{
						MessageBox.post("Kindly please select ECU Partameter Part Revision.","Error", MessageBox.ERROR);
					}
					
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			MessageBox.post("Kindly please select single ECU Parameter Part.",
					"Error", MessageBox.ERROR);
			
		}
		return null;
		
	}
}
