package com.teamcenter.rac.exportconfigcontext.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.jface.dialogs.MessageDialog;

@SuppressWarnings("unused")
public class SampleHandler2 extends AbstractHandler {

	@SuppressWarnings("unused")
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		//MessageDialog.openInformation(window.getShell(),"ExportConfigContext","Handler 2");
		
		VariantCompareReport obj = new VariantCompareReport();
		obj.frmVariantCompareReport.setVisible(true);
				
		return null;
	}
}
