package com.teamcenter.rac.exportconfigcontext.handlers;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import com.t5.services.rac.tmshellexecution.T5LinuxShellManagementService;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Collections;
import java.util.Vector;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JProgressBar;
import javax.swing.ImageIcon;

@SuppressWarnings("unused")
public class ExportConfigReport {

	public JFrame frmConfiguratorContextReport;
	
	JButton btnNewButton;
	JButton btnNewButton_1;
	
	JTextPane textPane_1;
	
	TCSession session = null;
	TCComponentQueryType tccomponentquerytype = null;
	TCComponentQuery query = null;
	TCComponent configObj = null;
	TCComponentItemRevision parObjectRev = null;
	TCComponentItem itemComp = null;
	TCComponent[] qryResultConfigcontext = null;
	TCComponent[] cfgModelList = null;
	
	Vector<String> itemIdsfound = new Vector<>();
	
	String LoggedInUser = null;
	String currentRole  = null; 
	String currentGroup = null;
	String itemId       = null;
	String shellPath    = null;
	String shellName    = null;
	String shellInput1  = null;
	String shellInput2  = null;
	
	int execution = 0;
	int variCount = 0;
	
	JLabel lblLoading        = new JLabel("Loading :");
	JPanel panel = new JPanel();
	JLabel lblNewLabel_1     = new JLabel("Vehicle :");
	@SuppressWarnings("rawtypes")
	JComboBox comboBox       = new JComboBox();
	JPanel panel_1 = new JPanel();
	JLabel lblNewLabel_1_1   = new JLabel("Vehicle Item ID  :");
	JLabel lblNewLabel_1_1_1 = new JLabel("Name  :");
	JLabel lblNewLabel_1_1_2 = new JLabel("Description  :");
	JLabel lblLoadiongIcon;
	
	JTextField textField_ID;
	JTextField textField_Name;
	JTextField textField_Desc;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExportConfigReport window = new ExportConfigReport();
					window.frmConfiguratorContextReport.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ExportConfigReport() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmConfiguratorContextReport = new JFrame();
		frmConfiguratorContextReport.addWindowListener(new WindowAdapter() {
			@SuppressWarnings("unchecked")
			@Override
			public void windowOpened(WindowEvent e) 
			{
				  try 
				  {	
					  lblLoading.setVisible(true);
					  lblLoadiongIcon.setVisible(true);
					  
					  session = (TCSession) AIFUtility.getCurrentApplication().getSession();
					  LoggedInUser=session.getUser().getProperty("user_id").toString();	 
					  currentRole=session.getCurrentRole().getProperty("object_name").toString();
					  currentGroup=session.getCurrentGroup().getProperty("display_name").toString();
					  
					  System.out.println(" LoggedInUser found = "+LoggedInUser);	
					  System.out.println(" currentRole  found = "+currentRole);
					  System.out.println(" currentGroup found = "+currentGroup);
				      
					  tccomponentquerytype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
					  query = (TCComponentQuery)tccomponentquerytype.find("General..."); 
					  String[] qryEntry3  = new String[] {"Name","Type"}; 
					  String[] qryValues3 = new String[] {"*", "Configurator Context" };
					  qryResultConfigcontext = null; 
					  qryResultConfigcontext = query.execute(qryEntry3,qryValues3);
					  System.out.println("Total Configurator Context Objects Found = "+qryResultConfigcontext.length);				  					  													
					 
					  if(qryResultConfigcontext.length>0)
					  {					 	  
						  for(int i=0;i<qryResultConfigcontext.length;i++)							  
						  {
							  itemComp=(TCComponentItem)qryResultConfigcontext[i]; 						  	    			   				  
							   itemIdsfound.add(itemComp.getStringProperty("item_id"));								   							
						  }
						  Collections.sort(itemIdsfound);
						 
						  for(int i=0;i<itemIdsfound.size();i++)
						  {
							  comboBox.addItem(itemIdsfound.elementAt(i));
						  }
					  }					  					  					 				 
				  }
				  catch(TCException e1)
				  {
					  e1.printStackTrace();
					  System.out.println("TC Exception Found [Point1]");
				  }
				  catch(Exception e1)
				  {
					  e1.printStackTrace();
					  System.out.println("TC Exception Found [Point2]");
				  }
			
				  lblLoading.setVisible(false);
				  lblLoadiongIcon.setVisible(false);
			}
		});
		frmConfiguratorContextReport.setResizable(false);
		frmConfiguratorContextReport.setTitle("Product configurator reports");
		frmConfiguratorContextReport.getContentPane().setBackground(Color.WHITE);
		frmConfiguratorContextReport.getContentPane().setForeground(Color.WHITE);
		frmConfiguratorContextReport.setBounds(100, 100, 750, 370);
		frmConfiguratorContextReport.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	    btnNewButton = new JButton("OK");
	    btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    	}
	    });
	    btnNewButton.setBounds(489, 281, 89, 23);
	    btnNewButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));
	    btnNewButton.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) 
	    	{
	    		System.out.println(" ************************* OK Executed ****************** ");
	    		System.out.println(" -variCount = "+variCount);
	    		if(variCount > 0)
	    		{
	    			lblLoading.setVisible(true);
					lblLoadiongIcon.setVisible(true);
					
		    		lblLoading.setText("Loading :");
		    		lblLoadiongIcon.setIcon(new ImageIcon(ExportConfigReport.class.getResource("/com/teamcenter/rac/exportconfigcontext/handlers/LoadingImg.png")));
		    			    					
		    		shellPath=session.getPreferenceService().getStringValue("T5_CfgItemReports_Path");
					System.out.println(" - prefPath = "+shellPath);
					System.out.println(" - itemId   = "+itemId);
													
					if(shellPath.length()>0 && itemId.length()>0)
					{	
						System.out.println("*********** Shell Call Started ************** ");	
					   // Shell call start
					
					   shellName   = "CfgItemReportShell.sh";
					   shellInput1 = itemId;
					   shellInput2 = "RE1";
					
					   shellInput1="\""+shellInput1+"\""; 
					   shellInput2="\""+shellInput2+"|"+LoggedInUser+"\""; 
					
					   System.out.println(" -shellPath   = "+shellPath);	
					   System.out.println(" -shellName   = "+shellName);	
					   System.out.println(" -shellInput1 = "+shellInput1);	
					   System.out.println(" -shellInput2 = "+shellInput2);	
													
					   T5LinuxShellManagementService t5LinuxShellManagementService = T5LinuxShellManagementService.getService(session);					
					    String returnMessage = t5LinuxShellManagementService.tmShellBatchCall(shellPath, shellName,
							shellInput1, shellInput2);
					
					    System.out.println("Shell Output message :" + returnMessage);
	                    // Shell call end																			
				        System.out.println("*********** Shell Call Ended  **************");
					    JOptionPane.showMessageDialog(null,"Process completed successfully.Item Report available in Product Configurator Reports folder in HOME.","Info",JOptionPane.INFORMATION_MESSAGE);
						frmConfiguratorContextReport.dispose();
					}
					else
					{
						System.out.println("Error : Shell Path not found.");
						JOptionPane.showMessageDialog(null, "Error : Shell Path not found or Preference not added.","Error",JOptionPane.ERROR_MESSAGE);
					}
									
					 lblLoading.setVisible(false);
					 lblLoadiongIcon.setVisible(false);			
	    		}
	    		else
	    		{
	    			JOptionPane.showMessageDialog(null, "Error : Variants not found for select Item. Please check and try again.","Error",JOptionPane.ERROR_MESSAGE);
	    			textField_ID.setText("");
	    			textField_Name.setText("");
	    			textField_Desc.setText("");	    			    
	    		}
	    	}
	    });
		frmConfiguratorContextReport.getContentPane().setLayout(null);
		btnNewButton.setBackground(Color.WHITE);
		frmConfiguratorContextReport.getContentPane().add(btnNewButton);
		
		btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.setBounds(609, 281, 89, 23);
		btnNewButton_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				frmConfiguratorContextReport.dispose();
			}
		});
		btnNewButton_1.setBackground(Color.WHITE);
		frmConfiguratorContextReport.getContentPane().add(btnNewButton_1);
		
		textPane_1 = new JTextPane();
		textPane_1.setBounds(461, 266, 263, 54);
		textPane_1.setEditable(false);
		textPane_1.setBorder(new LineBorder(Color.LIGHT_GRAY));
		frmConfiguratorContextReport.getContentPane().add(textPane_1);
		
		lblLoading.setText("Loading :");
		lblLoading.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		lblLoading.setBounds(440, 11, 74, 23);
		frmConfiguratorContextReport.getContentPane().add(lblLoading);
		
		
		panel.setBackground(Color.WHITE);
		panel.setBounds(10, 55, 714, 55);
		frmConfiguratorContextReport.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(115, 11, 65, 32);
		panel.add(lblNewLabel_1);
		comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		
		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if(execution>0)
				{
					try
					{
						itemId=comboBox.getSelectedItem().toString();
						session = (TCSession) AIFUtility.getCurrentApplication().getSession();
						tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
						query = (TCComponentQuery) tccomponentquerytype.find("Item...");
						String[] qryEntry2 = new String[] { "Item ID" };
						String[] qryValues2 = new String[] { itemId};
						qryResultConfigcontext = null;
						qryResultConfigcontext = query.execute(qryEntry2, qryValues2);
						System.out.println("Real Obj found = "+qryResultConfigcontext.length);
						
						if(qryResultConfigcontext.length>0)
						{
							for(int i=0;i<qryResultConfigcontext.length;i++)
							{
								textField_ID.setText(qryResultConfigcontext[i].getStringProperty("item_id"));
								textField_Name.setText(qryResultConfigcontext[i].getStringProperty("object_name"));
								textField_Desc.setText(qryResultConfigcontext[i].getStringProperty("object_desc"));
								configObj=qryResultConfigcontext[i].getReferenceProperty("cfg0ConfigPerspective");							
								System.out.println("Perspective name = "+configObj.getStringProperty("object_string"));
								cfgModelList=null;													
								cfgModelList=configObj.getReferenceListProperty("cfg0Models");
								System.out.println("Total Variants Found In ActionPerformed = "+cfgModelList.length);
								variCount=cfgModelList.length;
							}	
						}
						else
						{
							System.out.println("Error :qryResultConfigcontext.length == 0. Or Real Object not found.");
						}
					}
					catch(TCException e1)
					{
						System.out.println("TCException Found [Point 2]");
						e1.printStackTrace();
					}
					catch(Exception e1)
					{
						System.out.println("Exception Found [Point 2]");
						e1.printStackTrace();
					}
				}
				execution++;
			}
		});
		comboBox.setBounds(237, 11, 379, 33);
		panel.add(comboBox);
		
		
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(10, 121, 714, 130);
		frmConfiguratorContextReport.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(113, 9, 115, 25);
		panel_1.add(lblNewLabel_1_1);
		
		
		lblNewLabel_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1_1_1.setBounds(113, 44, 90, 25);
		panel_1.add(lblNewLabel_1_1_1);
		
		
		lblNewLabel_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1_1_2.setBounds(113, 80, 90, 25);
		panel_1.add(lblNewLabel_1_1_2);
		
		textField_ID = new JTextField();
		textField_ID.setEditable(false);
		textField_ID.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		textField_ID.setBounds(238, 13, 380, 25);
		panel_1.add(textField_ID);
		textField_ID.setColumns(10);
		
		textField_Name = new JTextField();
		textField_Name.setEditable(false);
		textField_Name.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		textField_Name.setColumns(10);
		textField_Name.setBounds(238, 48, 380, 25);
		panel_1.add(textField_Name);
		
		textField_Desc = new JTextField();
		textField_Desc.setEditable(false);
		textField_Desc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		textField_Desc.setColumns(10);
		textField_Desc.setBounds(238, 84, 380, 25);
		panel_1.add(textField_Desc);
		
		lblLoadiongIcon = new JLabel("");
		lblLoadiongIcon.setIcon(new ImageIcon(ExportConfigReport.class.getResource("/com/teamcenter/rac/exportconfigcontext/handlers/LoadingImg.png")));
		lblLoadiongIcon.setBounds(524, 10, 40, 32);
		frmConfiguratorContextReport.getContentPane().add(lblLoadiongIcon);
	}
}
