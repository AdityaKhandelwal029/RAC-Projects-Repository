package com.teamcenter.rac.exportconfigcontext.handlers;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Collections;
import java.util.Vector;
import java.awt.Color;
import javax.swing.JPanel;

import com.t5.services.rac.tmshellexecution.T5LinuxShellManagementService;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentConfigurationContext;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JProgressBar;
import javax.swing.ImageIcon;
import java.awt.Rectangle;

@SuppressWarnings("unused")
public class VariantCompareReport {

	public JFrame frmVariantCompareReport;
	JPanel panel = new JPanel();
	JLabel lblNewLabel    = new JLabel("Vehicle 1st  :");
	JLabel lblNewLabel_1  = new JLabel("Variant  :");
	@SuppressWarnings("rawtypes")
	JComboBox comboBoxId1    = new JComboBox();
	@SuppressWarnings("rawtypes")
	JComboBox comboBoxVar1  = new JComboBox();

	JPanel panel_1 = new JPanel();
	JLabel lblConfiguratorContextnd = new JLabel("Variant 2nd  :");
	JLabel lblNewLabel_1_1 = new JLabel("Variant  :");

	@SuppressWarnings("rawtypes")
	JComboBox comboBoxId2   = new JComboBox();
	@SuppressWarnings("rawtypes")
	JComboBox comboBoxVar2 = new JComboBox();
	JPanel panel_3 = new JPanel();

	JButton btnNewButton = new JButton("OK");
	JButton btnCancel    = new JButton("Cancel");
	TCSession session = null;
	TCComponentQueryType tccomponentquerytype = null;
	TCComponentQuery query = null;
	TCComponent configObj = null;
	TCComponentConfigurationContext cfgObj = null;
	TCComponentItemRevision parObjectRev = null;
	TCComponentItem itemComp = null;
	TCComponent[] qryResultConfigcontext = null;
	
	TCComponent[] cfgModelList = null;
	
	Vector<String> itemIdsfound = new Vector<>();
	
	String LoggedInUser = null;
	String currentRole  = null; 
	String currentGroup = null;
	String shellPath    = null;
	String shellName    = null;
	String shellInput1  = null;
	String shellInput2  = null;
	String itemId1      = null;
	String variant1     = null;
	String itemId2      = null;
	String variant2     = null;
	
	int execution1=0;
	int execution2=0;
	
	int variCount1 = 0;
	int variCount2 = 0;
	
	JLabel lblLoading = new JLabel("Loading :");
    JLabel lblLoadiongIcon = new JLabel("");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VariantCompareReport window = new VariantCompareReport();
					window.frmVariantCompareReport.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VariantCompareReport() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmVariantCompareReport = new JFrame();
		frmVariantCompareReport.setResizable(false);
		frmVariantCompareReport.setTitle("Product configurator reports");
		frmVariantCompareReport.getContentPane().setBackground(Color.WHITE);
		frmVariantCompareReport.addWindowListener(new WindowAdapter() {
			@SuppressWarnings("unchecked")
			@Override
			public void windowActivated(WindowEvent e) 
			{
				 try 
				  {		  
					 lblLoading.setVisible(true);
					 lblLoadiongIcon.setVisible(true);
					  
					  session = (TCSession) AIFUtility.getCurrentApplication().getSession();
					  LoggedInUser=session.getUser().getProperty("user_id").toString();	 
					  currentRole=session.getCurrentRole().getProperty("object_name").toString();
					  currentGroup=session.getCurrentGroup().getProperty("display_name").toString();
					  
					  System.out.println(" LoggedInUser found = "+LoggedInUser);	
					  System.out.println(" currentRole  found = "+currentRole);
					  System.out.println(" currentGroup found = "+currentGroup);
				      
					  tccomponentquerytype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
					  query = (TCComponentQuery)tccomponentquerytype.find("General..."); 
					  String[] qryEntry3  = new String[] {"Name","Type"}; 
					  String[] qryValues3 = new String[] {"*", "Configurator Context" };
					  qryResultConfigcontext = null; 
					  qryResultConfigcontext = query.execute(qryEntry3,qryValues3);
					  System.out.println("Total Configurator Context Objects Found = "+qryResultConfigcontext.length);				  					  													
					  if(qryResultConfigcontext.length>0)
					  {					 	  
						  for(int i=0;i<qryResultConfigcontext.length;i++)							  
						  {
							  itemComp=(TCComponentItem)qryResultConfigcontext[i]; 						  	    			   				  
							  itemIdsfound.add(itemComp.getStringProperty("item_id"));								   							
						  }
						  Collections.sort(itemIdsfound);
						  for(int i=0;i<itemIdsfound.size();i++)
						  {
							  comboBoxId1.addItem(itemIdsfound.elementAt(i));
							  comboBoxId2.addItem(itemIdsfound.elementAt(i));
						  }
					  }
					  
				  }
				  catch(TCException e1)
				  {
					  e1.printStackTrace();
					  System.out.println("TC Exception Found [Point 1.1]");
				  }
				  catch(Exception e1)
				  {
					  e1.printStackTrace();
					  System.out.println("TC Exception Found [Point 1.1]");
				  }
				 lblLoading.setVisible(false);
				 lblLoadiongIcon.setVisible(false);
			}
		});
		frmVariantCompareReport.setBounds(100, 100, 720, 435);
		frmVariantCompareReport.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmVariantCompareReport.getContentPane().setLayout(null);
		
		
		panel.setBackground(Color.WHITE);
		panel.setBounds(21, 53, 660, 105);
		frmVariantCompareReport.getContentPane().add(panel);
		panel.setLayout(null);
		lblNewLabel.setBounds(new Rectangle(0, 0, 80, 30));
		
		
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel.setBounds(40, 14, 80, 29);
		panel.add(lblNewLabel);
		lblNewLabel_1.setBounds(new Rectangle(0, 0, 80, 30));
		
		
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(40, 50, 80, 30);
		panel.add(lblNewLabel_1);
		comboBoxId1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		comboBoxId1.addActionListener(new ActionListener() {
			@SuppressWarnings("unchecked")
			public void actionPerformed(ActionEvent e) 
			{
				if(execution1>0)
				{
					try
					{
						itemId1=comboBoxId1.getSelectedItem().toString();
						comboBoxVar1.removeAllItems();						
						tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
						query = (TCComponentQuery) tccomponentquerytype.find("Item...");
						String[] qryEntry2 = new String[] { "Item ID" };
						String[] qryValues2 = new String[] { itemId1};
						qryResultConfigcontext = null;
						qryResultConfigcontext = query.execute(qryEntry2, qryValues2);
						System.out.println("Real Obj found = "+qryResultConfigcontext.length);
						if(qryResultConfigcontext.length>0)
						{
							for(int i=0;i<qryResultConfigcontext.length;i++)
							{							
								System.out.println("Item 1 ID   = "+qryResultConfigcontext[i].getStringProperty("item_id"));
								System.out.println("Item 1 Name = "+qryResultConfigcontext[i].getStringProperty("object_name"));
								System.out.println("Item 1 Desc = "+qryResultConfigcontext[i].getStringProperty("object_desc"));						    							
								
								configObj=qryResultConfigcontext[i].getReferenceProperty("cfg0ConfigPerspective");							
								System.out.println("Perspective name = "+configObj.getStringProperty("object_string"));
								cfgModelList=null;													
								cfgModelList=configObj.getReferenceListProperty("cfg0Models");
								System.out.println("Total Variants Found = "+cfgModelList.length);
								if(cfgModelList.length>0)
								{
									variCount1=cfgModelList.length;
									for(int itr=0;itr<cfgModelList.length;itr++)
									{
										System.out.println("Variant Name = "+cfgModelList[itr].getStringProperty("cfg0ObjectId"));
										comboBoxVar1.addItem(cfgModelList[itr].getStringProperty("cfg0ObjectId"));
									}	
								}
								else
								{
									System.out.println("Variant not found for cfgItem1. Please select Valid CfgItem");
									//JOptionPane.showMessageDialog(null, "Variants not found for Select configurator context 1st.Please Select Valid Object.","Error",JOptionPane.ERROR_MESSAGE);
								}
							}	
						}						
					}
					catch(TCException e1)
					{
						e1.printStackTrace();
						System.out.println("TC Exception Found [Point 2.1.1]");
					}
					catch(Exception e1)
					{
						e1.printStackTrace();
						System.out.println("TC Exception Found [Point 2.1.2]");
					}
				}
				execution1++;
			}
		});		
		
		comboBoxId1.setBounds(195, 15, 400, 30);
		panel.add(comboBoxId1);
		comboBoxVar1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		
		
		comboBoxVar1.setBounds(195, 55, 400, 30);
		panel.add(comboBoxVar1);
		
		
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(21, 186, 660, 105);
		frmVariantCompareReport.getContentPane().add(panel_1);
		
		
		lblConfiguratorContextnd.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblConfiguratorContextnd.setBounds(40, 14, 90, 30);
		panel_1.add(lblConfiguratorContextnd);
		
		
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(40, 50, 80, 30);
		panel_1.add(lblNewLabel_1_1);
		comboBoxId2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		comboBoxId2.addActionListener(new ActionListener() {
			@SuppressWarnings("unchecked")
			public void actionPerformed(ActionEvent e) 
			{
				if(execution2>0)
				{
					try
					{
						itemId2=comboBoxId2.getSelectedItem().toString();
						comboBoxVar2.removeAllItems();	
						tccomponentquerytype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
						query = (TCComponentQuery) tccomponentquerytype.find("Item...");
						String[] qryEntry2  = new String[] { "Item ID" };
						String[] qryValues2 = new String[] { itemId2};
						qryResultConfigcontext = null;
						qryResultConfigcontext = query.execute(qryEntry2, qryValues2);
						System.out.println("Real Obj found = "+qryResultConfigcontext.length);
						if(qryResultConfigcontext.length>0)
						{
							for(int i=0;i<qryResultConfigcontext.length;i++)
							{
								System.out.println("Item 2 ID   = "+qryResultConfigcontext[i].getStringProperty("item_id"));
								System.out.println("Item 2 Name = "+qryResultConfigcontext[i].getStringProperty("object_name"));
								System.out.println("Item 2 Desc = "+qryResultConfigcontext[i].getStringProperty("object_desc"));
								configObj=qryResultConfigcontext[i].getReferenceProperty("cfg0ConfigPerspective");							
								System.out.println("Perspective name = "+configObj.getStringProperty("object_string"));
								cfgModelList=null;													
								cfgModelList=configObj.getReferenceListProperty("cfg0Models");
								System.out.println("Total Variants Found = "+cfgModelList.length);
								if(cfgModelList.length>0)
								{
									variCount2=cfgModelList.length;
									for(int itr=0;itr<cfgModelList.length;itr++)
									{
										System.out.println("Variant Name = "+cfgModelList[itr].getStringProperty("cfg0ObjectId"));
										comboBoxVar2.addItem(cfgModelList[itr].getStringProperty("cfg0ObjectId"));
									}	
								}
								else
								{
									System.out.println("Variant not found for cfgItem1. Please select Valid CfgItem");
									//JOptionPane.showMessageDialog(null, "Variants not found for Select configurator context 2nd.Please Select Valid Object.","Error",JOptionPane.ERROR_MESSAGE);
								}
							}	
						}					
					}
					catch(TCException e1)
					{
						e1.printStackTrace();
						System.out.println("TC Exception Found [Point 2.1.1]");
					}
					catch(Exception e1)
					{
						e1.printStackTrace();
						System.out.println("TC Exception Found [Point 2.1.2]");
					}
				}
				execution2++;	
			}
		});
				
		comboBoxId2.setBounds(195, 11, 400, 30);
		panel_1.add(comboBoxId2);
		comboBoxVar2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		
		comboBoxVar2.setBounds(195, 50, 400, 30);
		panel_1.add(comboBoxVar2);
		
		
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(370, 302, 301, 83);
		frmVariantCompareReport.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				 try 
				 {					 					 
					 if(variCount1==0 || variCount2==0)
					 {
						 JOptionPane.showMessageDialog(null, "Error : Variants not found for selected Item. Please check and try again.","Error",JOptionPane.ERROR_MESSAGE); 
					 }
					 else
					 {
						 lblLoading.setVisible(true);
						 lblLoadiongIcon.setVisible(true);						
				    	 lblLoading.setText("Loading :");
				    	 lblLoadiongIcon.setIcon(new ImageIcon(ExportConfigReport.class.getResource("/com/teamcenter/rac/exportconfigcontext/handlers/LoadingImg.png")));			    			    										 
						 
						 itemId1      = comboBoxId1.getSelectedItem().toString();
						 variant1     = comboBoxVar1.getSelectedItem().toString();
						 itemId2      = comboBoxId2.getSelectedItem().toString();
						 variant2     = comboBoxVar2.getSelectedItem().toString();
						 shellPath=session.getPreferenceService().getStringValue("T5_CfgItemReports_Path");
						 shellName   = "CfgItemReportShell.sh";
						 
						 System.out.println(" -itemId1   = "+itemId1);
						 System.out.println(" -variant1  = "+variant1);
						 System.out.println(" -itemId2   = "+itemId2);
						 System.out.println(" -variant2  = "+variant2);
						 System.out.println(" -shellPath = "+shellPath);
						 System.out.println(" -shellName = "+shellName);
						 
						 if(itemId1.equals("")==true||variant1.equals("")==true||itemId2.equals("")==true||variant2.equals("")==true)
						 {
							 System.out.println("Error : [Point2] Values not found Proper.");
							 JOptionPane.showMessageDialog(null, "Error : Values not found Proper or miss values found. Please check and try again.","Error",JOptionPane.ERROR_MESSAGE);
						 }
						 else
						 {
							 shellInput1="\""+itemId1+"|"+variant1+"|"+itemId2+"|"+variant2+"\"";
							 shellInput2 = "\""+"RE2"+"|"+LoggedInUser+"\""; 
							 
							 System.out.println(" -shellInput1 Final = "+shellInput1);
							 System.out.println(" -shellInput2 Final = "+shellInput2);
							 
							 // Shell Call started
							 
							 if(shellPath.equals("")==true||shellName.equals("")==true||shellInput1.equals("")==true||shellInput2.equals("")==true)
							 {
								 System.out.println("Error : [Point3] Values not found Proper to execute shell.");
								 JOptionPane.showMessageDialog(null, "Error : Shell Path not found or Preference not added or Input not Proper.","Error",JOptionPane.ERROR_MESSAGE);
							 }
							 else
							 {
								 System.out.println("*********** Shell Call Started  **************");
								 T5LinuxShellManagementService t5LinuxShellManagementService = T5LinuxShellManagementService.getService(session);					
								 String returnMessage = t5LinuxShellManagementService.tmShellBatchCall(shellPath, shellName,
								 shellInput1, shellInput2);
								 System.out.println("Shell Output message :" + returnMessage);				                																		
							     System.out.println("*********** Shell Call Ended  **************");
								 JOptionPane.showMessageDialog(null,"Process completed successfully.Variant Comparison Report available in Product Configurator Reports folder in HOME. ","Info",JOptionPane.INFORMATION_MESSAGE);							 
								 frmVariantCompareReport.dispose();
							 }
							 // Shell call ended
						 }
					 }
					 
		       	  }
				  catch(Exception e1)
				  {
					  e1.printStackTrace();
					  System.out.println("General Exception Found [Point 3.1]");
				  }		
				 
				 lblLoading.setVisible(false);
				 lblLoadiongIcon.setVisible(false);
				 
			}
		});
		
		btnNewButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnNewButton.setBounds(46, 29, 89, 23);
		panel_3.add(btnNewButton);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				frmVariantCompareReport.dispose();
			}
		});
		
		
		btnCancel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnCancel.setBounds(169, 29, 89, 23);
		panel_3.add(btnCancel);
		lblLoading.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		lblLoading.setBounds(452, 12, 74, 23);
		
		frmVariantCompareReport.getContentPane().add(lblLoading);
		lblLoadiongIcon.setIcon(new ImageIcon(VariantCompareReport.class.getResource("/com/teamcenter/rac/exportconfigcontext/handlers/LoadingImg.png")));
		lblLoadiongIcon.setBounds(536, 10, 40, 32);
		
		frmVariantCompareReport.getContentPane().add(lblLoadiongIcon);
	}
}
